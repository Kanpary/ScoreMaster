package com.scoremaster.app.domain

import org.junit.Assert.*
import org.junit.Test
import java.math.BigDecimal

class ScoreRulesTest {
    @Test fun accuracyUsesOnlySettledWinsAndLosses() {
        val stats = ScoreRules.statistics(listOf(
            ResultStatus.WON, ResultStatus.WON, ResultStatus.LOST, ResultStatus.PENDING,
            ResultStatus.VOIDED, ResultStatus.POSTPONED, ResultStatus.CANCELLED
        ))
        assertEquals(2, stats.wins)
        assertEquals(1, stats.losses)
        assertEquals(1, stats.pending)
        assertEquals(3, stats.excluded)
        assertEquals(3, stats.sampleSize)
        assertEquals(BigDecimal("66.7"), stats.accuracyPercent)
    }

    @Test fun noSettledResultsIsUnknownNotZero() {
        val stats = ScoreRules.statistics(listOf(ResultStatus.PENDING, ResultStatus.VOIDED))
        assertEquals(0, stats.sampleSize)
        assertNull(stats.accuracyPercent)
    }

    @Test fun emptyDataIsUnknown() {
        assertNull(ScoreRules.statistics(emptyList()).accuracyPercent)
    }

    @Test fun resultMappingDefaultsUnknownValuesToPending() {
        assertEquals(ResultStatus.PENDING, ResultStatus.fromWire("new-value"))
        assertEquals(ResultStatus.WON, ResultStatus.fromWire("won"))
    }
}

class OddsParserTest {
    @Test fun acceptsCommaAndPeriodDecimals() {
        assertEquals(BigDecimal("1.85"), OddsParser.parse("1,85"))
        assertEquals(BigDecimal("2.1"), OddsParser.parse(" 2.10 "))
    }

    @Test fun rejectsInvalidOrNonPositiveValues() {
        listOf("", "0", "-1", "1,2.3", "1,", ".5", "1.12345", "abc").forEach {
            assertNull("$it should be invalid", OddsParser.parse(it))
        }
    }
}
