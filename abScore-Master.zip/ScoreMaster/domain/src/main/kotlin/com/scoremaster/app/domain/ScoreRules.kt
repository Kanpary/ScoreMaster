package com.scoremaster.app.domain

import java.math.BigDecimal
import java.math.RoundingMode

/** Canonical result states shared by the app and backend contract. */
enum class ResultStatus(val wireValue: String, val countsAsSettled: Boolean) {
    PENDING("pending", false), WON("won", true), LOST("lost", true),
    VOIDED("voided", false), POSTPONED("postponed", false), CANCELLED("cancelled", false);

    companion object {
        fun fromWire(value: String?): ResultStatus = entries.firstOrNull { it.wireValue == value } ?: PENDING
    }
}

data class SettledStatistics(
    val wins: Int,
    val losses: Int,
    val pending: Int,
    val excluded: Int,
    val sampleSize: Int,
    val accuracyPercent: BigDecimal?
)

/** Accuracy is wins / (wins + losses); voided, postponed and cancelled are excluded. */
object ScoreRules {
    fun statistics(statuses: Iterable<ResultStatus>): SettledStatistics {
        var wins = 0
        var losses = 0
        var pending = 0
        var excluded = 0
        for (status in statuses) when (status) {
            ResultStatus.WON -> wins++
            ResultStatus.LOST -> losses++
            ResultStatus.PENDING -> pending++
            ResultStatus.VOIDED, ResultStatus.POSTPONED, ResultStatus.CANCELLED -> excluded++
        }
        val sample = wins + losses
        val accuracy = if (sample == 0) null else
            BigDecimal(wins).multiply(BigDecimal("100")).divide(BigDecimal(sample), 1, RoundingMode.HALF_UP)
        return SettledStatistics(wins, losses, pending, excluded, sample, accuracy)
    }
}

/** Accepts decimal odds with either comma or period, without grouping separators. */
object OddsParser {
    fun parse(input: String): BigDecimal? {
        val normalized = input.trim().replace(',', '.')
        if (!normalized.matches(Regex("(?:0|[1-9]\\d*)(?:\\.\\d{1,4})?"))) return null
        val value = normalized.toBigDecimalOrNull() ?: return null
        if (value <= BigDecimal.ZERO) return null
        return value.stripTrailingZeros()
    }
}

data class PredictionDraft(
    val homeTeam: String,
    val awayTeam: String,
    val competition: String,
    val marketId: String,
    val selection: String,
    val startAtIso: String,
    val odds: BigDecimal?
)

object PredictionValidation {
    fun errors(draft: PredictionDraft, requiresOdds: Boolean): Set<String> = buildSet {
        if (draft.homeTeam.isBlank()) add("homeTeam")
        if (draft.awayTeam.isBlank()) add("awayTeam")
        if (draft.competition.isBlank()) add("competition")
        if (draft.marketId.isBlank()) add("marketId")
        if (draft.selection.isBlank()) add("selection")
        if (draft.startAtIso.isBlank()) add("startAt")
        if (requiresOdds && (draft.odds == null || draft.odds <= BigDecimal.ZERO)) add("odds")
    }
}
