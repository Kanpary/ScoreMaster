# Score Master

Projeto Android Kotlin com backend Firebase e painel administrativo autenticado. O arquivo ZIP abre com módulos ``app/``, ``domain/``, Wrapper Gradle e configurações na raiz `ScoreMaster/`.

O projeto não contém usuários, palpites, estatísticas, resultados ou credenciais fictícios. Os únicos registros QA são criados por testes nos emuladores ou por execução explicitamente autorizada com uma conta dedicada.

Leia ``ANDROID-SETUP.md`` para compilar e implantar pela nuvem usando o navegador do celular. ``VALIDATION.md`` informa precisamente o que foi executado. ``E2E-ACCEPTANCE.md`` define a validação no aparelho e no projeto de destino.

Inclui logomarca e ícone iguais, editor de componentes nativos e blocos declarativos, categorias tipadas, publicação/agendamento, usuários, documentos/FAQ, busca no servidor, salvos com histórico preservado, estatísticas canônicas, temas/idiomas, exportação paginada e campanhas FCM. A configuração declarativa controla os componentes e ações previstos no esquema; alterar o esquema ou criar uma função nova exige código.

Release exige Firebase Android real e chave permanente do responsável. O build interrompe a geração quando esses requisitos não existem. O ZIP é código-fonte; não contém APK aprovado para distribuição.
