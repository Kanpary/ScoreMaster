# Score Master

App Android de conteúdo esportivo público e painel administrativo para uma única conta proprietária. O app lê uma coleção pública separada, com somente os campos editoriais necessários; os registros internos permanecem restritos ao admin. Pesquisa/filtros e detalhes funcionam sem login. Favoritos e preferências ficam no dispositivo.

A edição Spark não usa Firebase Storage nem Cloud Functions. O painel escreve diretamente no Firestore sob regras que exigem a claim administrativa `admin: true`. Isso reduz a validação centralizada e o histórico de auditoria do backend anterior.

A configuração visual, categorias e palpites reais podem ser editados no painel. Login/cadastro de visitantes, favoritos sincronizados, métricas pessoais, notificações push/campanhas, uploads de imagem e agendamento não fazem parte desta edição. Firebase gratuito tem cotas; o workflow não faz upgrade para Blaze.

Use [COMECE-AQUI-ANDROID.md](COMECE-AQUI-ANDROID.md) para atualizar os arquivos pelo celular. [ANDROID-SETUP.md](ANDROID-SETUP.md) descreve a compilação. [VALIDATION.md](VALIDATION.md) registra o que foi realmente verificado nesta revisão. O pacote é código-fonte, não APK compilado/testado.
