# Validação executada — 11/10/2026

O pacote contém código-fonte Android, backend e painel. Nenhum APK foi gerado ou aprovado para distribuição nesta revisão. Nenhuma credencial, implantação ou sucesso de entrega foi inventado.

## Resultados desta revisão

| Verificação | Resultado | Evidência |
|---|---|---|
| Typecheck TypeScript com Node 22 | Passou | `evidence/backend-typecheck.txt` |
| Unitários backend | 14 testes, zero falhas | `evidence/backend-tests.txt` |
| Domínio Kotlin atual | 6 testes, zero falhas | `evidence/domain-isolated-tests.txt`, `evidence/domain-tests/` |
| Integração Auth/Firestore + wrappers HTTP reais Functions | 2 cenários integrados, zero falhas | `evidence/backend-integration-http.txt` |
| XML, recursos e idiomas | XML válido; 115 chaves iguais em PT/EN/ES | `evidence/source-checks.json` |
| JavaScript e workflows | Sintaxe válida; quatro workflows e todos os scripts shell parseados | `codemagic.yaml` |\n| Geração de keystore | PKCS12 e alias testados em diretório temporário isolado | Teste local do workflow; arquivo temporário excluído |\n| Envio simplificado de celular | ZIP do projeto + YAML na raiz, extração automatizada validada | `COMECE-AQUI-ANDROID.md` e `Score-Master-upload-celular.zip` |
| Logo e launcher | Mesmo bitmap, SHA-256 igual | `evidence/source-checks.json` |
| Compilação Android atual | Interrompida: SDK ausente | `evidence/android-compile-current.txt` |

O domínio Kotlin foi compilado em um projeto Gradle isolado que aponta para o mesmo módulo `domain` do aplicativo, sem substituir seu código. Corrigida a compatibilidade de alvos Java/Kotlin para JVM 17. Essa execução não compila a Activity, os serviços Android nem a instrumentação.

## Escopo comprovado da integração

Os testes executam os SDKs reais com Auth e Firestore emuladores. As funções callable são os próprios handlers HTTP do SDK Firebase Functions, servidos em TCP local, sem respostas simuladas. Criam contas e registros QA somente no ambiente isolado.

Verificam: acesso anônimo/não verificado/não administrativo negado; criação e publicação; busca; salvamento idempotente; estatísticas e resultados canônicos; transação do processador de sincronização executada duas vezes; preservação histórica após edição/arquivamento; preferências; idioma da conta preservado no registro do dispositivo; remoção do token ao sair; configuração válida/inválida; campanha agendada/cancelada; exportação paginada; consulta administrativa; desativação/reativação e revogação; exclusão; regras de isolamento e escrita protegida.

Nesta modalidade o processador de evento é invocado diretamente com snapshots reais do emulador. **A entrega automática do evento pelo Eventarc não foi validada.** A execução completa `test:integration` foi tentada, mas o runtime Functions usa socket Unix que este ambiente rejeita com EPERM (`evidence/backend-integration.txt`). O workflow adicional inclui essa execução em um runner compatível. FCM real, Storage real, Scheduler e infraestrutura de nuvem não são substituídos por essa evidência.

## Código incluído

- Android na raiz do ZIP; chave permanente exigida para release; logomarca e launcher iguais; ícone monocromático próprio para notificações.
- Auth real, verificação de e-mail, preferências de conta, temas claro/escuro/sistema e três idiomas.
- Busca e filtros no servidor, paginação e cache separado por conta; salvos filtrados e atualizados por listener, conteúdo histórico preservado e resultados sincronizados; histórico de resultados paginado.
- Categorias com campos tipados, validação, tradução, regras de odds e arquivamento; criação, edição concorrente, duplicação, publicação, retirada de publicação e agendamento de palpites.
- Editor declarativo: estilos dos 21 componentes previstos, textos, imagens, blocos, seções suportadas, rascunhos, publicação e restauração; documentos institucionais e FAQ; prévia de estilos/blocos no painel.
- Gestão de contas comuns, desativação/reativação, totais reais, consulta de auditoria e paginação administrativa.
- Exportação paginada para arquivo; exclusão reautenticada; limpeza de sessão e tokens/dispositivos.
- Campanhas FCM: idiomas, imagem/URL, próprios/todos, estimativa de público, fila, agendamento/cancelamento, inbox, preferências, canais, logs e retentativas limitadas.
- Instrumentação Android com conta de QA real, script de execução, workflows de backend, implantação e release assinado.

## Limites de configuração e execução

O editor altera os componentes e ações expressamente conectados ao esquema. Não executa código arbitrário nem cria novos tipos de tela/função; isso exige desenvolvimento. A prévia do painel representa estilos/blocos e não é uma reprodução pixel a pixel do Android. Textos de segurança e significado dos resultados são protegidos.

O ambiente de trabalho não tem Android SDK nem aparelho/emulador adb. A tentativa real de `:app:compileDebugKotlin` chega ao Gradle/AGP e falha em `SDK location not found`. Portanto não há typecheck Android, lint, instrumentação, instalação ou teste ponta a ponta no aparelho desta revisão. O JDK e o Gradle estão disponíveis; a distribuição Gradle usada passou no SHA-256 oficial, incluído no Wrapper.

O projeto Firebase do responsável, seu `google-services.json`, credencial autorizada para implantação e chave permanente de assinatura não foram fornecidos. Os workflows em nuvem estão preparados, mas não foram executados. Conteúdo institucional específico do responsável deve ser publicado por ele; o projeto não inventa política jurídica, contatos ou resultados. O preview hospedado anterior não foi atualizado nesta revisão; o painel novo está em `dist/` no ZIP.

`accepted_by_fcm` significa aceite do provedor, não entrega ao aparelho. `completed` significa fim do processamento. Envio interrompido fica `unknown`, sem repetição automática: não há garantia de entrega exatamente uma vez.

Siga `COMECE-AQUI-ANDROID.md` para as etapas pelo Android e consulte `ANDROID-SETUP.md` para os parâmetros de compilação/implantação e `E2E-ACCEPTANCE.md` para a aceitação no destino. Aprovação do release exige executar essas verificações no projeto e aparelho de destino.
