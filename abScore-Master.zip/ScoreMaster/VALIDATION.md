# Validação da edição Firebase Spark — 11/10/2026

## Resultado desta revisão

Esta revisão remove o requisito de conta visitante e troca o feed, detalhes, favoritos e preferências para leitura pública/local. O painel faz gravações diretas no Firestore protegidas por claim administrativa. O workflow Firebase não implanta Storage nem Cloud Functions.

| Verificação | Resultado | Evidência |
|---|---|---|
| Sintaxe do painel JavaScript | Passou | `node --check dist/admin.mjs` |
| Sintaxe de `firebase.json` | Passou | `python3 -m json.tool firebase.json` |
| Compilação Kotlin Android | Não executada | O wrapper tentou baixar Gradle e a rede do ambiente bloqueou a conexão; Android SDK também não está instalado neste ambiente. |
| APK, assinatura e instalação | Não executados | Exigem build Codemagic e execução em aparelho/emulador. |
| Firebase real / regras em produção | Não executados | Dependem do projeto, da credencial de implantação e da execução pelo responsável. |
| E2E em aparelho | Não executado | A instrumentação foi ajustada para a edição pública; requer um documento publicado de QA e runner conectado. |

Evidências anteriores em `evidence/` referem-se à versão com backend Functions/Auth de visitantes. Elas não comprovam as alterações desta edição Spark e não devem ser usadas como aprovação atual do app.

## Limitações da edição sem cobrança

O painel grava diretamente no Firestore, com acesso permitido apenas à conta administrativa que carrega a claim `admin: true`. A lógica deixa de ter a camada transacional/validadora do backend anterior; alterações administrativas não criam o mesmo registro de auditoria do servidor. Configure somente uma conta administrativa confiável e mantenha as regras publicadas.

Cadastro/login de visitantes, perfil, favoritos entre aparelhos, estatísticas pessoais, push/campanhas, upload Firebase Storage, agendamentos de publicação e histórico de auditoria não estão disponíveis. Favoritos e preferências ficam no próprio Android. O conteúdo público só aparece após publicar dados reais no Firestore.

Firestore, Authentication e Hosting têm cotas gratuitas sujeitas aos limites do Firebase. O fluxo descrito não ativa Blaze. Se alcançar limites, reduza ou interrompa o uso sem fazer upgrade.
