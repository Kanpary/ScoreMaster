# Marca Score Master

Marca única SM em verde sobre fundo escuro, com referência circular ao futebol. Gerada pela ferramenta de imagens integrada e aplicada ao painel e ao launcher Android. Os dois arquivos PNG são idênticos. O ícone adaptativo usa esse mesmo desenho; a forma externa é aplicada pelo launcher.

Prompt final: marca quadrada geométrica para Score Master, monograma SM integrado a um motivo de futebol, verde #18B777 sobre #0D1414, desenho central com margem para máscaras Android, sem palavras adicionais, sem mockup e sem símbolos financeiros. A imagem gerada tem leve variação tonal; não é um arquivo vetorial.

Arquivos: dist/assets/score-master-logo.png e android/app/src/main/res/drawable-nodpi/score_master_logo.png.
