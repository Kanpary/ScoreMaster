# Configuração real e geração Android

## Estrutura

Extraia `ScoreMaster/`: é a raiz Android importável, com `app/`, `domain/`, `gradle/`, `gradlew`, `gradlew.bat`, `settings.gradle.kts` e `build.gradle.kts`. `firebase/functions/` contém backend; `dist/` contém painel.

Pacote `com.scoremaster.app`, minSdk 23, compile/target 36, Java 17 e Functions `us-central1`. O SDK e dependências precisam existir ou estar acessíveis no ambiente de compilação.

## Pelo navegador do celular

1. Envie o conteúdo de `ScoreMaster/` à raiz de um repositório privado e conecte ao Codemagic. Repositório e conta de compilação não foram criados neste trabalho. `codemagic.yaml` já usa os caminhos da raiz.
2. Registre Android `com.scoremaster.app` no seu projeto Firebase real. Baixe `google-services.json`, ative Email/Password, configure Firestore e Storage.
3. No Codemagic, configure grupo `score_master_firebase` com `GOOGLE_SERVICES_JSON` (conteúdo real completo) e `FIREBASE_PROJECT_ID` (ID do mesmo projeto). O workflow restaura o arquivo em `app/` e valida correspondência.
4. Configure sua chave permanente Android com referência `score_master_release`. Gradle consome `CM_KEYSTORE_PATH`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS` e `CM_KEY_PASSWORD`. Não envie a chave ou senhas ao Git. Se não possui chave, esse requisito precisa ser resolvido antes de release; não há assinatura descartável incluída.
5. Licenças Android devem estar aceitas pelo responsável no ambiente. O workflow não aceita licenças automaticamente.
6. Execute **Score Master - Release assinado**. Somente após sucesso baixe APK, hash SHA-256, AAB e relatórios em Artifacts. Esse workflow não foi executado aqui; build não comprova funcionamento no aparelho.

## Implantação Firebase: etapa separada

Compilar APK não implanta o servidor. Em ambiente de desenvolvimento na nuvem aberto pelo navegador do celular, use Node 22, Firebase CLI autenticado com conta autorizada, JSON real em `app/` e variável `FIREBASE_PROJECT_ID` real. Na raiz:

```sh
node scripts/check-firebase-config.mjs
node scripts/prepare-firebase-project.mjs
cd firebase/functions
npm ci
npm run typecheck
npm test
cd ../..
firebase deploy --only firestore:rules,firestore:indexes,storage,functions,hosting
```

O script prepare gera `.firebaserc` lendo o ID do arquivo fornecido. Não cria contas nem executa deploy. Configure serviços/permissões necessários na sua conta. Se houver implantação anterior, revise remoção da função obsoleta `sendNotificationCampaign`.

Promova uma conta administrativa com e-mail verificado e custom claim `admin: true` apenas via Firebase Admin SDK em ambiente confiável. Nenhuma conta foi promovida aqui. Registre um aplicativo Web no mesmo projeto e insira o JSON público no console servido por HTTPS. Não insira credencial de serviço no navegador.

Crie categorias iniciais no painel, confira conteúdo/destinos HTTPS e publique configuração. O aplicativo vazio não gera usuários, palpites, resultados ou notificações fictícios. Agendamentos dependem de Scheduler implantado.

## Assinatura local opcional

Em ambiente privado com SDK, copie `signing.properties.example` para `signing.properties` e preencha sua chave permanente. `storeFile` aceita caminho absoluto ou relativo à raiz; variáveis CI têm prioridade. Release sem Firebase real ou chave própria é bloqueado.

## Validação antes de distribuir

O workflow verifica configuração, typecheck/testes backend/domínio, lint/build release, assinatura e hash. O teste instrumentado `RealFirebaseFlowTest` está incluído e exige execução em aparelho/emulador conectado com conta de QA verificada. Use `scripts/run-device-e2e.sh` em runner privado e configure as variáveis exigidas pelo script. Use **E2E-ACCEPTANCE.md** e consulte **VALIDATION.md** para os resultados e os limites efetivamente verificados.

## Workflows adicionais pelo navegador

- **Integração Firebase local**: Java 21/Node 22, regras e backend com emuladores. Os dados QA vivem apenas nos emuladores.
- **Implantar Firebase real**: execução manual; utiliza o grupo privado `score_master_firebase`, `FIREBASE_PROJECT_ID`, `GOOGLE_SERVICES_JSON` e `FIREBASE_DEPLOY_SERVICE_ACCOUNT_JSON`. A credencial deve pertencer ao projeto e ter somente as permissões necessárias para implantação. Nunca a inclua no repositório ou no painel Web. O workflow apaga sua cópia temporária.
- `SCORE_ADMIN_EMAIL` é opcional: só promove uma conta já existente, ativa e verificada. Nenhuma senha é armazenada no projeto. Ao promover, o script revoga sessões antigas; faça login novamente.

A implantação exige os serviços, permissões e faturamento habilitados pelo responsável. O código não cria uma conta de nuvem nem vincula pagamento. Publique no painel o conteúdo institucional verdadeiro e configure o aplicativo Web registrado no mesmo projeto.

O workflow de release produz um APK de produção assinado. A instrumentação usa um build de QA para verificar o código com uma conta dedicada; esse build não é o artefato destinado à distribuição.


Para um roteiro completo sem computador e com envio simplificado de dois arquivos ao repositório, leia COMECE-AQUI-ANDROID.md. O ZIP do projeto e o ZIP auxiliar de envio são entregues separadamente.
