# Configuração real e geração Android

## Estrutura

Extraia `ScoreMaster/`: é a raiz Android importável, com `app/`, `domain/`, `gradle/`, `gradlew`, `gradlew.bat`, `settings.gradle.kts` e `build.gradle.kts`. `firebase/functions/` contém backend; `dist/` contém painel.

Pacote `com.scoremaster.app`, minSdk 23, compile/target 36 e Java 17. O app é público; os favoritos e preferências ficam no aparelho. O painel administrativo usa Auth e grava diretamente no Firestore com uma conta verificada que tenha a custom claim `admin: true`.

## Pelo navegador do celular

1. Envie o conteúdo de `ScoreMaster/` à raiz de um repositório privado e conecte ao Codemagic. Repositório e conta de compilação não foram criados neste trabalho. `codemagic.yaml` já usa os caminhos da raiz.
2. Registre Android `com.scoremaster.app` no seu projeto Firebase real. Baixe `google-services.json`, crie Firestore e ative Email/Password apenas para o acesso administrativo. Não configure Storage, Functions ou Billing.
3. No Codemagic, configure grupo `score_master_firebase` com `GOOGLE_SERVICES_JSON` (conteúdo real completo) e `FIREBASE_PROJECT_ID` (ID do mesmo projeto). O workflow restaura o arquivo em `app/` e valida correspondência.
4. Configure sua chave permanente Android com referência `score_master_release`. Gradle consome `CM_KEYSTORE_PATH`, `CM_KEYSTORE_PASSWORD`, `CM_KEY_ALIAS` e `CM_KEY_PASSWORD`. Não envie a chave ou senhas ao Git. Se não possui chave, esse requisito precisa ser resolvido antes de release; não há assinatura descartável incluída.
5. Licenças Android devem estar aceitas pelo responsável no ambiente. O workflow não aceita licenças automaticamente.
6. Execute **Score Master - Release assinado**. Somente após sucesso baixe APK, hash SHA-256, AAB e relatórios em Artifacts. Esse workflow não foi executado aqui; build não comprova funcionamento no aparelho.

## Implantação Firebase: etapa separada

Compilar APK não implanta as regras nem o painel. O workflow **Score Master - Implantar Firebase real** implanta apenas regras/índices Firestore e Hosting; não implanta Cloud Functions nem Storage. Assim, não exige Blaze. Configure uma conta de serviço autorizada e o JSON real em `score_master_firebase`.

```sh
node scripts/check-firebase-config.mjs
node scripts/prepare-firebase-project.mjs
firebase deploy --only firestore:rules,firestore:indexes,hosting
```

O script prepare gera `.firebaserc` lendo o ID do arquivo fornecido. Não cria contas nem executa deploy. Configure serviços/permissões necessários na sua conta. Se houver implantação anterior, revise remoção da função obsoleta `sendNotificationCampaign`.

Crie no Firebase Authentication uma única conta de e-mail/senha para você, confirme o e-mail e configure `SCORE_ADMIN_EMAIL` no grupo protegido do Codemagic para o workflow conceder a claim `admin: true`. Nenhuma senha fica no repositório. Registre um aplicativo Web no mesmo projeto e insira o JSON público no painel Hosting. Nunca insira credencial de serviço no navegador.

Crie as categorias iniciais e confira/publica conteúdo no painel. O app não gera dados fictícios. A escrita direta no Firestore é protegida pela claim administrativa, mas a validação e o histórico de auditoria do antigo backend não estão disponíveis sem Functions.

## Assinatura local opcional

Em ambiente privado com SDK, copie `signing.properties.example` para `signing.properties` e preencha sua chave permanente. `storeFile` aceita caminho absoluto ou relativo à raiz; variáveis CI têm prioridade. Release sem Firebase real ou chave própria é bloqueado.

## Validação antes de distribuir

O workflow verifica configuração, typecheck/testes backend/domínio, lint/build release, assinatura e hash. O teste instrumentado `RealFirebaseFlowTest` está incluído e exige execução em aparelho/emulador conectado com conta de QA verificada. Use `scripts/run-device-e2e.sh` em runner privado e configure as variáveis exigidas pelo script. Use **E2E-ACCEPTANCE.md** e consulte **VALIDATION.md** para os resultados e os limites efetivamente verificados.

## Workflows adicionais pelo navegador

- **Integração Firebase local**: Java 21/Node 22, regras e backend com emuladores. Os dados QA vivem apenas nos emuladores.
- **Implantar Firebase real**: execução manual; utiliza o grupo privado `score_master_firebase`, `FIREBASE_PROJECT_ID`, `GOOGLE_SERVICES_JSON` e `FIREBASE_DEPLOY_SERVICE_ACCOUNT_JSON`. A credencial deve pertencer ao projeto e ter somente as permissões necessárias para implantação. Nunca a inclua no repositório ou no painel Web. O workflow apaga sua cópia temporária.
- `SCORE_ADMIN_EMAIL` identifica a conta administrativa existente, ativa e verificada. Nenhuma senha é armazenada no projeto. Ao promover, o script revoga sessões antigas; entre novamente no painel.

A solução deixa de fora cadastro/login de usuários, estatísticas pessoais, notificações push/campanhas, upload de imagens, agendamento de publicações e histórico de auditoria no servidor. Favoritos e preferências ficam neste aparelho. O painel ainda permite gerenciar palpites, categorias e configuração visual. Firestore/Auth/Hosting têm cotas gratuitas sujeitas aos limites atuais do Firebase; o workflow não altera o plano nem adiciona pagamento.

O workflow de release produz um APK de produção assinado. A instrumentação usa um build de QA para verificar o código com uma conta dedicada; esse build não é o artefato destinado à distribuição.


Para um roteiro completo sem computador e com envio simplificado de dois arquivos ao repositório, leia COMECE-AQUI-ANDROID.md. O ZIP do projeto e o ZIP auxiliar de envio são entregues separadamente.
