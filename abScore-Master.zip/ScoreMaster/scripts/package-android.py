#!/usr/bin/env python3
"""Build a source archive with Gradle modules directly at the project root."""
from pathlib import Path
import argparse
import json
import shutil
import tempfile
import zipfile

parser = argparse.ArgumentParser()
parser.add_argument("output", type=Path)
args = parser.parse_args()
source = Path(__file__).resolve().parents[1]
excluded_dirs = {".git", ".openai", ".gradle", ".firebase", "node_modules", "build", "lib", "__pycache__"}
excluded_names = {"local.properties", "google-services.json", "signing.properties", "key.properties", ".firebaserc", "firebase-deploy-credentials.json"}

def copy_tree(origin, destination):
    for item in origin.rglob("*"):
        relative = item.relative_to(origin)
        if any(part in excluded_dirs for part in relative.parts) or item.name in excluded_names:
            continue
        if item.is_file() and item.suffix.lower() not in {".jks", ".keystore", ".log"}:
            target = destination / relative
            target.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(item, target)

with tempfile.TemporaryDirectory(prefix="score-master-package-") as scratch:
    root = Path(scratch) / "ScoreMaster"
    root.mkdir()
    if (source / "android").is_dir():
        copy_tree(source / "android", root)
    else:
        for name in ["app", "domain", "gradle"]: copy_tree(source / name, root / name)
        for name in ["build.gradle.kts", "settings.gradle.kts", "gradle.properties", "gradlew", "gradlew.bat", "signing.properties.example"]: shutil.copy2(source / name, root / name)
    for name in ["firebase", "dist", "scripts", "branding", "evidence"]:
        if (source / name).exists(): copy_tree(source / name, root / name)
    for name in ["firebase.json", "firestore.rules", "firestore.indexes.json", ".gitignore", "ANDROID-SETUP.md", "VALIDATION.md", "README.md", "E2E-ACCEPTANCE.md", "COMECE-AQUI-ANDROID.md"]:
        shutil.copy2(source / name, root / name)
    workflow = (source / "codemagic.yaml").read_text()
    workflow = workflow.replace("$CM_BUILD_DIR/android/app", "$CM_BUILD_DIR/app").replace("$CM_BUILD_DIR/android/local", "$CM_BUILD_DIR/local").replace('cd "$CM_BUILD_DIR/android"', 'cd "$CM_BUILD_DIR"').replace("- android/", "- ")
    (root / "codemagic.yaml").write_text(workflow)
    required = ["app/src/main/AndroidManifest.xml", "app/build.gradle.kts", "domain/build.gradle.kts", "settings.gradle.kts", "build.gradle.kts", "gradlew", "gradlew.bat", "gradle/wrapper/gradle-wrapper.jar", "gradle/wrapper/gradle-wrapper.properties", "firebase/functions/package-lock.json", "codemagic.yaml"]
    for path in required:
        if not (root / path).is_file(): raise RuntimeError(f"Missing Android package component: {path}")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(args.output, "w", zipfile.ZIP_DEFLATED) as archive:
        for item in sorted(root.rglob("*")):
            if item.is_file(): archive.write(item, item.relative_to(root.parent))
    with zipfile.ZipFile(args.output) as archive:
        if archive.testzip() is not None: raise RuntimeError("ZIP integrity failed")
        if any(name.startswith("ScoreMaster/android/") for name in archive.namelist()): raise RuntimeError("Nested Android root")
    print(json.dumps({"archive": str(args.output.resolve()), "sizeBytes": args.output.stat().st_size, "requiredFiles": len(required), "zipIntegrity": "passed", "androidBuild": "not_validated"}))
