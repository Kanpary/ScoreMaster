import { readFileSync, existsSync } from 'node:fs';
const direct = new URL('../app/google-services.json', import.meta.url);
const nested = new URL('../android/app/google-services.json', import.meta.url);
const path = existsSync(direct) ? direct : nested;
if (!existsSync(path)) throw new Error('Adicione o google-services.json real em app/ antes de gerar release.');
const config = JSON.parse(readFileSync(path, 'utf8'));
const expectedProject = process.env.FIREBASE_PROJECT_ID;
if (!expectedProject) throw new Error('Configure FIREBASE_PROJECT_ID com o projeto de produção.');
if (config.project_info?.project_id !== expectedProject) throw new Error('Firebase do APK difere de FIREBASE_PROJECT_ID.');
const client = config.client?.find(item => item.client_info?.android_client_info?.package_name === 'com.scoremaster.app');
if (!client?.client_info?.mobilesdk_app_id || !client.api_key?.some(item => item.current_key)) {
  throw new Error('Configuração Android incompleta ou pacote diferente de com.scoremaster.app.');
}
console.log('Pacote Android e projeto Firebase correspondem à configuração fornecida.');
// This checks file consistency. It does not establish that backend functions are deployed.
