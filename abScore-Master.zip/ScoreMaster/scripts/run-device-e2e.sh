#!/usr/bin/env bash
set -euo pipefail
: "${ANDROID_SERIAL:?Selecione um aparelho/emulador autorizado}"
: "${SCORE_E2E_PROJECT_ID:?Informe o projeto Firebase de QA}"
: "${SCORE_E2E_EMAIL:?Informe a conta de QA verificada}"
: "${SCORE_E2E_PASSWORD:?Informe a senha pelo armazenamento privado do runner}"
: "${SCORE_E2E_PREDICTION_ID:?Informe um palpite publicado existente}"
: "${SCORE_E2E_CONSENT:?Defina true para autorizar alterações na conta de QA}"
test "$SCORE_E2E_CONSENT" = true
adb -s "$ANDROID_SERIAL" get-state
root=$(cd "$(dirname "$0")/.." && pwd)
if test -d "$root/android"; then cd "$root/android"; else cd "$root"; fi
chmod +x gradlew
./gradlew --no-daemon :app:connectedDebugAndroidTest \
  "-Pandroid.testInstrumentationRunnerArguments.e2eProjectId=$SCORE_E2E_PROJECT_ID" \
  "-Pandroid.testInstrumentationRunnerArguments.e2eEmail=$SCORE_E2E_EMAIL" \
  "-Pandroid.testInstrumentationRunnerArguments.e2ePassword=$SCORE_E2E_PASSWORD" \
  "-Pandroid.testInstrumentationRunnerArguments.e2ePredictionId=$SCORE_E2E_PREDICTION_ID" \
  "-Pandroid.testInstrumentationRunnerArguments.e2eConsent=true"
