// Uses only the real downloaded Firebase configuration; does not create accounts or deploy.
import { readFileSync, existsSync, writeFileSync } from 'node:fs';
const root = new URL('../', import.meta.url);
const direct = new URL('app/google-services.json', root);
const nested = new URL('android/app/google-services.json', root);
const config = JSON.parse(readFileSync(existsSync(direct) ? direct : nested, 'utf8'));
const project = config.project_info?.project_id;
if (typeof project !== 'string' || !/^[a-z][a-z0-9-]{4,28}[a-z0-9]$/.test(project)) throw new Error('ID do projeto Firebase inválido.');
if (process.env.FIREBASE_PROJECT_ID && process.env.FIREBASE_PROJECT_ID !== project) throw new Error('O arquivo Android e o projeto de implantação diferem.');
if (!config.client?.some(item => item.client_info?.android_client_info?.package_name === 'com.scoremaster.app')) throw new Error('Pacote Android incompatível.');
writeFileSync(new URL('.firebaserc', root), JSON.stringify({projects: {default: project}}, null, 2) + '\n');
console.log('Projeto Firebase selecionado a partir do google-services.json fornecido. Nenhum deploy foi executado.');
