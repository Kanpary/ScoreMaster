# Aceite no Firebase e Android

Esta lista deve ser executada com o Firebase e o aparelho de destino. A compilação verde não comprova que o projeto Firebase contém conteúdo nem que o app foi instalado no aparelho.

| Fluxo | Evidência necessária |
|---|---|
| Leitura pública | Abrir o app sem conta; visualizar feed, categorias, pesquisa, filtros e detalhes publicados. |
| Favoritos | Marcar/remover favorito, fechar/reabrir app, conferir em salvos; confirmar que não sincroniza para outro aparelho. |
| Preferências | Trocar idioma e tema, reiniciar e conferir persistência local. |
| Conteúdo real | Criar rascunho no painel, publicar e conferir no app; atualizar resultado e confirmar a atualização do Firestore. |
| Painel seguro | Conta administrativa verificada com claim `admin` consegue editar; conta comum e visitante não conseguem escrever no Firestore. |
| Categorias | Criar/editar/ativar/arquivar categoria e verificar filtro no app. |
| Editor | Salvar/publicar configuração visual e confirmar atualização no app. |
| Rede | Testar conexão lenta/ausente, atualização, reinício, tela pequena e fonte ampliada. |
| Release | Validar assinatura, SHA-256, instalação/atualização e Firebase correto no APK. |

Não teste com uma conta de usuário visitante: esta edição não oferece contas. Favoritos são locais e serão perdidos se os dados do aplicativo forem apagados. Push, Storage, histórico de auditoria e validações do antigo backend não são aceites desta edição.

A instrumentação `RealFirebaseFlowTest` usa o Firebase real indicado por argumentos do runner e exige um ID de palpite publicado de QA. Ela não deve usar credenciais pessoais nem alterar dados de produção. Registre aparelho/Android, projeto, versão do APK e evidências; não declare teste concluído sem executá-lo.
