# Aceite no aparelho e Firebase real

Checklist ainda não executado. Use duas contas comuns verificadas e uma administrativa no projeto de destino. Registros criados para validação devem ser identificados e removidos/arquivados depois.

| Fluxo | Evidência necessária |
|---|---|
| Auth | Cadastro/e-mail, bloqueio não verificado, login, senha incorreta, redefinição e logout. |
| Segurança | Isolamento entre contas, acesso administrativo negado, cliente sem escrita de resultados/claims. |
| Palpites | Criar/editar/duplicar/publicar/arquivar e rejeitar alteração concorrente. |
| Categorias | Traduções, campos obrigatórios/tipos, ativar/arquivar e impedir categoria inativa. |
| Combinação | Estados independentes, conteúdo histórico salvo e resultados sincronizados por ID. |
| Salvos/estatísticas | Idempotência, paginação, resultado canônico e win/(win+loss), sem percentual fictício sem amostra. |
| Filtros | Datas/intervalos inválidos, busca/filtros no servidor, paginação e cache próprio da conta e carregar mais. |
| Editor | Upload, idiomas, rascunho/publicação/restauração, dois dispositivos, cache e rejeição de config inválida. |
| Agendamento | Publicação/arquivamento, fila e Scheduler com evidência real. |
| Notificações | Permissão/canais/preferências, próprio/todos, agendar/cancelar, inbox, destinos, falhas/retomada. |
| Conta | Preferências entre dispositivos, exportação e exclusão reautenticada com limpeza dos tokens/dados. |
| Android | Versões mínima/atual, teclado/cutout, rotação, rede ausente/lenta, reinício, fonte grande/leitor de tela. |
| Release | Lint/build, apksigner, SHA-256, instalação/atualização e Firebase correto. |

Registre APK/hash, projeto Firebase, aparelho/Android, data, passos e evidência por teste. Não distribua com falhas essenciais. Este arquivo não afirma aprovação desses testes.

## Automação incluída

`firebase/functions/integration/` exercita Auth/Firestore e chamadas reais do SDK Functions em ambiente local. `npm run test:integration` inclui a infraestrutura de eventos do emulador Functions; `test:integration:http` usa HTTP TCP local e invoca diretamente o processador de evento para validar sua transação. Essa segunda modalidade não valida entrega Eventarc.

`RealFirebaseFlowTest` usa os SDKs e serviços reais do projeto explicitamente informado. Verifica três idiomas, navegação, idempotência do salvamento, persistência após recriar a Activity e o denominador das estatísticas. Execute por `scripts/run-device-e2e.sh` com segredo privado e conta de QA, nunca com a conta pessoal do responsável. Não substitui os demais cenários de segurança, push, escala, rotação e release da tabela.
