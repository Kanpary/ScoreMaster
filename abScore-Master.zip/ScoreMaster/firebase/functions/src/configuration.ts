export const languages = ["pt-BR", "en", "es"] as const;
export const componentNames = ["header", "navigation", "footer", "predictionCard", "statisticsCard", "filters", "tabs", "menus", "login", "register", "details", "history", "settings", "support", "dialogs", "bottomSheets", "banners", "notifications", "text", "button", "field"] as const;
export const pageNames = ["home", "explore", "saved", "stats", "settings", "notifications", "login", "register", "detail"] as const;
export function object(value: unknown): value is Record<string, unknown> { return typeof value === "object" && value !== null && !Array.isArray(value); }
export function localized(value: unknown, max: number): boolean {
  return object(value) && languages.every(language => typeof value[language] === "string" && (value[language] as string).trim().length > 0 && (value[language] as string).length <= max);
}
export function validateStyle(style: unknown): boolean {
  if (!object(style)) return false;
  const colors = new Set(["background", "color", "borderColor"]);
  const numeric: Record<string, [number, number]> = { textSize: [10, 40], padding: [0, 48], margin: [0, 48], radius: [0, 48], borderWidth: [0, 4], elevation:[0,12], lineSpacing:[0,16] };
  return Object.entries(style).every(([key, value]) => {
    if (colors.has(key)) return typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value);
    if (key in numeric) return typeof value === "number" && Number.isFinite(value) && value >= numeric[key]![0] && value <= numeric[key]![1];
    if (key === "font") return ["sans-serif", "serif", "monospace", "sans-serif-condensed"].includes(String(value));
    if (key === "alignment") return ["start", "center", "end"].includes(String(value));
    if (key === "bold") return typeof value === "boolean";
    return false;
  });
}
export const protectedTextKeys = new Set(["disclaimer", "email_verification", "backend_missing", "auth_required", "pending", "won", "lost", "voided", "postponed", "cancelled"]);
function luminance(color: string): number {
  const rgb = [1, 3, 5].map(offset => parseInt(color.slice(offset, offset + 2), 16) / 255).map(channel => channel <= 0.04045 ? channel / 12.92 : ((channel + 0.055) / 1.055) ** 2.4);
  return rgb[0]! * 0.2126 + rgb[1]! * 0.7152 + rgb[2]! * 0.0722;
}
function contrast(background: string, foreground: string): number {
  const a = luminance(background), b = luminance(foreground);
  return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
}
export function allowedAssetUrl(value: unknown): boolean {
  if (typeof value !== "string" || value.length > 3000) return false;
  try { const url = new URL(value); return url.protocol === "https:" && !url.username && !url.password && ["firebasestorage.googleapis.com", "storage.googleapis.com"].includes(url.hostname); } catch { return false; }
}
export function validateConfiguration(config: unknown): string[] {
  if (!object(config)) return ["configuration"];
  const errors: string[] = [];
  if (config.schemaVersion !== 1) errors.push("schemaVersion");
  if (config.lightTheme !== undefined && (!object(config.lightTheme) || !Object.entries(config.lightTheme).every(([key,value]) => ["background","surface","line","ink","muted","accent"].includes(key) && typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value)))) errors.push("lightTheme");
  if (object(config.lightTheme) && typeof config.lightTheme.background === "string" && typeof config.lightTheme.ink === "string" && contrast(config.lightTheme.background,config.lightTheme.ink)<4.5) errors.push("lightTheme.contrast");
  if (config.themeSelectionEnabled !== undefined && typeof config.themeSelectionEnabled !== "boolean") errors.push("themeSelectionEnabled");
  if (config.documents !== undefined) {
    if (!object(config.documents) || !Object.entries(config.documents).every(([key,value]) => ["privacy","terms","about","contact"].includes(key) && object(value) && localized(value.title,200) && localized(value.body,20000))) errors.push("documents");
  }
  if (config.faq !== undefined && (!Array.isArray(config.faq) || config.faq.length>50 || !config.faq.every(entry=>object(entry) && typeof entry.id==="string" && /^[a-zA-Z0-9_-]{1,80}$/.test(entry.id) && localized(entry.question,500) && localized(entry.answer,5000)) || new Set(config.faq.map(entry=>entry.id)).size!==config.faq.length)) errors.push("faq");
  if (!object(config.theme) || !Object.entries(config.theme).every(([key, value]) => ["background", "surface", "line", "ink", "muted", "accent"].includes(key) && typeof value === "string" && /^#[0-9a-f]{6}$/i.test(value))) errors.push("theme");
  if (!object(config.components) || !Object.entries(config.components).every(([key, value]) => componentNames.includes(key as typeof componentNames[number]) && validateStyle(value))) errors.push("components");
  if (!object(config.texts) || Object.keys(config.texts).length > 300 || !Object.entries(config.texts).every(([key, value]) => /^[a-z][a-z0-9_]{0,79}$/.test(key) && localized(value, 2000))) errors.push("texts");
  if (!object(config.pages)) errors.push("pages");
  else for (const [page, blocks] of Object.entries(config.pages)) {
    if (!pageNames.includes(page as typeof pageNames[number]) || !Array.isArray(blocks) || blocks.length > 30) { errors.push(`pages.${page}`); continue; }
    const ids = new Set<string>();
    for (const block of blocks) {
      if (!object(block) || typeof block.id !== "string" || !/^[a-zA-Z0-9_-]{1,80}$/.test(block.id) || ids.has(block.id)) { errors.push(`pages.${page}.id`); continue; }
      ids.add(block.id);
      if (!["text", "button", "divider", "image"].includes(String(block.type)) || typeof block.visible !== "boolean" || !validateStyle(block.style)) errors.push(`pages.${page}.${block.id}`);
      if (!["divider", "image"].includes(String(block.type)) && !localized(block.text, 2000)) errors.push(`pages.${page}.${block.id}.text`);
      if (block.type === "image" && (!allowedAssetUrl(block.imageUrl) || !localized(block.accessibility, 500))) errors.push(`pages.${page}.${block.id}.image`);
      if (block.accessibility !== undefined && !localized(block.accessibility, 500)) errors.push(`pages.${page}.${block.id}.accessibility`);
      if (block.type === "button" && !(typeof block.action === "string" && (/^navigate:(home|explore|saved|stats|settings|notifications)$/.test(block.action) || block.action === "support:telegram"))) errors.push(`pages.${page}.${block.id}.action`);
    }
  }
  if (config.sections !== undefined) {
    const allowed = ["welcomeTitle","welcomeBody","sectionTitle","search","marketFilters","filterButton","filtersExplanation","predictionList"];
    if (!object(config.sections)) errors.push("sections");
    else for (const [page, entries] of Object.entries(config.sections)) {
      if (!pageNames.includes(page as typeof pageNames[number]) || !Array.isArray(entries) || entries.length > allowed.length || !entries.every(entry => object(entry) && allowed.includes(String(entry.id)) && typeof entry.visible === "boolean" && (entry.id !== "predictionList" || entry.visible === true)) || new Set(entries.map(entry => entry.id)).size !== entries.length) errors.push(`sections.${page}`);
    }
  }
  if (config.allowedHttpsHosts !== undefined && (!Array.isArray(config.allowedHttpsHosts) || config.allowedHttpsHosts.length > 30 || !config.allowedHttpsHosts.every(host => typeof host === "string" && /^(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}$/.test(host)))) errors.push("allowedHttpsHosts");
  if (config.images !== undefined && (!object(config.images) || Object.keys(config.images).length > 50 || !Object.entries(config.images).every(([key, value]) => /^[a-zA-Z0-9_-]{1,80}$/.test(key) && object(value) && allowedAssetUrl(value.url) && localized(value.alt, 500)))) errors.push("images");
  if (object(config.texts) && Object.keys(config.texts).some(key => protectedTextKeys.has(key))) errors.push("protectedTexts");
  if (object(config.theme) && typeof config.theme.background === "string" && typeof config.theme.ink === "string" && contrast(config.theme.background, config.theme.ink) < 4.5) errors.push("theme.contrast");
  if (object(config.components)) for (const [key, style] of Object.entries(config.components)) {
    if (object(style) && typeof style.background === "string" && typeof style.color === "string" && contrast(style.background, style.color) < 4.5) errors.push(`components.${key}.contrast`);
  }
  if (JSON.stringify(config).length > 180_000) errors.push("size");
  return errors;
}
