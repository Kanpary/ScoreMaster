import { allowedAssetUrl, localized, object } from "./configuration.js";
import { parseDecimalOdds, ResultStatus } from "./domain.js";
export const results = new Set<ResultStatus>(["pending","won","lost","voided","postponed","cancelled"]);
/** Keep the content saved by the user and synchronize only the result of matching legs. */
export function synchronizeSavedLegs(saved: unknown, canonical: unknown): unknown[] {
  if (!Array.isArray(saved)) return [];
  const current = new Map((Array.isArray(canonical) ? canonical : []).filter(object).map(leg => [leg.id, leg.resultStatus]));
  return saved.map(leg => object(leg) ? { ...leg, resultStatus: results.has(current.get(leg.id) as ResultStatus) ? current.get(leg.id) : leg.resultStatus ?? "pending" } : leg);
}
export function validateExtraFields(fields: unknown, schema: unknown): string[] {
  if (!object(fields) || !Array.isArray(schema)) return ["customFields"];
  const errors: string[] = [], keys = new Set<string>();
  for (const definition of schema) {
    if (!object(definition) || typeof definition.id !== "string") continue;
    const key = definition.id; keys.add(key); const value = fields[key];
    if (value === undefined || value === null || value === "") { if (definition.required) errors.push(key); continue; }
    if (definition.type === "number" && (typeof value !== "number" || !Number.isFinite(value))) errors.push(key);
    if (definition.type === "boolean" && typeof value !== "boolean") errors.push(key);
    if (definition.type === "text" && !localized(value, 1000)) errors.push(key);
  }
  if (Object.keys(fields).some(key => !keys.has(key))) errors.push("unknownFields");
  return errors;
}
export function normalizePredictionExtras(input: Record<string, unknown>, category: Record<string, unknown>): Record<string, unknown> {
  const customFields = input.customFields ?? {};
  const errors = validateExtraFields(customFields, category.fields ?? []);
  if (errors.length) throw new Error(`Campos da categoria inválidos: ${errors.join(", ")}`);
  if (!localized(input.selectionLocalized, 1000)) throw new Error("Seleção nos três idiomas obrigatória.");
  if (input.analysisLocalized !== undefined && !localized(input.analysisLocalized, 5000)) throw new Error("Análise incompleta nos três idiomas.");
  if (input.country !== undefined && (typeof input.country !== "string" || input.country.length > 100)) throw new Error("País inválido.");
  const extras: Record<string, unknown> = { customFields, selectionLocalized: input.selectionLocalized, country: input.country ?? "" };
  for(const key of ["homeLogoUrl","awayLogoUrl"]){if(input[key]!==undefined&&input[key]!==null&&input[key]!==""&&!allowedAssetUrl(input[key]))throw new Error("Escudo deve ser uma imagem válida do Storage.");extras[key]=input[key]||null;}
  if (input.analysisLocalized !== undefined) extras.analysisLocalized = input.analysisLocalized;
  if (input.sources !== undefined) {
    if (!Array.isArray(input.sources) || input.sources.length > 20 || !input.sources.every(url => typeof url === "string" && url.length < 2000 && url.startsWith("https://") && !new URL(url).username && !new URL(url).password)) throw new Error("Fontes devem ser URLs HTTPS.");
    extras.sources = input.sources;
  }
  if (input.legs !== undefined) {
    if (input.marketId !== "combined" || !Array.isArray(input.legs) || input.legs.length < 2 || input.legs.length > 20 || !input.legs.every(leg => object(leg) && typeof leg.id === "string" && /^[a-zA-Z0-9_-]{1,80}$/.test(leg.id) && localized(leg.selection, 1000) && results.has(leg.resultStatus as ResultStatus) && (leg.odds === undefined || parseDecimalOdds(leg.odds) !== null))) throw new Error("Pernas da combinação inválidas.");
    if (new Set(input.legs.map(leg => leg.id)).size !== input.legs.length) throw new Error("IDs de pernas repetidos.");
    extras.legs = input.legs;
  } else if (input.marketId === "combined") throw new Error("Combinada exige pelo menos duas pernas.");
  return extras;
}
