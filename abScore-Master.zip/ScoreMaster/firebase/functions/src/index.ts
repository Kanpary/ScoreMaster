import { requireUser, requireAdmin } from "./authorization.js";
import { predictionSearchTerms, normalizeSearch, predictionMatches } from "./search.js";
import { normalizePredictionExtras, synchronizeSavedLegs } from "./prediction-input.js";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { onDocumentUpdated } from "firebase-functions/v2/firestore";
import { localized, object, validateConfiguration } from "./configuration.js";
import { createHash } from "node:crypto";
import { initializeApp, getApps } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { FieldValue, FieldPath, Timestamp, getFirestore } from "firebase-admin/firestore";

import { HttpsError, onCall } from "firebase-functions/v2/https";
import { setGlobalOptions } from "firebase-functions/v2";
import { calculateStats, EditorialState, parseDecimalOdds, ResultStatus, validatePrediction } from "./domain.js";

if (!getApps().length) initializeApp();
setGlobalOptions({ region: "us-central1", maxInstances: 10, timeoutSeconds: 60, memory: "256MiB" });
const db = getFirestore();
const authAdmin = getAuth();
const validResults = new Set<ResultStatus>(["pending", "won", "lost", "voided", "postponed", "cancelled"]);
const publicSnapshotFields = ["homeTeam", "awayTeam", "homeLogoUrl", "awayLogoUrl", "competition", "country", "marketId", "marketName", "selection", "odds", "startsAt", "analysis", "resultStatus", "selectionLocalized", "analysisLocalized", "customFields", "legs", "sources"] as const;

function id(value: unknown, name = "id"): string {
  if (typeof value !== "string" || value.length < 1 || value.length > 128 || value.includes("/")) throw new HttpsError("invalid-argument", `${name} inválido.`);
  return value;
}
function safeError(error: unknown): never {
  if (error instanceof HttpsError) throw error;
  console.error("Score Master operation failed", error);
  throw new HttpsError("internal", "Não foi possível concluir a operação.");
}
async function rateLimit(uid: string, action: string, max = 60): Promise<void> {
  const ref = db.collection("rate_limits").doc(`${uid}_${action}`);
  await db.runTransaction(async (tx) => {
    const snap = await tx.get(ref);
    const now = Date.now();
    const start = snap.get("windowStart") as number | undefined;
    const count = snap.get("count") as number | undefined;
    if (start !== undefined && now - start < 60_000 && (count ?? 0) >= max) throw new HttpsError("resource-exhausted", "Muitas tentativas. Aguarde um minuto.");
    tx.set(ref, start !== undefined && now - start < 60_000 ? { windowStart: start, count: (count ?? 0) + 1 } : { windowStart: now, count: 1 });
  });
}
function writeAudit(uid: string, action: string, targetId: string, details: Record<string, unknown> = {}) {
  return db.collection("audit_logs").add({ actorUid: uid, action, targetId, details, createdAt: FieldValue.serverTimestamp() });
}
function snapshotOf(data: FirebaseFirestore.DocumentData): Record<string, unknown> {
  const out: Record<string, unknown> = {};
  for (const key of publicSnapshotFields) {
    if (data[key] === undefined) continue;
    out[key] = key === "startsAt" && data[key] instanceof Timestamp ? data[key].toMillis() : data[key];
  }
  return out;
}
function assertPrediction(input: Record<string, unknown>): asserts input is Record<string, unknown> {
  const errors = validatePrediction(input);
  if (errors.length) throw new HttpsError("invalid-argument", `Campos inválidos: ${errors.join(", ")}`);
}

export const savePrediction = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    await rateLimit(user.uid, "save", 120);
    const predictionId = id(request.data?.predictionId, "predictionId");
    const predictionRef = db.collection("predictions").doc(predictionId);
    const savedRef = db.collection("users").doc(user.uid).collection("saved_predictions").doc(predictionId);
    await db.runTransaction(async (tx) => {
      const [predictionSnap, savedSnap] = await Promise.all([tx.get(predictionRef), tx.get(savedRef)]);
      if (!predictionSnap.exists || predictionSnap.get("editorialState") !== "published") throw new HttpsError("not-found", "Esse palpite não está disponível.");
      if (savedSnap.exists) return;
      const data = predictionSnap.data()!;
      tx.create(savedRef, {
        predictionId,
        userId: user.uid,
        snapshot: snapshotOf(data),
        resultStatus: data.resultStatus ?? "pending",
        savedAt: FieldValue.serverTimestamp(),
      });
    });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const unsavePrediction = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    await rateLimit(user.uid, "unsave", 120);
    const predictionId = id(request.data?.predictionId, "predictionId");
    await db.collection("users").doc(user.uid).collection("saved_predictions").doc(predictionId).delete();
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const getSavedPredictions = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    const cursor = typeof request.data?.cursor === "string" ? request.data.cursor : undefined;
    let query = db.collection("users").doc(user.uid).collection("saved_predictions").orderBy("savedAt", "desc").limit(50);
    if (cursor) {
      const cursorSnap = await db.collection("users").doc(user.uid).collection("saved_predictions").doc(id(cursor)).get();
      if (cursorSnap.exists) query = query.startAfter(cursorSnap);
    }
    const page = await query.get();
    const currentPredictions = new Map<string, FirebaseFirestore.DocumentSnapshot>();
    const predictionRefs = page.docs.map((doc) => db.collection("predictions").doc(doc.id));
    for (let i = 0; i < predictionRefs.length; i += 100) {
      const current = await db.getAll(...predictionRefs.slice(i, i + 100));
      current.forEach((prediction) => currentPredictions.set(prediction.id, prediction));
    }
    const items = page.docs.map((doc) => {
      const canonical = currentPredictions.get(doc.id);
      const snapshot = (doc.get("snapshot") ?? {}) as Record<string, unknown>;
      return {
      predictionId: doc.id,
      snapshot: { ...snapshot, legs: synchronizeSavedLegs(snapshot.legs, canonical?.get("legs")), resultStatus: canonical?.get("resultStatus") ?? snapshot.resultStatus ?? "pending" },
      resultStatus: canonical?.get("resultStatus") ?? snapshot.resultStatus ?? "pending",
      savedAt: doc.get("savedAt")?.toMillis?.() ?? null,
      };
    });
    return { items, nextCursor: page.docs.length === 50 ? page.docs.at(-1)!.id : null };
  } catch (error) { return safeError(error); }
});

export const getPersonalStats = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    const saved = await db.collection("users").doc(user.uid).collection("saved_predictions").select("predictionId", "resultStatus").get();
    const statuses: ResultStatus[] = [];
    const savedStatusById = new Map(saved.docs.map((doc) => [doc.id, doc.get("resultStatus")]));
    const refs = saved.docs.map((doc) => db.collection("predictions").doc(doc.id));
    for (let i = 0; i < refs.length; i += 100) {
      const docs = await db.getAll(...refs.slice(i, i + 100));
      for (const doc of docs) {
        const status = doc.exists ? doc.get("resultStatus") : savedStatusById.get(doc.id);
        if (validResults.has(status as ResultStatus)) statuses.push(status as ResultStatus);
      }
    }
    return { ...calculateStats(statuses), updatedAt: Date.now() };
  } catch (error) { return safeError(error); }
});

export const getGlobalStats = onCall(async (request) => {
  try {
    await requireUser(request);
    const base = db.collection("predictions").where("editorialState", "==", "published");
    const [published, won, lost, pending] = await Promise.all([
      base.count().get(), base.where("resultStatus", "==", "won").count().get(),
      base.where("resultStatus", "==", "lost").count().get(), base.where("resultStatus", "==", "pending").count().get(),
    ]);
    const wins = won.data().count;
    const losses = lost.data().count;
    const waiting = pending.data().count;
    const sampleSize = wins + losses;
    const stats = {
      wins,
      losses,
      pending: waiting,
      excluded: Math.max(0, published.data().count - sampleSize - waiting),
      sampleSize,
      accuracyPercent: sampleSize === 0 ? null : Math.round((wins / sampleSize) * 1000) / 10,
    };
    return { ...stats, published: published.data().count, updatedAt: Date.now() };
  } catch (error) { return safeError(error); }
});

export const createPrediction = onCall(async (request) => {
  try {
    const actor = await requireAdmin(request);
    await rateLimit(actor.uid, "admin-write", 90);
    const input = request.data?.prediction as Record<string, unknown> | undefined;
    if (!input) throw new HttpsError("invalid-argument", "Palpite ausente.");
    assertPrediction(input);
    const category = await db.collection("market_categories").doc(id(input.marketId, "marketId")).get();
    if (!category.exists || category.get("active") !== true || category.get("archived") === true) throw new HttpsError("invalid-argument", "Selecione uma categoria ativa registrada.");
    if (category.get("rules.oddsRequired") === true && parseDecimalOdds(input.odds) === null) throw new HttpsError("invalid-argument", "Esta categoria exige uma odd positiva.");
    const ref = db.collection("predictions").doc();
    let extras: Record<string, unknown>;
    try { extras = normalizePredictionExtras(input, category.data()!); } catch (error) { throw new HttpsError("invalid-argument", (error as Error).message); }
    if (Array.isArray(extras.legs)) extras.legs = extras.legs.map(leg => ({ ...leg, resultStatus: "pending" }));
    const data: Record<string, unknown> = {
      ...extras,
      homeTeam: (input.homeTeam as string).trim(), awayTeam: (input.awayTeam as string).trim(),
      competition: (input.competition as string).trim(), marketId: (input.marketId as string).trim(),
      marketName: input.marketName, selection: (input.selection as string).trim(),
      startsAt: Timestamp.fromMillis(input.startsAtMillis as number),
      editorialState: "draft" satisfies EditorialState, resultStatus: "pending" satisfies ResultStatus,
      authorUid: actor.uid, createdAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(),
      version: 1,
    };
    data.searchTerms=predictionSearchTerms(data);
    if (input.odds !== undefined && input.odds !== null) data.odds = parseDecimalOdds(input.odds);
    if (typeof input.analysis === "string" && input.analysis.trim()) data.analysis = input.analysis.trim().slice(0, 5000);
    await ref.create(data);
    await writeAudit(actor.uid, "prediction.created", ref.id);
    return { predictionId: ref.id };
  } catch (error) { return safeError(error); }
});

export const publishPrediction = onCall(async (request) => {
  try {
    const actor = await requireAdmin(request);
    await rateLimit(actor.uid, "admin-write", 90);
    const predictionId = id(request.data?.predictionId, "predictionId");
    const ref = db.collection("predictions").doc(predictionId);
    await db.runTransaction(async (tx) => {
      const doc = await tx.get(ref);
      if (!doc.exists) throw new HttpsError("not-found", "Palpite não encontrado.");
      const data = doc.data()!;
      const category=await tx.get(db.collection("market_categories").doc(id(data.marketId)));
      if(category.get("active")!==true)throw new HttpsError("failed-precondition","Categoria inativa.");
      try{normalizePredictionExtras(data,category.data()!);}catch(error){throw new HttpsError("failed-precondition",(error as Error).message);}
      if(category.get("rules.oddsRequired")&&parseDecimalOdds(data.odds)===null)throw new HttpsError("failed-precondition","Odd obrigatória.");
      if (data.editorialState !== "draft" && data.editorialState !== "scheduled") throw new HttpsError("failed-precondition", "Somente rascunhos podem ser publicados.");
      const missing = ["homeTeam", "awayTeam", "competition", "marketId", "selection", "startsAt", "marketName"].filter((field) => data[field] === undefined || data[field] === null || data[field] === "");
      if (missing.length) throw new HttpsError("invalid-argument", `Campos obrigatórios: ${missing.join(", ")}`);
      tx.update(ref, { editorialState: "published", searchTerms:predictionSearchTerms(data), publishedAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(), version: (data.version ?? 0) + 1 });
      tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "prediction.published", targetId: predictionId, createdAt: FieldValue.serverTimestamp() });
    });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const setPredictionResult = onCall(async (request) => {
  try {
    const actor = await requireAdmin(request);
    await rateLimit(actor.uid, "admin-result", 30);
    const predictionId = id(request.data?.predictionId, "predictionId");
    const next = request.data?.resultStatus as ResultStatus;
    const reason = typeof request.data?.reason === "string" ? request.data.reason.trim().slice(0, 500) : "";
    if (!validResults.has(next)) throw new HttpsError("invalid-argument", "Resultado inválido.");
    if (!reason) throw new HttpsError("invalid-argument","Informe o motivo da alteração.");
    const ref = db.collection("predictions").doc(predictionId);
    await db.runTransaction(async (tx) => {
      const doc = await tx.get(ref);
      if (!doc.exists || doc.get("editorialState") !== "published") throw new HttpsError("not-found", "Palpite publicado não encontrado.");
      const previous = doc.get("resultStatus") ?? "pending";
      if (previous === next) return;
      tx.update(ref, { resultStatus: next, settledAt: ["won", "lost", "voided"].includes(next) ? FieldValue.serverTimestamp() : null, updatedAt: FieldValue.serverTimestamp(), version: (doc.get("version") ?? 0) + 1 });
      tx.set(db.collection("prediction_status_history").doc(), { predictionId, previousStatus: previous, newStatus: next, reason, actorUid: actor.uid, createdAt: FieldValue.serverTimestamp() });
      tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "prediction.result_changed", targetId: predictionId, details: { previous, next, reason }, createdAt: FieldValue.serverTimestamp() });
    });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const archivePrediction = onCall(async (request) => {
  try {
    const actor = await requireAdmin(request);
    await rateLimit(actor.uid, "admin-write", 90);
    const predictionId = id(request.data?.predictionId, "predictionId");
    const ref = db.collection("predictions").doc(predictionId);
    await db.runTransaction(async (tx) => {
      const doc = await tx.get(ref);
      if (!doc.exists) throw new HttpsError("not-found", "Palpite não encontrado.");
      tx.update(ref, { editorialState: "archived", archivedAt: FieldValue.serverTimestamp(), updatedAt: FieldValue.serverTimestamp(), version: (doc.get("version") ?? 0) + 1 });
      tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "prediction.archived", targetId: predictionId, createdAt: FieldValue.serverTimestamp() });
    });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const registerDeviceToken = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    await rateLimit(user.uid, "device-token", 30);
    const token = request.data?.token;
    const platform = request.data?.platform;
    if (typeof token !== "string" || token.length < 20 || token.length > 4096 || platform !== "android") throw new HttpsError("invalid-argument", "Token de dispositivo inválido.");
    const rawLanguage = typeof request.data?.language === "string" ? request.data.language : "pt-BR";
    const language = rawLanguage.startsWith("en") ? "en" : rawLanguage.startsWith("es") ? "es" : "pt-BR";
    const profileRef = db.collection("users").doc(user.uid);
    await db.runTransaction(async tx => {
      const profile = await tx.get(profileRef);
      tx.set(profileRef,{...(!profile.get("language")?{language}:{}),...(!profile.exists?{createdAt:FieldValue.serverTimestamp()}:{}),updatedAt:FieldValue.serverTimestamp()},{merge:true});
    });
    const hash = createHash("sha256").update(token).digest("hex");
    const owner = db.collection("device_owners").doc(hash);
    await db.runTransaction(async tx => {
      const previous = await tx.get(owner);
      const previousUid = previous.get("uid") as string | undefined;
      if (previousUid && previousUid !== user.uid) tx.delete(db.collection("users").doc(previousUid).collection("devices").doc(hash));
      tx.set(owner, { uid: user.uid, updatedAt: FieldValue.serverTimestamp() });
      tx.set(db.collection("users").doc(user.uid).collection("devices").doc(hash), { token, platform, language, updatedAt: FieldValue.serverTimestamp() });
    });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const unregisterDeviceToken = onCall(async request => {
  const user = await requireUser(request);
  await rateLimit(user.uid, "device-token", 30);
  const token = request.data?.token;
  if (typeof token !== "string" || token.length < 20 || token.length > 4096) throw new HttpsError("invalid-argument", "Token inválido.");
  const hash = createHash("sha256").update(token).digest("hex");
  await db.runTransaction(async tx => {
    const owner = db.collection("device_owners").doc(hash);
    const record = await tx.get(owner);
    if (record.get("uid") === user.uid) tx.delete(owner);
    tx.delete(db.collection("users").doc(user.uid).collection("devices").doc(hash));
  });
  return {ok:true};
});

export const requestAccountExport = onCall(async request => {
  const user=await requireUser(request),userRef=db.collection("users").doc(user.uid);
  const phase=request.data?.phase??"saved";
  if(!["saved","inbox"].includes(phase))throw new HttpsError("invalid-argument","Etapa inválida.");
  const cursor=request.data?.cursor? id(request.data.cursor):null;
  const cutoff=request.data?.cutoffMillis??Date.now();
  if(!Number.isSafeInteger(cutoff)||cutoff>Date.now()+60000||cutoff<0)throw new HttpsError("invalid-argument","Data inválida.");
  if(!request.data?.phase)await userRef.set({requests:{exportRequestedAt:FieldValue.serverTimestamp()}},{merge:true});
  const collection=phase==="saved"?"saved_predictions":"notification_inbox";
  let query=userRef.collection(collection).orderBy(FieldPath.documentId()).limit(25);if(cursor)query=query.startAfter(cursor);
  const page=await query.get();const records:Record<string,unknown>[]=[];let bytes=0,last=cursor,stopped=false;
  function serialize(value:unknown):unknown {
    if(value instanceof Timestamp)return value.toDate().toISOString();
    if(Array.isArray(value))return value.map(serialize);
    if(object(value))return Object.fromEntries(Object.entries(value).map(([key,item])=>[key,serialize(item)]));
    return value;
  }
  for(const record of page.docs){const data=record.data(),created=data.savedAt??data.createdAt;
    if(created instanceof Timestamp&&created.toMillis()>cutoff){last=record.id;continue;}
    const row={id:record.id,...serialize(data) as Record<string,unknown>};const size=Buffer.byteLength(JSON.stringify(row));
    if(bytes+size>350000&&records.length){stopped=true;break;}
    if(size>350000)throw new HttpsError("resource-exhausted","Registro excede o limite de exportação.");
    records.push(row);bytes+=size;last=record.id;
  }
  const more=stopped||page.size===25;
  const next=more?{phase,cursor:last,cutoffMillis:cutoff}:phase==="saved"?{phase:"inbox",cutoffMillis:cutoff}:null;
  const profile= !request.data?.phase ? await userRef.get():null;
  return {phase,records,next,header:profile?{exportedAt:new Date(cutoff).toISOString(),account:{uid:user.uid,email:user.account.email??null,emailVerified:user.account.emailVerified},profile:{language:profile.get("language")??"pt-BR",theme:profile.get("theme")??"system",preferences:profile.get("preferences")??{},createdAt:serialize(profile.get("createdAt")??null)}}:null};
});

export const deleteMyAccount = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    const authTime = Number(user.token.auth_time ?? 0) * 1000;
    if (Date.now() - authTime > 5 * 60_000) throw new HttpsError("failed-precondition", "Entre novamente antes de excluir a conta.");
    const userRef = db.collection("users").doc(user.uid);
    const collections = ["saved_predictions", "devices", "notification_inbox"];
    for (const name of collections) {
      while (true) {
        const page = await userRef.collection(name).limit(400).get();
        if (page.empty) break;
        if (name === "devices") {
          for (const device of page.docs) await db.runTransaction(async tx => {
            const owner = db.collection("device_owners").doc(device.id);
            if ((await tx.get(owner)).get("uid") === user.uid) tx.delete(owner);
            tx.delete(device.ref);
          });
        } else {
          const batch = db.batch(); page.docs.forEach((doc) => batch.delete(doc.ref)); await batch.commit();
        }
      }
    }
    await userRef.delete();
    const limits = await db.collection("rate_limits").where("__name__", ">=", `${user.uid}_`).where("__name__", "<", `${user.uid}_\uf8ff`).get();
    for (let i = 0; i < limits.docs.length; i += 400) {
      const batch = db.batch(); limits.docs.slice(i, i + 400).forEach(doc => batch.delete(doc.ref)); await batch.commit();
    }
    await authAdmin.deleteUser(user.uid);
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const markNotificationRead = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    const notificationId = id(request.data?.notificationId, "notificationId");
    const ref = db.collection("users").doc(user.uid).collection("notification_inbox").doc(notificationId);
    await ref.update({ readAt: FieldValue.serverTimestamp() });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const updateMyPreferences = onCall(async (request) => {
  try {
    const user = await requireUser(request);
    await rateLimit(user.uid, "preferences", 30);
    const language = request.data?.language;
    const notificationsEnabled = request.data?.notificationsEnabled;
    if (!["pt-BR", "en", "es"].includes(language)) throw new HttpsError("invalid-argument", "Idioma inválido.");
    const patch: Record<string, unknown> = { language, updatedAt: FieldValue.serverTimestamp() };
    const theme = request.data?.theme;
    if (theme !== undefined) {
      if (!["system","light","dark"].includes(theme)) throw new HttpsError("invalid-argument","Tema inválido.");
      patch.theme = theme;
    }
    if (notificationsEnabled !== undefined) {
      if (typeof notificationsEnabled !== "boolean") throw new HttpsError("invalid-argument", "Preferência inválida.");
      patch.preferences = { notificationsEnabled };
    }
    const categories = request.data?.categories;
    if (categories !== undefined) {
      if (!object(categories) || !Object.entries(categories).every(([key,value]) => ["general","predictions","results"].includes(key) && typeof value === "boolean")) throw new HttpsError("invalid-argument", "Categorias de notificação inválidas.");
      patch.preferences = { ...(patch.preferences as Record<string,unknown> ?? {}), categories };
    }
    await db.collection("users").doc(user.uid).set(patch, { merge: true });
    return { ok: true };
  } catch (error) { return safeError(error); }
});

export const upsertMarketCategory = onCall(async request => {
  try {
    const actor = await requireAdmin(request);
    await rateLimit(actor.uid, "category-write", 60);
    const input = request.data?.category;
    if (!object(input) || !localized(input.name, 120) || !localized(input.description, 1000) || !/^#[0-9a-f]{6}$/i.test(String(input.color)) || typeof input.active !== "boolean" || typeof input.archived !== "boolean" || !Number.isSafeInteger(input.order) || Number(input.order) < 0 || Number(input.order) > 10000 || !["ball", "clock", "flag", "chart", "layers"].includes(String(input.icon)) || !object(input.rules) || typeof input.rules.oddsRequired !== "boolean" || !Array.isArray(input.fields) || input.fields.length > 20 || !input.fields.every(f => object(f) && typeof f.id === "string" && /^[a-z][a-z0-9_]{0,39}$/.test(f.id) && localized(f.label, 120) && ["text", "number", "boolean"].includes(String(f.type)) && typeof f.required === "boolean")) throw new HttpsError("invalid-argument", "Categoria inválida ou traduções incompletas.");
    const categoryId = id(request.data?.categoryId, "categoryId");
    const ref = db.collection("market_categories").doc(categoryId);
    await db.runTransaction(async tx => {
      const current = await tx.get(ref);
      if (current.exists && current.get("version") !== request.data?.expectedVersion) throw new HttpsError("aborted", "Categoria alterada por outra sessão. Recarregue antes de salvar.");
      tx.set(ref, { name: input.name, description: input.description, color: input.color, icon: input.icon, rules: { oddsRequired: (input.rules as Record<string, unknown>).oddsRequired }, fields: input.fields, order: input.order, active: input.active && !input.archived, archived: input.archived, version: (current.get("version") ?? 0) + 1, updatedAt: FieldValue.serverTimestamp(), updatedBy: actor.uid });
      tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "category.saved", targetId: categoryId, createdAt: FieldValue.serverTimestamp() });
    });
    return { categoryId };
  } catch (error) { return safeError(error); }
});

export const saveFrontendDraft = onCall(async request => {
  try {
    const actor = await requireAdmin(request);
    await rateLimit(actor.uid, "frontend-draft", 30);
    const errors = validateConfiguration(request.data?.configuration);
    if (errors.length) throw new HttpsError("invalid-argument", `Configuração inválida: ${errors.join(", ")}`);
    const ref = db.collection("app_config_versions").doc();
    await ref.create({ state: "draft", configuration: request.data.configuration, createdBy: actor.uid, createdAt: FieldValue.serverTimestamp() });
    await writeAudit(actor.uid, "frontend.draft_created", ref.id);
    return { versionId: ref.id };
  } catch (error) { return safeError(error); }
});

export const publishFrontendVersion = onCall(async request => {
  try {
    const actor = await requireAdmin(request);
    const versionId = id(request.data?.versionId, "versionId");
    const ref = db.collection("app_config_versions").doc(versionId);
    const pointer = db.collection("app_config").doc("current");
    await db.runTransaction(async tx => {
      const [version, current] = await Promise.all([tx.get(ref), tx.get(pointer)]);
      if (!version.exists) throw new HttpsError("not-found", "Versão inexistente.");
      const errors = validateConfiguration(version.get("configuration"));
      if (errors.length) throw new HttpsError("failed-precondition", "Versão incompatível.");
      const expected = request.data?.expectedCurrentVersionId ?? null;
      if ((current.get("versionId") ?? null) !== expected) throw new HttpsError("aborted", "Uma nova versão foi publicada. Atualize o painel.");
      tx.update(ref, { state: "published", publishedAt: FieldValue.serverTimestamp() });
      tx.set(pointer, { versionId, configuration: version.get("configuration"), updatedAt: FieldValue.serverTimestamp() });
      tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "frontend.published_or_restored", targetId: versionId, previousVersionId: expected, createdAt: FieldValue.serverTimestamp() });
    });
    return { versionId };
  } catch (error) { return safeError(error); }
});

export { saveNotificationDraft, activateNotificationCampaign, cancelNotificationCampaign, processNotificationQueue, estimateNotificationAudience } from "./notifications.js";

export const initializeMarketCategories = onCall(async request => {
  const actor = await requireAdmin(request);
  const initial = [
    ["goals", "Over/Under Gols", "Over/Under Goals", "Más/Menos Goles"],
    ["ht-ft", "HT/FT", "HT/FT", "HT/FT"],
    ["both-score", "Ambas Marcam", "Both Teams to Score", "Ambos Marcan"],
    ["correct-score", "Placar Correto", "Correct Score", "Marcador Exacto"],
    ["corners", "Over/Under Escanteios", "Over/Under Corners", "Más/Menos Córners"],
    ["cards", "Over/Under Cartões", "Over/Under Cards", "Más/Menos Tarjetas"],
    ["handicap", "Handicap", "Handicap", "Hándicap"],
    ["odds-2", "Odd 2.00+", "Odds 2.00+", "Cuota 2.00+"],
    ["odds-10", "Odd 10.00+", "Odds 10.00+", "Cuota 10.00+"],
    ["draw", "Empate", "Draw", "Empate"],
    ["combined", "Combinada de Vários Mercados", "Multi-market Accumulator", "Combinada de Varios Mercados"],
  ];
  await db.runTransaction(async tx => {
    const refs = initial.map(category => db.collection("market_categories").doc(category[0]!));
    const docs = await Promise.all(refs.map(ref => tx.get(ref)));
    initial.forEach((category, order) => {
      if (docs[order]!.exists) return;
      tx.create(refs[order]!, { name: { "pt-BR": category[1], en: category[2], es: category[3] }, description: { "pt-BR": `Palpites para ${category[1]}.`, en: `Predictions for ${category[2]}.`, es: `Pronósticos para ${category[3]}.` }, order, active: true, archived: false, color: "#18b777", icon: "ball", fields: [], rules: { oddsRequired: category[0]!.startsWith("odds-") }, version: 1, updatedBy: actor.uid, updatedAt: FieldValue.serverTimestamp() });
    });
    tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "categories.initialized", createdAt: FieldValue.serverTimestamp() });
  });
  return { ok: true };
});

export const editPrediction = onCall(async request => {
  try {
    const actor = await requireAdmin(request);await rateLimit(actor.uid, "admin-write", 60);
    const predictionId = id(request.data?.predictionId), input = request.data?.prediction;
    if (!object(input)) throw new HttpsError("invalid-argument", "Palpite inválido.");
    assertPrediction(input);
    const category = await db.collection("market_categories").doc(id(input.marketId)).get();
    if (category.get("active") !== true) throw new HttpsError("invalid-argument", "Categoria inativa.");
    let extras: Record<string, unknown>;
    try { extras = normalizePredictionExtras(input, category.data()!); } catch (error) { throw new HttpsError("invalid-argument", (error as Error).message); }
    if (category.get("rules.oddsRequired") && parseDecimalOdds(input.odds) === null) throw new HttpsError("invalid-argument", "Odd obrigatória.");
    const ref = db.collection("predictions").doc(predictionId);
    await db.runTransaction(async tx => {
      const previous = await tx.get(ref);
      if (!previous.exists) throw new HttpsError("not-found", "Palpite inexistente.");
      if (previous.get("version") !== request.data?.expectedVersion) throw new HttpsError("aborted", "Palpite alterado por outra sessão. Recarregue.");
      if (previous.get("editorialState") === "published" && request.data?.confirmedPublishedEdit !== true) throw new HttpsError("failed-precondition", "Confirme a alteração de conteúdo já publicado.");
      const next: Record<string, unknown> = { ...extras, homeTeam: String(input.homeTeam).trim(), awayTeam: String(input.awayTeam).trim(), competition: String(input.competition).trim(), marketId: input.marketId, marketName: input.marketName, selection: String(input.selection).trim(), startsAt: Timestamp.fromMillis(Number(input.startsAtMillis)), odds: input.odds === undefined ? null : parseDecimalOdds(input.odds), updatedAt: FieldValue.serverTimestamp(), version: previous.get("version") + 1 };
      next.analysis = typeof input.analysis === "string" ? input.analysis.trim().slice(0, 5000) : "";
      next.analysisLocalized = extras.analysisLocalized ?? FieldValue.delete();
      next.sources = extras.sources ?? [];
      next.legs = extras.legs ?? [];
      next.searchTerms = predictionSearchTerms(next);
      // A content edit must never change results or erase saved historical snapshots.
      if (next.legs && Array.isArray(next.legs)) {
        const oldLegs = previous.get("legs") as Array<Record<string, unknown>> | undefined;
        next.legs = (next.legs as Array<Record<string, unknown>>).map(leg => ({ ...leg, resultStatus: oldLegs?.find(old => old.id === leg.id)?.resultStatus ?? "pending" }));
      }
      tx.update(ref, next);
      tx.set(db.collection("prediction_edit_history").doc(), { predictionId, actorUid: actor.uid, previous: snapshotOf(previous.data()!), createdAt: FieldValue.serverTimestamp() });
      tx.set(db.collection("audit_logs").doc(), { actorUid: actor.uid, action: "prediction.edited", targetId: predictionId, createdAt: FieldValue.serverTimestamp() });
    });return { predictionId };
  } catch (error) { return safeError(error); }
});

export const duplicatePrediction = onCall(async request => {
  try {
    const actor=await requireAdmin(request);await rateLimit(actor.uid,"admin-write",60);
    const original=await db.collection("predictions").doc(id(request.data?.predictionId)).get();
    if(!original.exists)throw new HttpsError("not-found","Palpite inexistente.");
    const data=snapshotOf(original.data()!);data.resultStatus="pending";
    if(Array.isArray(data.legs))data.legs=data.legs.map(leg=>({...leg,resultStatus:"pending"}));
    const ref=db.collection("predictions").doc();
    await ref.create({...data,searchTerms:predictionSearchTerms(data),editorialState:"draft",authorUid:actor.uid,version:1,startsAt:original.get("startsAt"),createdAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp(),duplicatedFrom:original.id});
    await writeAudit(actor.uid,"prediction.duplicated",ref.id);return {predictionId:ref.id};
  } catch(error){return safeError(error);}
});

export const schedulePrediction = onCall(async request => {
  try {
    const actor=await requireAdmin(request),ref=db.collection("predictions").doc(id(request.data?.predictionId));
    const start=request.data?.publishAtMillis,end=request.data?.unpublishAtMillis;
    if(!Number.isSafeInteger(start)||start<Date.now()||!Number.isSafeInteger(end)||end<=start)throw new HttpsError("invalid-argument","Período de publicação inválido.");
    await db.runTransaction(async tx=>{const current=await tx.get(ref);if(current.get("editorialState")!=="draft")throw new HttpsError("failed-precondition","Somente rascunho pode ser agendado.");
      tx.update(ref,{editorialState:"scheduled",publishAt:Timestamp.fromMillis(start),unpublishAt:Timestamp.fromMillis(end),updatedAt:FieldValue.serverTimestamp(),version:FieldValue.increment(1)});
      tx.set(db.collection("audit_logs").doc(),{actorUid:actor.uid,action:"prediction.scheduled",targetId:ref.id,createdAt:FieldValue.serverTimestamp()});});return {scheduled:true};
  }catch(error){return safeError(error);}
});

export const setCombinationLegResult = onCall(async request=>{
  try {
    const actor=await requireAdmin(request),ref=db.collection("predictions").doc(id(request.data?.predictionId)),legId=id(request.data?.legId),result=request.data?.resultStatus as ResultStatus;
    if(!validResults.has(result)||typeof request.data?.reason!=="string"||!request.data.reason.trim())throw new HttpsError("invalid-argument","Informe resultado e motivo.");
    await db.runTransaction(async tx=>{const current=await tx.get(ref);const legs=current.get("legs") as Array<Record<string,unknown>>|undefined;
      if(current.get("editorialState")!=="published"||!legs?.some(leg=>leg.id===legId))throw new HttpsError("not-found","Perna de combinação publicada não encontrada.");
      const previous=legs.find(leg=>leg.id===legId)!.resultStatus;
      tx.update(ref,{legs:legs.map(leg=>leg.id===legId?{...leg,resultStatus:result}:leg),updatedAt:FieldValue.serverTimestamp(),version:FieldValue.increment(1)});
      tx.set(db.collection("prediction_status_history").doc(),{predictionId:ref.id,legId,previousStatus:previous,newStatus:result,reason:request.data.reason.trim().slice(0,500),actorUid:actor.uid,createdAt:FieldValue.serverTimestamp()});});return {ok:true};
  }catch(error){return safeError(error);}
});

export const processPredictionSchedule = onSchedule({schedule:"every 1 minutes",maxInstances:1,timeoutSeconds:120},async()=>{
  const due=await db.collection("predictions").where("editorialState","==","scheduled").where("publishAt","<=",Timestamp.now()).limit(100).get();
  for(const item of due.docs)await db.runTransaction(async tx=>{const current=await tx.get(item.ref);if(current.get("editorialState")!=="scheduled")return;
    const category=await tx.get(db.collection("market_categories").doc(current.get("marketId")));
    let invalid=category.get("active")!==true;
    try{normalizePredictionExtras(current.data()!,category.data()??{});}catch{invalid=true;}
    if(category.get("rules.oddsRequired")&&parseDecimalOdds(current.get("odds"))===null)invalid=true;
    if(invalid){tx.update(item.ref,{editorialState:"draft",scheduleError:"Conteúdo ou categoria inválidos; revise antes de publicar.",updatedAt:FieldValue.serverTimestamp(),version:FieldValue.increment(1)});tx.set(db.collection("audit_logs").doc(),{action:"prediction.schedule_rejected",targetId:item.id,actorUid:"scheduler",createdAt:FieldValue.serverTimestamp()});return;}
    const expired=current.get("unpublishAt")?.toMillis?.()<=Date.now();
    tx.update(item.ref,{editorialState:expired?"archived":"published",searchTerms:predictionSearchTerms(current.data()!),publishedAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp(),version:FieldValue.increment(1)});
    tx.set(db.collection("audit_logs").doc(),{action:expired?"prediction.schedule_expired":"prediction.schedule_published",targetId:item.id,actorUid:"scheduler",createdAt:FieldValue.serverTimestamp()});});
  const expired=await db.collection("predictions").where("editorialState","==","published").where("unpublishAt","<=",Timestamp.now()).limit(100).get();
  for(const item of expired.docs)await db.runTransaction(async tx=>{const current=await tx.get(item.ref);if(current.get("editorialState")!=="published")return;
    tx.update(item.ref,{editorialState:"archived",archivedAt:FieldValue.serverTimestamp(),updatedAt:FieldValue.serverTimestamp(),version:FieldValue.increment(1)});tx.set(db.collection("audit_logs").doc(),{action:"prediction.schedule_archived",targetId:item.id,actorUid:"scheduler",createdAt:FieldValue.serverTimestamp()});});
});

export const getPredictionDetails = onCall(async request => {
  try {
    const user = await requireUser(request), predictionId = id(request.data?.predictionId);
    const [prediction, saved] = await Promise.all([db.collection("predictions").doc(predictionId).get(),db.collection("users").doc(user.uid).collection("saved_predictions").doc(predictionId).get()]);
    if (!prediction.exists && !saved.exists) throw new HttpsError("not-found", "Conteúdo indisponível.");
    if (prediction.get("editorialState") !== "published" && !saved.exists) throw new HttpsError("not-found", "Conteúdo indisponível.");
    const data = saved.exists ? (saved.get("snapshot") as Record<string, unknown>) : snapshotOf(prediction.data()!);
    const snapshot = { ...data, resultStatus: prediction.get("resultStatus") ?? saved.get("resultStatus") ?? "pending", legs: saved.exists ? synchronizeSavedLegs(data.legs, prediction.get("legs")) : data.legs ?? [] };
    let historyQuery = db.collection("prediction_status_history").where("predictionId","==",predictionId).orderBy("createdAt","desc").limit(50);
    if(request.data?.historyCursor){const cursor=await db.collection("prediction_status_history").doc(id(request.data.historyCursor)).get();if(!cursor.exists||cursor.get("predictionId")!==predictionId)throw new HttpsError("invalid-argument","Cursor inválido.");historyQuery=historyQuery.startAfter(cursor);}
    const history = await historyQuery.get();
    return { predictionId, snapshot, saved:saved.exists, archived: prediction.get("editorialState") !== "published", nextHistoryCursor:history.size===50?history.docs.at(-1)!.id:null, history: history.docs.map(doc=>({previousStatus:doc.get("previousStatus"),newStatus:doc.get("newStatus"),legId:doc.get("legId")??null,createdAtMillis:doc.get("createdAt")?.toMillis?.()??null})) };
  }catch(error){return safeError(error);}
});

export { listManagedUsers, setManagedUserDisabled, getAdministrativeOverview } from "./administration.js";

export const synchronizeSavedResults = onDocumentUpdated({document:"predictions/{predictionId}",retry:true,timeoutSeconds:540},async event => {
  const before=event.data?.before.data(),after=event.data?.after.data();if(!before||!after)return;
  const states=(value:unknown)=>Array.isArray(value)?value.map(leg=>[leg.id,leg.resultStatus]):[];
  if(before.resultStatus===after.resultStatus&&JSON.stringify(states(before.legs))===JSON.stringify(states(after.legs)))return;
  let cursor:FirebaseFirestore.QueryDocumentSnapshot|undefined;
  while(true){let query=db.collectionGroup("saved_predictions").where("predictionId","==",event.params.predictionId).orderBy(FieldPath.documentId()).limit(200);if(cursor)query=query.startAfter(cursor);
    const page=await query.get();if(page.empty)break;
    for(const saved of page.docs)await db.runTransaction(async tx=>{
      const [record,canonical]=await Promise.all([tx.get(saved.ref),tx.get(db.collection("predictions").doc(event.params.predictionId))]);
      if(!record.exists||!canonical.exists||(record.get("synchronizedVersion")??0)>=(canonical.get("version")??1))return;
      const snapshot=record.get("snapshot")??{},status=canonical.get("resultStatus")??"pending";
      tx.update(saved.ref,{resultStatus:status,snapshot:{...snapshot,resultStatus:status,legs:synchronizeSavedLegs(snapshot.legs,canonical.get("legs"))},synchronizedVersion:canonical.get("version")??1,synchronizedAt:FieldValue.serverTimestamp()});
    });
    cursor=page.docs.at(-1);if(page.size<200)break;
  }
});

export const unpublishPrediction = onCall(async request=>{
  const actor=await requireAdmin(request),ref=db.collection("predictions").doc(id(request.data?.predictionId));
  await db.runTransaction(async tx=>{const current=await tx.get(ref);if(current.get("editorialState")!=="published")throw new HttpsError("failed-precondition","O palpite não está publicado.");
    tx.update(ref,{editorialState:"draft",publishAt:FieldValue.delete(),unpublishAt:FieldValue.delete(),updatedAt:FieldValue.serverTimestamp(),version:FieldValue.increment(1)});
    tx.set(db.collection("audit_logs").doc(),{actorUid:actor.uid,action:"prediction.unpublished",targetId:ref.id,createdAt:FieldValue.serverTimestamp()});});return {ok:true};
});

export const listPublishedPredictions = onCall(async request=>{
  const user=await requireUser(request),filters=request.data?.filters??{};
  if(!object(filters)||JSON.stringify(filters).length>3000)throw new HttpsError("invalid-argument","Filtros inválidos.");
  for(const key of ["minimumOdds","maximumOdds","fromDate","untilDate"])if(filters[key]!==undefined&&(typeof filters[key]!=="number"||!Number.isFinite(filters[key])))throw new HttpsError("invalid-argument","Intervalo inválido.");
  const sorting=request.data?.sort??"kickoff";
  if(!["recent","kickoff","market"].includes(sorting))throw new HttpsError("invalid-argument","Ordem inválida.");
  const field=sorting==="recent"?"createdAt":sorting==="market"?"marketId":"startsAt";
  let query=db.collection("predictions").where("editorialState","==","published").orderBy(field,sorting==="recent"?"desc":"asc");
  const word=normalizeSearch(String(filters.search??"")).split(" ")[0];if(word)query=query.where("searchTerms","array-contains",word.slice(0,30));
  if(request.data?.cursor){const cursor=await db.collection("predictions").doc(id(request.data.cursor)).get();if(!cursor.exists)throw new HttpsError("aborted","Recarregue a lista: cursor removido.");query=query.startAfter(cursor);}
  const items:Record<string,unknown>[]=[];let last:FirebaseFirestore.QueryDocumentSnapshot|undefined,exhausted=false;
  for(let scan=0;scan<5&&items.length<50;scan++){
    const page=await query.limit(100).get();if(page.empty){exhausted=true;break;}
    for(const record of page.docs){last=record;if(predictionMatches(record.data(),filters))items.push({predictionId:record.id,snapshot:snapshotOf(record.data()!)});if(items.length===50)break;}
    if(items.length===50)break;if(page.size<100){exhausted=true;break;}query=query.startAfter(last!);
  }
  const refs=items.map(item=>db.collection("users").doc(user.uid).collection("saved_predictions").doc(item.predictionId as string));
  const saved=refs.length?await db.getAll(...refs):[];
  return {items,savedIds:saved.filter(record=>record.exists).map(record=>record.id),nextCursor:exhausted?null:last?.id??null,updatedAt:Date.now()};
});

export const backfillPredictionSearch = onCall({timeoutSeconds:240},async request=>{
  const actor=await requireAdmin(request);let query=db.collection("predictions").orderBy(FieldPath.documentId()).limit(200);
  if(request.data?.cursor)query=query.startAfter(id(request.data.cursor));const page=await query.get();const batch=db.batch();
  for(const item of page.docs)batch.update(item.ref,{searchTerms:predictionSearchTerms(item.data())});await batch.commit();
  await writeAudit(actor.uid,"prediction.search_indexed",page.docs.at(-1)?.id??"empty",{records:page.size});
  return {count:page.size,nextCursor:page.size===200?page.docs.at(-1)!.id:null};
});
