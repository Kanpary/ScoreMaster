import test from "node:test";
import assert from "node:assert/strict";
import { validateExtraFields, normalizePredictionExtras, synchronizeSavedLegs } from "./prediction-input.js";
const texts = { "pt-BR":"Seleção", en:"Selection", es:"Selección" };
test("market-specific required fields reject incorrect types and unknown keys",()=>{
  const schema=[{id:"threshold",type:"number",required:true}];
  assert.deepEqual(validateExtraFields({threshold:2.5},schema),[]);
  assert.deepEqual(validateExtraFields({},schema),["threshold"]);
  assert.deepEqual(validateExtraFields({threshold:"2.5"},schema),["threshold"]);
  assert.ok(validateExtraFields({threshold:2.5,role:"admin"},schema).includes("unknownFields"));
});
test("saved accumulator content survives edits while matching results synchronize",()=>{
  const saved=[{id:"first",selection:texts,resultStatus:"pending"},{id:"removed",selection:texts,resultStatus:"won"}];
  const canonical=[{id:"first",selection:{...texts,en:"Changed"},resultStatus:"lost"},{id:"new",resultStatus:"won"}];
  assert.deepEqual(synchronizeSavedLegs(saved,canonical),[{...saved[0],resultStatus:"lost"},saved[1]]);
  assert.equal(saved[0]!.resultStatus,"pending");
  assert.deepEqual(synchronizeSavedLegs(saved,undefined),saved);
});
test("accumulator legs retain independent statuses and require unique IDs",()=>{
  const input={marketId:"combined",selectionLocalized:texts,legs:[{id:"first",selection:texts,resultStatus:"won"},{id:"second",selection:texts,resultStatus:"pending"}]};
  assert.deepEqual(normalizePredictionExtras(input,{fields:[]}).legs,input.legs);
  assert.throws(()=>normalizePredictionExtras({...input,legs:[input.legs[0],input.legs[0]]},{fields:[]}));
  assert.throws(()=>normalizePredictionExtras({marketId:"combined",selectionLocalized:texts},{fields:[]}));
});
