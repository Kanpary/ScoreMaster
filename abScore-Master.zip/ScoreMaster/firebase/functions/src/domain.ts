export type ResultStatus = "pending" | "won" | "lost" | "voided" | "postponed" | "cancelled";
export type EditorialState = "draft" | "scheduled" | "published" | "archived";

export interface Stats {
  wins: number;
  losses: number;
  pending: number;
  excluded: number;
  sampleSize: number;
  accuracyPercent: number | null;
}

export function calculateStats(statuses: Iterable<ResultStatus>): Stats {
  let wins = 0;
  let losses = 0;
  let pending = 0;
  let excluded = 0;
  for (const status of statuses) {
    if (status === "won") wins++;
    else if (status === "lost") losses++;
    else if (status === "pending") pending++;
    else excluded++;
  }
  const sampleSize = wins + losses;
  return {
    wins,
    losses,
    pending,
    excluded,
    sampleSize,
    accuracyPercent: sampleSize === 0 ? null : Math.round((wins / sampleSize) * 1000) / 10,
  };
}

export function parseDecimalOdds(value: unknown): number | null {
  if (typeof value === "number") return Number.isFinite(value) && value > 0 ? value : null;
  if (typeof value !== "string") return null;
  const normalized = value.trim().replace(",", ".");
  if (!/^(?:0|[1-9]\d*)(?:\.\d{1,4})?$/.test(normalized)) return null;
  const parsed = Number(normalized);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : null;
}

export function validatePrediction(input: Record<string, unknown>): string[] {
  const required = ["homeTeam", "awayTeam", "competition", "marketId", "selection", "startsAtMillis"];
  const errors = required.filter((key) => {
    const value = input[key];
    return key === "startsAtMillis" ? typeof value !== "number" || !Number.isSafeInteger(value) || value < 0 || value > 253402300799999 : typeof value !== "string" || value.trim().length === 0;
  });
  const names = input.marketName;
  if (typeof names !== "object" || names === null ||
      !["pt-BR", "en", "es"].every((language) => {
        const label = (names as Record<string, unknown>)[language];
        return typeof label === "string" && label.trim().length > 0 && label.length <= 120;
      })) errors.push("marketName");
  for (const key of ["homeTeam", "awayTeam", "competition", "marketId", "selection"]) {
    if (typeof input[key] === "string" && (input[key] as string).length > 300 && !errors.includes(key)) errors.push(key);
  }
  if (typeof input.marketId === "string" && input.marketId.includes("/") && !errors.includes("marketId")) errors.push("marketId");
  if (input.odds !== undefined && input.odds !== null && parseDecimalOdds(input.odds) === null) errors.push("odds");
  return errors;
}
