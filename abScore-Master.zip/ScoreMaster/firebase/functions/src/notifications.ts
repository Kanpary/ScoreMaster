import { requireAdmin as admin } from "./authorization.js";
import { getFirestore, FieldValue, FieldPath, Timestamp } from "firebase-admin/firestore";
import { getMessaging } from "firebase-admin/messaging";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { onSchedule } from "firebase-functions/v2/scheduler";
import { randomUUID } from "node:crypto";
import { allowedAssetUrl, localized, object } from "./configuration.js";
const database = () => getFirestore();
function identifier(value: unknown): string {
  if (typeof value !== "string" || !/^[a-zA-Z0-9_-]{1,128}$/.test(value)) throw new HttpsError("invalid-argument", "Identificador inválido.");
  return value;
}
export const saveNotificationDraft = onCall(async request => {
  const actor = await admin(request), input = request.data?.notification;
  if (!object(input) || !localized(input.title, 120) || !localized(input.body, 2000) || !["general", "predictions", "results"].includes(String(input.category)) || !["normal", "high"].includes(String(input.priority))) throw new HttpsError("invalid-argument", "Notificação inválida ou traduções incompletas.");
  let url: string | null = null;
  if (input.url) {
    try {
      const target = new URL(String(input.url));
      const configuration = await database().collection("app_config").doc("current").get();
      const hosts = configuration.get("configuration.allowedHttpsHosts") as string[] | undefined;
      if (target.protocol !== "https:" || target.username || target.password || !(hosts ?? ["t.me"]).includes(target.hostname)) throw new Error();
      url = target.toString();
    } catch { throw new HttpsError("invalid-argument", "URL não autorizada pela configuração publicada."); }
  }
  if (input.imageUrl && !allowedAssetUrl(input.imageUrl)) throw new HttpsError("invalid-argument", "Imagem inválida. Use um upload do Storage.");
  const screen = input.screen ?? "notifications";
  if (!["home","explore","saved","stats","settings","notifications"].includes(String(screen))) throw new HttpsError("invalid-argument", "Tela de destino inválida.");
  const predictionId = input.predictionId ? identifier(input.predictionId) : null;
  if (predictionId) {
    const prediction = await database().collection("predictions").doc(predictionId).get();
    if (prediction.get("editorialState") !== "published") throw new HttpsError("invalid-argument", "Destino não é um palpite publicado.");
  }
  const ref = database().collection("notification_campaigns").doc();
  for (const language of ["pt-BR", "en", "es"]) {
    const payload = { campaignId: ref.id, recipientUid: "x".repeat(128), title: (input.title as Record<string, string>)[language], body: (input.body as Record<string, string>)[language], category: input.category, screen, ...(url ? {url} : {}), ...(input.imageUrl ? {imageUrl: input.imageUrl} : {}), ...(predictionId ? {predictionId} : {}) };
    // Reserve room for transport keys; long URLs and multibyte text must fit together.
    if (Buffer.byteLength(JSON.stringify(payload), "utf8") > 3500) throw new HttpsError("invalid-argument", "Texto e URLs excedem o limite seguro do push. Reduza o conteúdo.");
  }
  await ref.create({ title: input.title, body: input.body, category: input.category, priority: input.priority, predictionId, url, imageUrl: input.imageUrl ?? null, screen, status: "draft", createdBy: actor.uid, createdAt: FieldValue.serverTimestamp(), processedUsers: 0 });
  return { campaignId: ref.id };
});
export const estimateNotificationAudience = onCall({timeoutSeconds:240},async request=>{
  await admin(request);const category=request.data?.category;
  if(!["general","predictions","results"].includes(category))throw new HttpsError("invalid-argument","Categoria inválida.");
  let cursor:FirebaseFirestore.QueryDocumentSnapshot|undefined,users=0,devices=0;
  while(true){let query=database().collection("users").orderBy(FieldPath.documentId()).limit(100);if(cursor)query=query.startAfter(cursor);const page=await query.get();if(page.empty)break;
    const counts=await Promise.all(page.docs.map(async user=>{if(user.get("disabled")===true||user.get("preferences.notificationsEnabled")===false||user.get(`preferences.categories.${category}`)===false)return 0;return (await user.ref.collection("devices").count().get()).data().count;}));
    for(const count of counts)if(count){users++;devices+=count;}cursor=page.docs.at(-1);if(page.size<100)break;
  }return {eligibleUsers:users,registeredDevices:devices,queriedAt:Date.now(),note:"Registered tokens; FCM delivery is not guaranteed"};
});
export const activateNotificationCampaign = onCall(async request => {
  const actor = await admin(request), ref = database().collection("notification_campaigns").doc(identifier(request.data?.campaignId));
  const audience = request.data?.audience;
  if (!["all", "self"].includes(audience)) throw new HttpsError("invalid-argument", "Público inválido.");
  if (audience === "all" && request.data?.confirmedToAll !== true) throw new HttpsError("failed-precondition", "Confirme o envio para todos.");
  const time = request.data?.sendAtMillis ?? Date.now();
  if (typeof time !== "number" || !Number.isSafeInteger(time) || time < Date.now() - 60000 || time > Date.now() + 366 * 86400000) throw new HttpsError("invalid-argument", "Data inválida.");
  await database().runTransaction(async tx => {
    const campaign = await tx.get(ref);
    if (campaign.get("status") !== "draft") throw new HttpsError("failed-precondition", "Somente rascunho pode iniciar um envio.");
    tx.update(ref, { status: time > Date.now() ? "scheduled" : "queued", sendAt: Timestamp.fromMillis(time), audience, targetUid: audience === "self" ? actor.uid : null, activatedBy: actor.uid, activatedAt: FieldValue.serverTimestamp() });
    tx.set(database().collection("audit_logs").doc(), { actorUid: actor.uid, action: "notification.activated", targetId: ref.id, audience, createdAt: FieldValue.serverTimestamp() });
  });
  return { campaignId: ref.id, queued: true };
});
export const cancelNotificationCampaign = onCall(async request => {
  const actor = await admin(request), ref = database().collection("notification_campaigns").doc(identifier(request.data?.campaignId));
  await database().runTransaction(async tx => {
    const campaign = await tx.get(ref);
    if (!["draft", "scheduled", "queued"].includes(campaign.get("status"))) throw new HttpsError("failed-precondition", "Um envio iniciado não pode ser desfeito.");
    tx.update(ref, { status: "cancelled", cancelledBy: actor.uid, cancelledAt: FieldValue.serverTimestamp() });
    tx.set(database().collection("audit_logs").doc(), { actorUid: actor.uid, action: "notification.cancelled", targetId: ref.id, createdAt: FieldValue.serverTimestamp() });
  });
  return { cancelled: true };
});
// Persistent queue drained in small pages. Locks prevent overlapping scheduler invocations.
export const processNotificationQueue = onSchedule({ schedule: "every 1 minutes", timeZone: "America/Sao_Paulo", timeoutSeconds: 300, maxInstances: 1, retryCount: 2 }, async () => {
  const campaigns = await database().collection("notification_campaigns").where("status", "in", ["queued", "scheduled", "processing"]).where("sendAt", "<=", Timestamp.now()).orderBy("sendAt").limit(5).get();
  for (const campaign of campaigns.docs) {
    const ref = campaign.ref, owner = randomUUID();
    const acquired = await database().runTransaction(async tx => {
      const latest = await tx.get(ref);
      if (!["queued", "scheduled", "processing"].includes(latest.get("status")) || Number(latest.get("leaseUntil") ?? 0) > Date.now()) return false;
      tx.update(ref, { status: "processing", leaseOwner: owner, leaseUntil: Date.now() + 330000 });return true;
    });
    if (!acquired) continue;
    try {
      const data = (await ref.get()).data()!;
      let users: FirebaseFirestore.DocumentSnapshot[];
      if (data.audience === "self") users = data.cursor ? [] : [await database().collection("users").doc(data.targetUid).get()];
      else {
        let query = database().collection("users").orderBy(FieldPath.documentId()).limit(10);
        if (data.cursor) query = query.startAfter(data.cursor);
        users = (await query.get()).docs;
      }
      for (const user of users) {
        if (user.exists && user.get("disabled") !== true && user.get("preferences.notificationsEnabled") !== false && user.get(`preferences.categories.${data.category}`) !== false) {
          const language = user.get("language") ?? "pt-BR", title = String(data.title[language] ?? data.title["pt-BR"]), body = String(data.body[language] ?? data.body["pt-BR"]);
          const inbox = user.ref.collection("notification_inbox").doc(campaign.id);
          await database().runTransaction(async tx => {
            if (!(await tx.get(inbox)).exists) tx.create(inbox, { campaignId: campaign.id, title, body, predictionId: data.predictionId, category: data.category, url: data.url ?? null, imageUrl: data.imageUrl ?? null, screen: data.screen ?? "notifications", createdAt: FieldValue.serverTimestamp(), readAt: null });
          });
          const devices = await user.ref.collection("devices").get();
          for (const device of devices.docs) {
            if (typeof device.get("token") !== "string") continue;
            const deviceLanguage = device.get("language") ?? language;
            const deviceTitle = String(data.title[deviceLanguage] ?? data.title["pt-BR"]);
            const deviceBody = String(data.body[deviceLanguage] ?? data.body["pt-BR"]);
            const delivery = ref.collection("deliveries").doc(`${user.id}_${device.id}`);
            const claimed = await database().runTransaction(async tx => {
              const previous = await tx.get(delivery);
              if (previous.exists) { if (previous.get("status") === "sending") tx.update(delivery, { status: "unknown", note: "Envio interrompido; não repetido automaticamente para evitar duplicação." });return false; }
              tx.create(delivery, { userId: user.id, status: "sending", createdAt: FieldValue.serverTimestamp() });return true;
            });
            if (!claimed) continue;
            let success = false;
            try {
              for (let attempt = 1; attempt <= 3; attempt++) {
                const result = await getMessaging().sendEachForMulticast({ tokens: [device.get("token")], data: { campaignId: campaign.id, recipientUid: user.id, title: deviceTitle, body: deviceBody, category: data.category, screen: data.screen ?? "notifications", ...(data.url ? {url:data.url} : {}), ...(data.imageUrl ? {imageUrl:data.imageUrl} : {}), ...(data.predictionId ? { predictionId: data.predictionId } : {}) }, android: { priority: data.priority === "high" ? "high" : "normal", collapseKey: campaign.id } });
                const response = result.responses[0]!;
                if (response.success) { success = true; await delivery.update({ status: "accepted_by_fcm", messageId: response.messageId ?? null, attempts: attempt, finishedAt: FieldValue.serverTimestamp() }); break; }
                const code = response.error?.code ?? "unknown";
                if (["messaging/registration-token-not-registered", "messaging/invalid-registration-token"].includes(code)) await database().runTransaction(async tx => { const owner=database().collection("device_owners").doc(device.id);const record=await tx.get(owner);if(record.get("uid")===user.id)tx.delete(owner);tx.delete(device.ref); });
                if (!["messaging/server-unavailable", "messaging/internal-error"].includes(code) || attempt === 3) { await delivery.update({ status: "failed", errorCode: code, attempts: attempt, finishedAt: FieldValue.serverTimestamp() }); break; }
                await new Promise(resolve => setTimeout(resolve, attempt * 1000));
              }
            } catch {
              await delivery.update({ status: "unknown", note: "Sem confirmação do provedor; push não repetido automaticamente.", finishedAt: FieldValue.serverTimestamp() });
            }
            if (success) await ref.update({ acceptedPushes: FieldValue.increment(1) });
          }
        }
        await ref.update({ cursor: user.id, processedUsers: FieldValue.increment(1) });
      }
      const finished = data.audience === "self" || users.length < 10;
      await database().runTransaction(async tx => {
        const latest = await tx.get(ref);if (latest.get("leaseOwner") !== owner) return;
        tx.update(ref, { status: finished ? "completed" : "processing", leaseUntil: 0, ...(finished ? { completedAt: FieldValue.serverTimestamp() } : {}) });
      });
    } catch (error) {
      console.error("Notification queue failed", campaign.id, error);
      await ref.update({ leaseUntil: 0, lastErrorAt: FieldValue.serverTimestamp() });
    }
  }
});
