import { getAuth, UserRecord } from "firebase-admin/auth";
import { FieldValue, getFirestore } from "firebase-admin/firestore";
import { HttpsError, onCall } from "firebase-functions/v2/https";
import { requireAdmin } from "./authorization.js";
export const listManagedUsers = onCall(async request => {
  await requireAdmin(request);
  const email = typeof request.data?.email === "string" ? request.data.email.trim() : "";
  const pageToken = request.data?.pageToken;
  if (pageToken !== undefined && (typeof pageToken !== "string" || pageToken.length > 2000)) throw new HttpsError("invalid-argument", "Cursor inválido.");
  let users: UserRecord[], nextPageToken: string | null = null;
  if (email) {
    if (email.length > 320) throw new HttpsError("invalid-argument", "E-mail inválido.");
    try { users = [await getAuth().getUserByEmail(email)]; } catch (error) { if ((error as {code?:string}).code === "auth/user-not-found") users = []; else throw error; }
  } else { const page = await getAuth().listUsers(50, pageToken); users = page.users; nextPageToken = page.pageToken ?? null; }
  const items = await Promise.all(users.map(async user => {
    const profile = await getFirestore().collection("users").doc(user.uid).get();
    return { uid: user.uid, email: user.email ?? null, emailVerified: user.emailVerified, disabled: user.disabled, admin: user.customClaims?.admin === true, createdAt: user.metadata.creationTime, lastSignInAt: user.metadata.lastSignInTime ?? null, language: profile.get("language") ?? null, preferences: profile.get("preferences") ?? {}, requests: profile.get("requests") ?? {} };
  }));
  return { items, nextPageToken, updatedAt: Date.now() };
});
export const setManagedUserDisabled = onCall(async request => {
  const actor = await requireAdmin(request), uid = request.data?.uid, disabled = request.data?.disabled;
  const reason = typeof request.data?.reason === "string" ? request.data.reason.trim().slice(0,500) : "";
  if (typeof uid !== "string" || uid.length > 128 || typeof disabled !== "boolean" || !reason) throw new HttpsError("invalid-argument", "Informe conta, estado e motivo.");
  const account = await getAuth().getUser(uid);
  if (uid === actor.uid || account.customClaims?.admin === true) throw new HttpsError("failed-precondition", "Contas administrativas são geridas pelo responsável no Firebase Console.");
  // Deny in rules first. If Auth fails, the protected profile remains disabled safely.
  await getFirestore().collection("users").doc(uid).set({ disabled: true, updatedAt: FieldValue.serverTimestamp() }, {merge:true});
  await getAuth().updateUser(uid,{disabled});
  if (disabled) await getAuth().revokeRefreshTokens(uid);
  await getFirestore().collection("users").doc(uid).set({ disabled, updatedAt: FieldValue.serverTimestamp() }, {merge:true});
  await getFirestore().collection("audit_logs").add({actorUid:actor.uid,action:disabled?"user.disabled":"user.enabled",targetId:uid,details:{reason},createdAt:FieldValue.serverTimestamp()});
  return {ok:true};
});
export const getAdministrativeOverview = onCall({timeoutSeconds:240},async request => {
  await requireAdmin(request);
  const since = Date.now()-30*86400000; let total=0,active=0,disabled=0,token: string|undefined;
  do { const page=await getAuth().listUsers(1000,token); for(const user of page.users){total++;if(user.disabled)disabled++;if(!user.disabled&&Date.parse(user.metadata.lastSignInTime??"")>=since)active++;}token=page.pageToken; } while(token);
  return {totalUsers:total,activeUsersLast30Days:active,disabledUsers:disabled,updatedAt:Date.now(),activityDefinition:"Firebase Auth last sign-in within 30 days"};
});
