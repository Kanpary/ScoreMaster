export function normalizeSearch(value: string): string { return value.normalize("NFD").replace(/[\u0300-\u036f]/g,"").toLowerCase().replace(/[^a-z0-9]+/g," ").trim(); }
export function predictionSearchTerms(data:Record<string,unknown>):string[]{
  const values=[data.homeTeam,data.awayTeam,data.competition,data.selection,...Object.values((data.selectionLocalized??{}) as Record<string,unknown>)];
  const result=new Set<string>();
  for(const value of values){if(typeof value!=="string")continue;for(const word of normalizeSearch(value).split(" "))for(let n=1;n<=Math.min(word.length,30);n++){result.add(word.slice(0,n));if(result.size>=500)return [...result];}}
  return [...result];
}
export function predictionMatches(data:Record<string,unknown>,filters:Record<string,unknown>):boolean{
  for(const field of ["marketId","resultStatus"])if(filters[field]&&data[field]!==filters[field])return false;
  if(typeof filters.competition==="string"&&!normalizeSearch(String(data.competition??"")).includes(normalizeSearch(filters.competition)))return false;
  const odds=typeof data.odds==="number"?data.odds:null;
  if(typeof filters.minimumOdds==="number"&&(odds===null||odds<filters.minimumOdds))return false;
  if(typeof filters.maximumOdds==="number"&&(odds===null||odds>filters.maximumOdds))return false;
  const timestamp=data.startsAt as {toMillis?:()=>number}|number;
  const start=typeof timestamp==="number"?timestamp:timestamp?.toMillis?.();
  if(typeof filters.fromDate==="number"&&(start===undefined||start<filters.fromDate))return false;
  if(typeof filters.untilDate==="number"&&(start===undefined||start>=filters.untilDate))return false;
  const text=normalizeSearch([data.homeTeam,data.awayTeam,data.competition,data.selection,...Object.values((data.selectionLocalized??{}) as Record<string,unknown>)].join(" "));
  return normalizeSearch(String(filters.search??"")).split(" ").filter(Boolean).every(word=>text.includes(word));
}
