import test from "node:test";
import assert from "node:assert/strict";
import { localized, validateConfiguration, validateStyle } from "./configuration.js";
const config = { schemaVersion: 1, theme: { background: "#0d1414" }, components: {}, texts: {}, pages: {} };
test("configuration accepts supported styles and localized safe blocks", () => {
  assert.deepEqual(validateConfiguration(config), []);
  assert.ok(validateStyle({ textSize: 18, color: "#ffffff", bold: true }));
  assert.ok(localized({ "pt-BR": "Nome", en: "Name", es: "Nombre" }, 20));
});
test("configuration rejects code, unsupported navigation, missing translations and duplicate blocks", () => {
  assert.equal(validateStyle({ javascript: "alert(1)" }), false);
  assert.equal(validateStyle({ textSize: 1 }), false);
  const block = { id: "button", type: "button", visible: true, style: {}, text: { "pt-BR": "Ir", en: "Go", es: "Ir" }, action: "javascript:alert(1)" };
  assert.ok(validateConfiguration({ ...config, pages: { home: [block] } }).some(e => e.endsWith("action")));
  assert.ok(validateConfiguration({ ...config, pages: { home: [block, block] } }).some(e => e.endsWith("id")));
  assert.ok(validateConfiguration({ ...config, texts: { home: { en: "Home" } } }).includes("texts"));
});

test("essential result/safety labels and readable contrast are protected", () => {
  assert.ok(validateConfiguration({ ...config, texts: { disclaimer: { "pt-BR": "x", en: "x", es: "x" } } }).includes("protectedTexts"));
  assert.ok(validateConfiguration({ ...config, theme: { background: "#000000", ink: "#000000" } }).includes("theme.contrast"));
  assert.ok(validateConfiguration({ ...config, components: { text: { background: "#ffffff", color: "#ffffff" } } }).includes("components.text.contrast"));
});
test("institutional documents FAQ and theme controls require complete safe content",()=>{
  const texts={"pt-BR":"Conteúdo",en:"Content",es:"Contenido"};
  const value={...config,documents:{terms:{title:texts,body:texts}},faq:[{id:"first",question:texts,answer:texts}],themeSelectionEnabled:true,lightTheme:{background:"#ffffff",ink:"#10251c"}};
  assert.deepEqual(validateConfiguration(value),[]);
  assert.ok(validateConfiguration({...value,documents:{terms:{title:texts,body:{en:"Incomplete"}}}}).includes("documents"));
  assert.ok(validateConfiguration({...value,lightTheme:{background:"#ffffff",ink:"#ffffff"}}).includes("lightTheme.contrast"));
  assert.ok(validateConfiguration({...value,faq:[value.faq[0],value.faq[0]]}).includes("faq"));
});
