import test from "node:test";
import assert from "node:assert/strict";
import { normalizeSearch, predictionSearchTerms, predictionMatches } from "./search.js";
test("search indexes localized accents and prefixes without unbounded terms",()=>{
  const value={homeTeam:"São Paulo",awayTeam:"Flamengo",selectionLocalized:{"pt-BR":"Acima de 2 gols",en:"Over 2 goals",es:"Más de 2 goles"}};
  assert.equal(normalizeSearch("São"),"sao");assert.ok(predictionSearchTerms(value).includes("flam"));assert.ok(predictionSearchTerms(value).includes("goals"));
  assert.ok(predictionMatches(value,{search:"sao flam"}));assert.ok(!predictionMatches(value,{search:"santos"}));
});
test("filters combine market result odds date and competition, rejecting missing odds",()=>{
  const value={marketId:"goals",resultStatus:"pending",odds:2.5,competition:"Copa",startsAt:1000};
  assert.ok(predictionMatches(value,{marketId:"goals",resultStatus:"pending",minimumOdds:2,maximumOdds:3,fromDate:1000,untilDate:1001,competition:"cop"}));
  assert.ok(!predictionMatches(value,{untilDate:1000}));assert.ok(!predictionMatches({...value,odds:null},{minimumOdds:2}));assert.ok(!predictionMatches(value,{marketId:"corners"}));
});
