import { getAuth } from "firebase-admin/auth";
import { HttpsError } from "firebase-functions/v2/https";
type Request = { auth?: { uid: string; token: Record<string, unknown> } | null };
export async function requireUser(request: Request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Entre na sua conta.");
  if (request.auth.token.email_verified !== true) throw new HttpsError("failed-precondition", "Confirme seu e-mail.");
  const account = await getAuth().getUser(request.auth.uid);
  const issued = Number(request.auth.token.auth_time ?? 0) * 1000;
  if (account.disabled || !account.emailVerified || issued < Date.parse(account.tokensValidAfterTime || "1970-01-01")) throw new HttpsError("unauthenticated", "Sessão revogada. Entre novamente.");
  return { ...request.auth, account };
}
export async function requireAdmin(request: Request) {
  const user = await requireUser(request);
  if (request.auth?.token.admin !== true || user.account.customClaims?.admin !== true) throw new HttpsError("permission-denied", "Permissão administrativa necessária.");
  return user;
}
