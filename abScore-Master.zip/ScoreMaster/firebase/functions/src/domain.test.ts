import test from "node:test";
import assert from "node:assert/strict";
import { calculateStats, parseDecimalOdds, validatePrediction } from "./domain.js";

test("accuracy includes only won and lost predictions", () => {
  assert.deepEqual(calculateStats(["won", "won", "lost", "pending", "voided", "postponed", "cancelled"]), {
    wins: 2, losses: 1, pending: 1, excluded: 3, sampleSize: 3, accuracyPercent: 66.7,
  });
});

test("no settled data is null, not a fabricated zero", () => {
  assert.equal(calculateStats(["pending", "voided"]).accuracyPercent, null);
  assert.equal(calculateStats([]).accuracyPercent, null);
});

test("odds normalize commas and reject ambiguous or non-positive values", () => {
  assert.equal(parseDecimalOdds("1,85"), 1.85);
  assert.equal(parseDecimalOdds("2.10"), 2.1);
  for (const value of ["", "0", "-1", "1,2.3", "1,", ".5", "1.12345", "abc"]) assert.equal(parseDecimalOdds(value), null);
});

test("prediction validation reports only missing or malformed fields", () => {
  const valid = { homeTeam: "A", awayTeam: "B", competition: "Cup", marketId: "goals", selection: "Over 2.5", startsAtMillis: 100, marketName: { "pt-BR": "Gols", en: "Goals", es: "Goles" }, odds: "1,85" };
  assert.deepEqual(validatePrediction(valid), []);
  assert.deepEqual(validatePrediction({ ...valid, odds: "1,2.3" }), ["odds"]);
  assert.deepEqual(validatePrediction({ homeTeam: "A" }), ["awayTeam", "competition", "marketId", "selection", "startsAtMillis", "marketName"]);
});

test("creation rejects missing translations and Firestore-incompatible dates", () => {
  const valid = { homeTeam: "A", awayTeam: "B", competition: "Cup", marketId: "goals", selection: "Over 2.5", startsAtMillis: 100, marketName: { "pt-BR": "Gols", en: "Goals", es: "Goles" } };
  assert.ok(validatePrediction({ ...valid, marketName: undefined }).includes("marketName"));
  assert.ok(validatePrediction({ ...valid, marketName: { "pt-BR": "Gols" } }).includes("marketName"));
  for (const startsAtMillis of [NaN, Infinity, -1, 253402300800000, 1.5]) {
    assert.ok(validatePrediction({ ...valid, startsAtMillis }).includes("startsAtMillis"));
  }
  assert.ok(validatePrediction({ ...valid, marketId: "goals/nested" }).includes("marketId"));
});
