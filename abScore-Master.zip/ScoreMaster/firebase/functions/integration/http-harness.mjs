// Actual firebase-functions callable HTTP wrappers, hosted on a loopback TCP port.
// No fake authentication or mocked Firestore responses.
import express from 'express';
import * as functions from '../lib/index.js';
const app=express();app.use(express.json({limit:'1mb'}));
for(const[name,handler]of Object.entries(functions))if(typeof handler==='function'&&handler.__endpoint?.callableTrigger)app.post(`/demo-score-master/us-central1/${name}`,handler);
const server=app.listen(5002,'127.0.0.1',()=>console.log('Callable SDK HTTP harness ready on loopback.'));
process.on('SIGTERM',()=>server.close(()=>process.exit(0)));
