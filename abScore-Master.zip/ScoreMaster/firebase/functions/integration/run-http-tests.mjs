import {spawn} from 'node:child_process';
import net from 'node:net';
const environment={...process.env,GCLOUD_PROJECT:'demo-score-master',GOOGLE_CLOUD_PROJECT:'demo-score-master',FIREBASE_CONFIG:JSON.stringify({projectId:'demo-score-master'}),FUNCTIONS_EMULATOR:'true',INTEGRATION_HTTP_PORT:'5002'};
const server=spawn(process.execPath,['integration/http-harness.mjs'],{env:environment,stdio:'inherit'});
const wait=()=>new Promise(resolve=>{const socket=net.connect(5002,'127.0.0.1');socket.on('connect',()=>{socket.destroy();resolve(true)});socket.on('error',()=>resolve(false));});
let ready=false;for(let attempt=0;attempt<100;attempt++){if(await wait()){ready=true;break;}await new Promise(resolve=>setTimeout(resolve,100));}
if(!ready){server.kill('SIGTERM');throw new Error('Callable SDK HTTP harness did not start');}
const tests=spawn(process.execPath,['--test','--test-concurrency=1','integration/firebase-flow.test.mjs'],{env:environment,stdio:'inherit'});
tests.on('exit',code=>{server.kill('SIGTERM');process.exitCode=code??1;});
