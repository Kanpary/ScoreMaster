import test from 'node:test';
import assert from 'node:assert/strict';
import { readFile } from 'node:fs/promises';
import { randomUUID } from 'node:crypto';
import { initializeApp } from 'firebase-admin/app';
import { getAuth } from 'firebase-admin/auth';
import { getFirestore } from 'firebase-admin/firestore';
import { initializeTestEnvironment, assertFails, assertSucceeds } from '@firebase/rules-unit-testing';
import { doc, getDoc, setDoc } from 'firebase/firestore';

const project='demo-score-master';
if(!process.env.FIREBASE_AUTH_EMULATOR_HOST||!process.env.FIRESTORE_EMULATOR_HOST)throw new Error('Run only through the Firebase emulators:exec script');
initializeApp({projectId:project});const auth=getAuth(),db=getFirestore();
const password=randomUUID()+'aA1!';
async function login(email){const response=await fetch(`http://${process.env.FIREBASE_AUTH_EMULATOR_HOST}/identitytoolkit.googleapis.com/v1/accounts:signInWithPassword?key=emulator-only`,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({email,password,returnSecureToken:true})});const data=await response.json();assert.equal(response.status,200);return data.idToken;}
async function call(name,token,data={}){const response=await fetch(`http://127.0.0.1:${process.env.INTEGRATION_HTTP_PORT||5001}/${project}/us-central1/${name}`,{method:'POST',headers:{'Content-Type':'application/json',...(token?{Authorization:`Bearer ${token}`}:{})},body:JSON.stringify({data})});const body=await response.json();if(body.error){const error=new Error(body.error.message);error.status=body.error.status;throw error;}assert.equal(response.status,200);return body.result;}
const localized={'pt-BR':'Conteúdo QA','en':'QA content','es':'Contenido QA'};

test('real emulator flow: authorization, publication, saving, results, configuration, export and deletion',{timeout:240000},async()=>{
 const suffix=randomUUID().slice(0,8);const accounts={};
 for(const [role,verified]of[['admin',true],['user',true],['other',true],['unverified',false]]){const email=`${role}-${suffix}@qa.example.test`;const user=await auth.createUser({email,password,emailVerified:verified});if(role==='admin')await auth.setCustomUserClaims(user.uid,{admin:true});accounts[role]={uid:user.uid,email,token:await login(email)};}
 const admin=accounts.admin.token,user=accounts.user.token,other=accounts.other.token;
 let predictionId;
 try {
  await assert.rejects(call('getGlobalStats',null),e=>e.status==='UNAUTHENTICATED');
  await assert.rejects(call('getGlobalStats',accounts.unverified.token),e=>e.status==='FAILED_PRECONDITION');
  await assert.rejects(call('initializeMarketCategories',user),e=>e.status==='PERMISSION_DENIED');
  await call('initializeMarketCategories',admin);
  const category=(await db.collection('market_categories').limit(1).get()).docs[0];assert.ok(category);
  const prediction={homeTeam:'QA Mandante',awayTeam:'QA Visitante',competition:'QA integração',marketId:category.id,marketName:localized,selection:'QA seleção',selectionLocalized:localized,startsAtMillis:Date.now()+86400000,odds:'2,10',customFields:{}};
  ({predictionId}=await call('createPrediction',admin,{prediction}));
  await assert.rejects(call('getPredictionDetails',user,{predictionId}),e=>e.status==='NOT_FOUND');
  await call('publishPrediction',admin,{predictionId});
  const feed=await call('listPublishedPredictions',user,{filters:{search:'qa mand'},sort:'recent'});assert.ok(feed.items.some(row=>row.predictionId===predictionId));
  await call('savePrediction',user,{predictionId});await call('savePrediction',user,{predictionId});
  assert.equal((await db.collection('users').doc(accounts.user.uid).collection('saved_predictions').get()).size,1);
  const beforeResult=await db.collection('predictions').doc(predictionId).get();
  await call('setPredictionResult',admin,{predictionId,resultStatus:'won',reason:'QA resultado controlado'});
  if(process.env.INTEGRATION_HTTP_PORT){
    const {synchronizeSavedResults}=await import('../lib/index.js');
    const afterResult=await db.collection('predictions').doc(predictionId).get();
    await synchronizeSavedResults.run({params:{predictionId},data:{before:beforeResult,after:afterResult}});
    await synchronizeSavedResults.run({params:{predictionId},data:{before:beforeResult,after:afterResult}});
  }
  const personal=await call('getPersonalStats',user);assert.equal(personal.wins,1);assert.equal(personal.sampleSize,1);assert.equal(personal.accuracyPercent,100);
  assert.equal((await call('getPredictionDetails',user,{predictionId})).snapshot.resultStatus,'won');
  let synchronized=false;for(let attempt=0;attempt<(process.env.INTEGRATION_HTTP_PORT?1:100);attempt++){const saved=await db.collection('users').doc(accounts.user.uid).collection('saved_predictions').doc(predictionId).get();if(saved.get('resultStatus')==='won'){synchronized=true;break;}await new Promise(resolve=>setTimeout(resolve,100));}assert.ok(synchronized,'Result processor updates the saved record; repeated events are idempotent');
  const before=await db.collection('predictions').doc(predictionId).get();await call('editPrediction',admin,{predictionId,expectedVersion:before.get('version'),confirmedPublishedEdit:true,prediction:{...prediction,homeTeam:'QA alterado'}});
  await call('archivePrediction',admin,{predictionId});const detail=await call('getPredictionDetails',user,{predictionId});assert.equal(detail.snapshot.homeTeam,'QA Mandante');assert.equal(detail.saved,true);assert.equal(detail.archived,true);
  await assert.rejects(call('getPredictionDetails',other,{predictionId}),e=>e.status==='NOT_FOUND');
  await call('updateMyPreferences',user,{language:'es',theme:'light',categories:{results:false}});
  const profile=await db.collection('users').doc(accounts.user.uid).get();assert.equal(profile.get('language'),'es');assert.equal(profile.get('preferences.categories.results'),false);
  const token='qa-device-'+randomUUID();await call('registerDeviceToken',user,{token,platform:'android',language:'en'});
  assert.equal((await db.collection('users').doc(accounts.user.uid).get()).get('language'),'es','Token registration preserves account language');
  assert.equal((await db.collection('users').doc(accounts.user.uid).collection('devices').get()).size,1);
  await call('unregisterDeviceToken',user,{token});assert.equal((await db.collection('users').doc(accounts.user.uid).collection('devices').get()).size,0);
  const configuration={schemaVersion:1,theme:{background:'#101418',ink:'#ffffff'},components:{},texts:{welcome_title:localized},pages:{},documents:{terms:{title:localized,body:localized}}};
  const draft=await call('saveFrontendDraft',admin,{configuration});await call('publishFrontendVersion',admin,{versionId:draft.versionId,expectedCurrentVersionId:(await db.collection('app_config').doc('current').get()).get('versionId')??null});assert.equal((await db.collection('app_config').doc('current').get()).get('configuration.documents.terms.body.es'),'Contenido QA');
  await assert.rejects(call('saveFrontendDraft',admin,{configuration:{...configuration,texts:{welcome_title:{en:'missing'}}}}),e=>e.status==='INVALID_ARGUMENT');
  const campaign=await call('saveNotificationDraft',admin,{notification:{title:localized,body:localized,category:'general',priority:'normal'}});await call('activateNotificationCampaign',admin,{campaignId:campaign.campaignId,audience:'self',sendAtMillis:Date.now()+3600000});await call('cancelNotificationCampaign',admin,{campaignId:campaign.campaignId});assert.equal((await db.collection('notification_campaigns').doc(campaign.campaignId).get()).get('status'),'cancelled');
  let payload={},records=[];do{const page=await call('requestAccountExport',user,payload);records.push(...page.records);payload=page.next;}while(payload);assert.ok(records.some(record=>record.id===predictionId));
  const listed=await call('listManagedUsers',admin,{email:accounts.other.email});assert.equal(listed.items[0].uid,accounts.other.uid);assert.ok(!('password' in listed.items[0]));
  await call('setManagedUserDisabled',admin,{uid:accounts.other.uid,disabled:true,reason:'QA revogação'});await assert.rejects(call('getGlobalStats',other));await call('setManagedUserDisabled',admin,{uid:accounts.other.uid,disabled:false,reason:'QA reativação'});
  await call('deleteMyAccount',user);assert.equal((await db.collection('users').doc(accounts.user.uid).get()).exists,false);await assert.rejects(auth.getUser(accounts.user.uid));
 } finally {for(const account of Object.values(accounts)){await db.recursiveDelete(db.collection('users').doc(account.uid));await auth.deleteUser(account.uid).catch(()=>{});}if(predictionId)await db.collection('predictions').doc(predictionId).delete();}
});

test('Firestore rules enforce user isolation, immutable official records and disabled profiles',{timeout:30000},async()=>{
 const environment=await initializeTestEnvironment({projectId:project,firestore:{host:'127.0.0.1',port:8080,rules:await readFile(new URL('../../../firestore.rules',import.meta.url),'utf8')}});
 try {
  await environment.withSecurityRulesDisabled(async context=>{const firestore=context.firestore();await setDoc(doc(firestore,'users/rules-user'),{disabled:false});await setDoc(doc(firestore,'users/rules-user/saved_predictions/first'),{snapshot:{selection:'QA'}});await setDoc(doc(firestore,'users/rules-disabled'),{disabled:true});});
  const own=environment.authenticatedContext('rules-user',{email_verified:true}).firestore(),other=environment.authenticatedContext('rules-other',{email_verified:true}).firestore(),disabled=environment.authenticatedContext('rules-disabled',{email_verified:true}).firestore();
  await assertSucceeds(getDoc(doc(own,'users/rules-user/saved_predictions/first')));await assertFails(getDoc(doc(other,'users/rules-user/saved_predictions/first')));await assertFails(getDoc(doc(disabled,'users/rules-disabled')));
  await assertFails(setDoc(doc(own,'predictions/forged'),{editorialState:'published'}));await assertFails(setDoc(doc(own,'users/rules-user'),{admin:true}));await assertFails(getDoc(doc(own,'notification_campaigns/private')));
 }finally{await environment.cleanup();}
});
