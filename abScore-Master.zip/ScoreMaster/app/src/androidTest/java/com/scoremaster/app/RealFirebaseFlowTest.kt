package com.scoremaster.app

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.scrollTo
import androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom
import androidx.test.espresso.matcher.ViewMatchers.withText
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import org.hamcrest.Matchers.allOf
import org.junit.Assert.assertEquals
import org.junit.Test
import org.junit.runner.RunWith
import com.google.android.gms.tasks.Tasks
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import java.util.concurrent.TimeUnit

/** End-to-end smoke test against a real Firebase project with one published QA prediction. */
@RunWith(AndroidJUnit4::class)
class RealFirebaseFlowTest {
    @Test fun publicFeedAndLocalFavoritesWorkWithoutVisitorAccounts() {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val context=instrumentation.targetContext
        val args=InstrumentationRegistry.getArguments()
        val project=args.getString("e2eProjectId")?:error("Supply e2eProjectId for the QA Firebase project")
        assertEquals("Firebase project mismatch",project,FirebaseApp.getInstance().options.projectId)
        val predictionId=args.getString("e2ePredictionId")?:error("Supply an existing published prediction ID")
        val snapshot=Tasks.await(FirebaseFirestore.getInstance().collection("public_predictions").document(predictionId).get(),60,TimeUnit.SECONDS)
        check(snapshot.exists()&&snapshot.getString("editorialState")=="published") { "The QA prediction must be published." }
        val home=snapshot.getString("homeTeam")?:error("QA prediction lacks homeTeam")
        val away=snapshot.getString("awayTeam")?:error("QA prediction lacks awayTeam")
        val prefs=context.getSharedPreferences("score_master",0)
        val old=prefs.getStringSet("saved_ids",emptySet()).orEmpty()
        val wasSaved=predictionId in old
        try {
            ActivityScenario.launch(MainActivity::class.java).use { scenario ->
                var activity:MainActivity?=null;scenario.onActivity{activity=it}
                fun label(id:Int):String {val a=activity!!;return FrontendConfiguration(a).text(a.resources.getResourceEntryName(id))?:a.getString(id)}
                fun waitFor(text:String){val deadline=System.currentTimeMillis()+60000;while(true){try{onView(withText(text)).check(matches(isDisplayed()));return}catch(error:AssertionError){if(System.currentTimeMillis()>deadline)throw error}catch(error:androidx.test.espresso.NoMatchingViewException){if(System.currentTimeMillis()>deadline)throw error};Thread.sleep(100)}}
                waitFor(label(R.string.home))
                onView(allOf(withText(label(R.string.explore)),isAssignableFrom(android.widget.Button::class.java))).perform(click())
                waitFor("$home  ×  $away")
                if(!wasSaved)onView(allOf(withText(label(R.string.save)),isAssignableFrom(android.widget.Button::class.java))).perform(scrollTo(),click())
                onView(allOf(withText(label(R.string.saved)),isAssignableFrom(android.widget.Button::class.java))).perform(click())
                waitFor("$home  ×  $away")
                scenario.recreate()
                waitFor(label(R.string.home))
                onView(allOf(withText(label(R.string.saved)),isAssignableFrom(android.widget.Button::class.java))).perform(click())
                waitFor("$home  ×  $away")
            }
        } finally {
            val current=prefs.getStringSet("saved_ids",emptySet()).orEmpty().toMutableSet()
            if(wasSaved)current.add(predictionId) else current.remove(predictionId)
            prefs.edit().putStringSet("saved_ids",current).commit()
        }
    }
}
