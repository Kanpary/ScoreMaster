package com.scoremaster.app

import androidx.test.core.app.ActivityScenario
import androidx.test.ext.junit.runners.AndroidJUnit4
import androidx.test.platform.app.InstrumentationRegistry
import androidx.test.espresso.Espresso.onView
import androidx.test.espresso.action.ViewActions.click
import androidx.test.espresso.action.ViewActions.scrollTo
import androidx.test.espresso.matcher.ViewMatchers.isAssignableFrom
import org.hamcrest.Matchers.allOf
import androidx.test.espresso.assertion.ViewAssertions.matches
import androidx.test.espresso.matcher.ViewMatchers.isDisplayed
import androidx.test.espresso.matcher.ViewMatchers.withText
import com.google.android.gms.tasks.Tasks
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import java.util.concurrent.TimeUnit

/** Runs against the explicitly supplied Firebase project/account; no response stubs. */
@RunWith(AndroidJUnit4::class)
class RealFirebaseFlowTest {
    @Test fun accountNavigationAndSavedPersistenceAcrossActivityRestart() {
        val instrumentation=InstrumentationRegistry.getInstrumentation()
        val context=instrumentation.targetContext
        val arguments=InstrumentationRegistry.getArguments()
        val project=arguments.getString("e2eProjectId")?:error("Supply e2eProjectId for the dedicated QA project")
        assertEquals("Firebase project mismatch",project,FirebaseApp.getInstance().options.projectId)
        check(arguments.getString("e2eConsent")=="true"){"Explicit QA account consent is required"}
        val email=arguments.getString("e2eEmail")?:error("Supply verified QA account email")
        val password=arguments.getString("e2ePassword")?:error("Supply QA password privately in the runner")
        val predictionId=arguments.getString("e2ePredictionId")?:error("Supply an existing published prediction ID")
        val auth=FirebaseAuth.getInstance();val functions=FirebaseFunctions.getInstance()
        fun call(name:String,data:Map<String,Any> = emptyMap())=Tasks.await(functions.getHttpsCallable(name).call(data),60,TimeUnit.SECONDS).data as Map<*,*>
        Tasks.await(auth.signInWithEmailAndPassword(email,password),60,TimeUnit.SECONDS)
        assertTrue("QA account must be verified",auth.currentUser!!.isEmailVerified)
        Tasks.await(auth.currentUser!!.getIdToken(true),60,TimeUnit.SECONDS)
        val originalProfile=Tasks.await(com.google.firebase.firestore.FirebaseFirestore.getInstance().collection("users").document(auth.currentUser!!.uid).get(),60,TimeUnit.SECONDS)
        val originalLanguage=originalProfile.getString("language")?:"pt-BR"
        val before=call("getPredictionDetails",mapOf("predictionId" to predictionId))["saved"]==true
        try {
            for(language in listOf("pt-BR","en","es")) {
                call("updateMyPreferences",mapOf("language" to language))
                context.getSharedPreferences("score_master",0).edit().putString("language",language).commit()
                ActivityScenario.launch(MainActivity::class.java).use { scenario ->
                    var activity:MainActivity?=null;scenario.onActivity{activity=it}
                    fun label(id:Int):String {val a=activity!!;return FrontendConfiguration(a).text(a.resources.getResourceEntryName(id))?:a.getString(id)}
                    fun waitFor(label:String){val deadline=System.currentTimeMillis()+60000;while(true){try{onView(allOf(withText(label),isAssignableFrom(android.widget.Button::class.java))).check(matches(isDisplayed()));return}catch(error:AssertionError){if(System.currentTimeMillis()>deadline)throw error}catch(error:androidx.test.espresso.NoMatchingViewException){if(System.currentTimeMillis()>deadline)throw error};Thread.sleep(100)}}
                    waitFor(label(R.string.home))
                    for(page in listOf(R.string.explore,R.string.saved,R.string.statistics,R.string.settings)) {val title=label(page);waitFor(title);onView(allOf(withText(title),isAssignableFrom(android.widget.Button::class.java))).perform(click())}
                    onView(allOf(withText(label(R.string.logout)),isAssignableFrom(android.widget.Button::class.java))).perform(scrollTo()).check(matches(isDisplayed()))
                    call("savePrediction",mapOf("predictionId" to predictionId));call("savePrediction",mapOf("predictionId" to predictionId))
                    assertEquals(true,call("getPredictionDetails",mapOf("predictionId" to predictionId))["saved"])
                    scenario.recreate();Thread.sleep(300)
                    assertEquals(true,call("getPredictionDetails",mapOf("predictionId" to predictionId))["saved"])
                    val statistics=call("getPersonalStats");val wins=(statistics["wins"] as Number).toInt();val losses=(statistics["losses"] as Number).toInt();assertEquals(wins+losses,(statistics["sampleSize"] as Number).toInt())
                }
            }
        } finally {
            try {if(!before)call("unsavePrediction",mapOf("predictionId" to predictionId));call("updateMyPreferences",mapOf("language" to originalLanguage));context.getSharedPreferences("score_master",0).edit().putString("language",originalLanguage).commit()}
            finally {auth.signOut()}
        }
    }
}
