package com.scoremaster.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import java.net.URI
import java.net.URL
import javax.net.ssl.HttpsURLConnection

internal object ImageAssets {
    fun allowed(url:String):Boolean = runCatching { val uri=URI(url);uri.scheme=="https"&&uri.userInfo==null&&uri.host in listOf("firebasestorage.googleapis.com","storage.googleapis.com") }.getOrDefault(false)
    fun fetch(url:String,timeout:Int=10000):Bitmap? = runCatching {
        if(!allowed(url))return@runCatching null
        val connection=URL(url).openConnection() as HttpsURLConnection
        connection.connectTimeout=timeout;connection.readTimeout=timeout;connection.instanceFollowRedirects=false
        try {
            if(connection.responseCode!=200||connection.contentLength>2097152)return@runCatching null
            val bytes=connection.inputStream.use{input->val output=java.io.ByteArrayOutputStream();val buffer=ByteArray(8192)
                while(true){val read=input.read(buffer);if(read<0)break;if(output.size()+read>2097152)return@runCatching null;output.write(buffer,0,read)};output.toByteArray()}
            val bounds=BitmapFactory.Options().apply{inJustDecodeBounds=true};BitmapFactory.decodeByteArray(bytes,0,bytes.size,bounds)
            if(bounds.outWidth !in 1..4096||bounds.outHeight !in 1..4096)return@runCatching null
            val options=BitmapFactory.Options().apply{inSampleSize=1};while(maxOf(bounds.outWidth,bounds.outHeight)/options.inSampleSize>1024)options.inSampleSize*=2
            BitmapFactory.decodeByteArray(bytes,0,bytes.size,options)
        }finally{connection.disconnect()}
    }.getOrNull()
}
