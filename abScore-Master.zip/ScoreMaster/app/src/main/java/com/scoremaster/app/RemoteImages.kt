package com.scoremaster.app

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import android.widget.ImageView
import java.net.URL
import java.util.concurrent.Executors

internal class RemoteImages {
    private val executor = Executors.newFixedThreadPool(2)
    private val handler = Handler(Looper.getMainLooper())
    private val cache = object : LruCache<String, Bitmap>(8 * 1024 * 1024) {
        override fun sizeOf(key: String, value: Bitmap) = value.byteCount
    }
    fun load(url: String, view: ImageView) {
        view.setTag(com.scoremaster.app.R.id.remote_image_url, url)
        val parsed = runCatching { android.net.Uri.parse(url) }.getOrNull() ?: return
        if (parsed.scheme != "https" || parsed.userInfo != null || parsed.host !in listOf("firebasestorage.googleapis.com", "storage.googleapis.com")) return
        cache.get(url)?.let { view.setImageBitmap(it); return }
        if (executor.isShutdown) return
        executor.execute {
            val bitmap = ImageAssets.fetch(url) ?: return@execute
            cache.put(url, bitmap)
            handler.post { if (view.getTag(com.scoremaster.app.R.id.remote_image_url) == url) view.setImageBitmap(bitmap) }
        }
    }
    fun close() { executor.shutdownNow(); handler.removeCallbacksAndMessages(null); cache.evictAll() }
}
