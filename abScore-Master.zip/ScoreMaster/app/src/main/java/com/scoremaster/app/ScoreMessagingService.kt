package com.scoremaster.app

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessagingService
import com.google.firebase.messaging.RemoteMessage

class ScoreMessagingService : FirebaseMessagingService() {
    override fun onNewToken(token: String) {
        if (FirebaseApp.getApps(this).isEmpty()) return
        val user = FirebaseAuth.getInstance().currentUser ?: return
        if (!user.isEmailVerified) return
        FirebaseFunctions.getInstance().getHttpsCallable("registerDeviceToken")
            .call(mapOf("token" to token, "platform" to "android", "language" to resources.configuration.locale.toLanguageTag()))
    }

    override fun onMessageReceived(message: RemoteMessage) {
        if (FirebaseApp.getApps(this).isEmpty()) return
        val currentUser = FirebaseAuth.getInstance().currentUser ?: return
        if (message.data["recipientUid"] != currentUser.uid || !currentUser.isEmailVerified) return
        val category = message.data["category"]?.takeIf { it in listOf("general", "predictions", "results") } ?: "general"
        val channelId = "score_$category"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val label = when (category) { "predictions" -> R.string.notifications_predictions; "results" -> R.string.notifications_results; else -> R.string.notifications_general }
            getSystemService(NotificationManager::class.java).createNotificationChannel(
                NotificationChannel(channelId, getString(label), NotificationManager.IMPORTANCE_DEFAULT)
            )
        }
        val campaignId = message.data["campaignId"]
        if (campaignId != null) {
            val received = getSharedPreferences("received_pushes", MODE_PRIVATE)
            val previous = received.getStringSet("ids", emptySet()).orEmpty()
            if (campaignId in previous) return
            val next = previous.toMutableSet().apply { add(campaignId) }
            received.edit().putStringSet("ids", next.toList().takeLast(200).toSet()).apply()
        }
        val id = message.data["predictionId"]
        val title = message.data["title"] ?: message.notification?.title ?: getString(R.string.app_name)
        val body = message.data["body"] ?: message.notification?.body ?: return
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) return
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_CLEAR_TOP or Intent.FLAG_ACTIVITY_SINGLE_TOP
            if (id != null) putExtra("predictionId", id)
            else putExtra("openNotifications", true)
            putExtra("targetScreen", message.data["screen"])
            putExtra("targetUrl", message.data["url"])
        }
        val pending = PendingIntent.getActivity(this, campaignId?.hashCode() ?: id?.hashCode() ?: 0, intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, channelId)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(title)
            .setContentText(body)
            .setStyle(NotificationCompat.BigTextStyle().bigText(body))
            .setContentIntent(pending)
            .setAutoCancel(true)
            .setVisibility(NotificationCompat.VISIBILITY_PRIVATE)
            .setPublicVersion(NotificationCompat.Builder(this,channelId).setSmallIcon(R.drawable.ic_notification).setContentTitle(getString(R.string.app_name)).setContentText(getString(R.string.notifications_title)).build())
        message.data["imageUrl"]?.let { url -> ImageAssets.fetch(url,2000)?.let { bitmap -> notification.setStyle(NotificationCompat.BigPictureStyle().bigPicture(bitmap).setSummaryText(body)) } }
        if(FirebaseAuth.getInstance().currentUser?.uid!=currentUser.uid)return
        NotificationManagerCompat.from(this).notify(campaignId?.hashCode() ?: id?.hashCode() ?: System.currentTimeMillis().toInt(), notification.build())
    }
}
