package com.scoremaster.app

import com.google.firebase.Timestamp
import com.google.firebase.firestore.DocumentSnapshot
import com.scoremaster.app.domain.ResultStatus
import java.util.Date
import java.util.Locale

internal data class Prediction(
    val id: String,
    val homeTeam: String,
    val awayTeam: String,
    val competition: String,
    val marketName: String,
    val marketId: String,
    val selection: String,
    val odds: String?,
    val startsAt: Date?,
    val resultStatus: ResultStatus,
    val country: String,
    val analysis: String?,
    val sources: List<String>,
    val legs: List<Map<*, *>>,
    val homeLogoUrl:String?,
    val awayLogoUrl:String?
) {
    companion object {
        fun from(document: DocumentSnapshot): Prediction? = fromMap(document.id, document.data)

        fun fromMap(id: String, data: Map<*, *>?): Prediction? {
            data ?: return null
            fun text(key: String) = data[key] as? String
            val home = text("homeTeam") ?: return null
            val away = text("awayTeam") ?: return null
            val competition = text("competition") ?: return null
            fun localized(key: String): String? {
                val map = data[key] as? Map<*, *> ?: return null
                val language = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
                return map[language] as? String ?: map["pt-BR"] as? String
            }
            val selection = localized("selectionLocalized") ?: text("selection") ?: return null
            val localizedMarket = data["marketName"] as? Map<*, *>
            val locale = Locale.getDefault()
            val language = if (locale.language == "pt") "pt-BR" else locale.language
            val marketName = (localizedMarket?.get(language) as? String)
                ?: (localizedMarket?.get("pt-BR") as? String)
                ?: text("marketName") ?: return null
            val timestamp = data["startsAt"] as? Timestamp
            val rawStart = data["startsAt"]
            val start = timestamp?.toDate() ?: (rawStart as? Date) ?: (rawStart as? Number)?.toLong()?.let(::Date)
            return Prediction(
                id = id,
                homeTeam = home,
                awayTeam = away,
                competition = competition,
                marketName = marketName,
                marketId = text("marketId").orEmpty(),
                selection = selection,
                odds = data["odds"]?.toString(),
                startsAt = start,
                resultStatus = ResultStatus.fromWire(text("resultStatus")),
                country = text("country").orEmpty(),
                analysis = localized("analysisLocalized") ?: text("analysis"),
                sources = (data["sources"] as? List<*>)?.filterIsInstance<String>().orEmpty(),
                legs = (data["legs"] as? List<*>)?.mapNotNull { it as? Map<*, *> }.orEmpty(),
                homeLogoUrl=text("homeLogoUrl"),awayLogoUrl=text("awayLogoUrl")
            )
        }
    }
}
