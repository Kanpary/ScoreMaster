package com.scoremaster.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import com.google.firebase.FirebaseApp
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.scoremaster.app.domain.ResultStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var bg = Color.rgb(13, 20, 20)
    private var surface = Color.rgb(20, 29, 29)
    private var line = Color.rgb(39, 54, 52)
    private var ink = Color.rgb(239, 246, 242)
    private var muted = Color.rgb(149, 164, 157)
    private var green = Color.rgb(24, 183, 119)

    private val remoteImages = RemoteImages()
    private lateinit var frontend: FrontendConfiguration
    private var configListener: ListenerRegistration? = null
    private lateinit var root: LinearLayout
    private lateinit var configuredContent: LinearLayout
    private lateinit var content: LinearLayout
    private var predictionListener: ListenerRegistration? = null
    private var predictions = emptyList<Prediction>()
    private val savedIds = linkedSetOf<String>()
    private var savedItems = emptyList<Prediction>()
    private var savedLimit = 50
    private var savedResultFilter = ""
    private var screenVersion = 0
    private var currentPage = "home"
    private var searchQuery = ""
    private var selectedMarketId = ""
    private var nextFeedCursor: String? = null
    private var nextFeedDocument: com.google.firebase.firestore.DocumentSnapshot? = null
    private var feedRequest = 0
    private var feedSort = "kickoff"
    private var inboxLimit = 50
    private var resultFilter = ""
    private var competitionFilter = ""
    private var minimumOdds: Double? = null
    private var maximumOdds: Double? = null
    private var fromDate: Long? = null
    private var untilDate: Long? = null
    private lateinit var predictionCards: LinearLayout
    private val searchHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var searchUpdate: Runnable? = null
    private var categoryListener: ListenerRegistration? = null
    private var pendingPredictionId: String? = null
    private var pendingTargetUrl: String? = null

    private val firebaseConfigured: Boolean
        get() = FirebaseApp.getApps(applicationContext).isNotEmpty()
    private val db: FirebaseFirestore?
        get() = if (firebaseConfigured) FirebaseFirestore.getInstance() else null

    override fun attachBaseContext(newBase: Context) {
        val language = newBase.getSharedPreferences("score_master", MODE_PRIVATE)
            .getString("language", null)
        if (language.isNullOrBlank()) {
            super.attachBaseContext(newBase)
            return
        }
        val config = Configuration(newBase.resources.configuration)
        val selectedLocale = Locale.forLanguageTag(language)
        Locale.setDefault(selectedLocale)
        config.setLocale(selectedLocale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        frontend = FrontendConfiguration(this)
        applyFrontendPalette()
        subscribeFrontend()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        pendingTargetUrl = intent.getStringExtra("targetUrl")
        pendingPredictionId = intent.getStringExtra("predictionId")
        if (intent.getBooleanExtra("openNotifications", false)) currentPage = "notifications"
        intent.getStringExtra("targetScreen")?.takeIf { it in listOf("home", "explore", "saved", "stats", "settings", "notifications") }?.let { currentPage = it }
        render()
    }

    override fun onResume() {
        super.onResume()
        if (!firebaseConfigured) return
        startUserSubscriptions()
        val deepLink = pendingPredictionId
        if (deepLink != null) renderPredictionDetail(deepLink) else renderApp(currentPage)
    }

    override fun onDestroy() {
        predictionListener?.remove()
        configListener?.remove()
        categoryListener?.remove()
        screenVersion++
        remoteImages.close()
        searchHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun render() {
        predictionListener?.remove()
        predictionListener = null
        if (!firebaseConfigured) { renderAuthGate(configurationMissing = true); return }
        startUserSubscriptions()
        val deepLink = pendingPredictionId
        if (deepLink != null) renderPredictionDetail(deepLink) else renderApp(currentPage)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingTargetUrl = intent.getStringExtra("targetUrl")
        pendingPredictionId = intent.getStringExtra("predictionId")
        pendingPredictionId?.let { renderPredictionDetail(it) }
        if (pendingPredictionId == null && intent.getBooleanExtra("openNotifications", false)) {
            val target = intent.getStringExtra("targetScreen")?.takeIf { it in listOf("home", "explore", "saved", "stats", "settings", "notifications") } ?: "notifications"
            renderApp(target)
            openPendingTarget()
        }
    }

    @Deprecated("Deprecated in Android SDK; retained for devices using the platform back button")
    override fun onBackPressed() {
        if (currentPage == "detail") {
            pendingPredictionId = null
            renderApp("explore")
        } else super.onBackPressed()
    }

    private fun renderAuthGate(configurationMissing:Boolean){
        currentPage="home";screenVersion++;root=baseRoot()
        val panel=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(22),dp(28),dp(22),dp(24))}
        panel.addView(android.widget.ImageView(this).apply{setImageResource(R.drawable.score_master_logo);contentDescription="Score Master";scaleType=android.widget.ImageView.ScaleType.FIT_CENTER},lp(dp(72),dp(72)).apply{gravity=Gravity.CENTER_HORIZONTAL})
        panel.addView(text("Score Master",25f,ink,true),lp())
        panel.addView(text(if(configurationMissing)uiString(R.string.backend_missing) else "Não foi possível conectar ao Firebase. Tente novamente mais tarde.",14f,muted),lp().apply{topMargin=dp(14)})
        root.addView(panel,lp());showRoot()
    }

    private fun renderApp(page: String) {
        if(!firebaseConfigured){render();return}
        categoryListener?.remove()
        screenVersion++
        predictionListener?.remove()
        predictionListener = null
        currentPage = page
        root = baseRoot()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = rounded(surface, 0f)
        }
        header.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.score_master_logo)
            contentDescription = "Score Master"
            frontend.image("logo")?.let { asset -> remoteImages.load(asset.getString("url"), this); contentDescription = frontend.localized(asset.optJSONObject("alt")) }
        }, lp(dp(42), dp(42)))
        header.addView(text("Score Master", 17f, ink, true).apply { setPadding(dp(10), 0, 0, 0) }, lp(0, -2, 1f))
        header.tag = "header"
        frontend.apply(header, "header")
        root.addView(header, lp())
        val scroller = ScrollView(this).apply { fillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(18), dp(17), dp(24)) }
        configuredContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), 0, dp(17), dp(16)) }
        val scrollBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollBody.addView(content, lp())
        scrollBody.addView(configuredContent, lp())
        scroller.addView(scrollBody)
        root.addView(scroller, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(7), dp(4), dp(7)); background = rounded(surface, 0f) }
        val items = listOf("home" to R.string.home, "explore" to R.string.explore, "saved" to R.string.saved, "stats" to R.string.statistics, "settings" to R.string.settings)
        items.forEach { (id, label) ->
            val b = Button(this).apply {
                text = uiString(label)
                textSize = 10f
                isAllCaps = false
                setTextColor(if (currentPage == id) green else muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { renderApp(id) }
            }
            b.minHeight=dp(48)
            nav.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        nav.tag = "navigation"
        frontend.apply(nav, "navigation")
        root.addView(nav, lp())
        frontend.decorate(root, when (currentPage) { "detail" -> "details"; "home" -> "banners"; "saved" -> "history"; "stats" -> "statisticsCard"; else -> currentPage })
        showRoot()
        when (page) {
            "home" -> renderHome()
            "explore" -> renderExplore()
            "saved" -> renderSaved()
            "stats" -> renderStats()
            "notifications" -> renderInbox()
            else -> renderSettings()
        }
        frontend.arrange(content, page)
        addConfiguredBlocks(page)
        frontend.decorate(content,when(page){"home"->"banners";"stats"->"statisticsCard";"saved"->"history";else->page})
        openPendingTarget()
    }

    private fun uiString(id: Int): String {
        val key = resources.getResourceEntryName(id)
        if (key in setOf("disclaimer", "email_verification", "backend_missing", "auth_required", "pending", "won", "lost", "voided", "postponed", "cancelled")) return getString(id)
        return frontend.text(key) ?: getString(id)
    }
    private fun uiFormat(id:Int,vararg arguments:Any):String = runCatching {String.format(Locale.getDefault(),uiString(id),*arguments)}.getOrElse {getString(id,*arguments)}

    private fun applyFrontendPalette() {
        bg = frontend.color("background", Color.rgb(13, 20, 20)); surface = frontend.color("surface", Color.rgb(20, 29, 29))
        line = frontend.color("line", Color.rgb(39, 54, 52)); ink = frontend.color("ink", Color.rgb(239, 246, 242))
        muted = frontend.color("muted", Color.rgb(149, 164, 157)); green = frontend.color("accent", Color.rgb(24, 183, 119))
        val preference = getSharedPreferences("score_master",MODE_PRIVATE).getString("theme","system")
        val systemDark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        if (frontend.value?.optBoolean("themeSelectionEnabled",true) != false && (preference == "light" || (preference == "system" && !systemDark))) {
            bg = frontend.lightColor("background",Color.rgb(243,247,245)); surface = frontend.lightColor("surface",Color.WHITE)
            line = frontend.lightColor("line",Color.rgb(196,208,202)); ink = frontend.lightColor("ink",Color.rgb(16,37,28))
            muted = frontend.lightColor("muted",Color.rgb(66,92,80)); green = frontend.lightColor("accent",Color.rgb(8,122,75))
        }
    }

    private fun subscribeFrontend() {
        configListener = db?.collection("app_config")?.document("current")?.addSnapshotListener { doc, error ->
            if (error != null || isDestroyed) return@addSnapshotListener
            val data = doc?.get("configuration") as? Map<*, *> ?: return@addSnapshotListener
            val candidate = org.json.JSONObject(data)
            if (candidate.toString() == frontend.value?.toString()) return@addSnapshotListener
            if (!frontend.accept(candidate)) {
                android.util.Log.w("ScoreMaster", "Configuração incompatível ignorada; última configuração válida preservada.")
                return@addSnapshotListener
            }
            applyFrontendPalette()
            if (currentPage == "detail") { pendingPredictionId?.let(::renderPredictionDetail); return@addSnapshotListener }
            render()
        }
    }

    private fun addConfiguredBlocks(page: String) {
        val blocks = frontend.value?.optJSONObject("pages")?.optJSONArray(page) ?: return
        for (i in 0 until blocks.length()) {
            val block = blocks.optJSONObject(i) ?: continue
            if (!block.optBoolean("visible", true)) continue
            val label = frontend.localized(block.optJSONObject("text")).orEmpty()
            val view: View = when (block.optString("type")) {
                "button" -> button(label, false) {
                    val action = block.optString("action")
                    if (action == "support:telegram") openTelegram()
                    else if (action in FrontendConfiguration.allowedActions) renderApp(action.substringAfter(":"))
                }
                "image" -> android.widget.ImageView(this).apply {
                    adjustViewBounds = true
                    minimumHeight = dp(80)
                    scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                    remoteImages.load(block.optString("imageUrl"), this)
                }
                "divider" -> View(this).apply { setBackgroundColor(line); minimumHeight = dp(1) }
                else -> text(label, 14f, ink)
            }
            view.contentDescription = frontend.localized(block.optJSONObject("accessibility")) ?: label
            configuredContent.addView(view, lp().apply { topMargin = dp(8) })
            frontend.apply(view, "text", block.optJSONObject("style"))
        }
    }

    private fun renderHome() {
        content.addView(text(uiString(R.string.welcome_title), 24f, ink, true).apply { tag = "welcomeTitle" }, lp())
        content.addView(text(uiString(R.string.welcome_body), 13f, muted).apply { tag = "welcomeBody"; setPadding(0, dp(5), 0, dp(15)) }, lp())
        content.addView(text(uiString(R.string.disclaimer), 11f, Color.rgb(203, 191, 146)).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(Color.rgb(43, 39, 27), 12f)
        }, lp().apply { bottomMargin = dp(15) })
        sectionTitle(uiString(R.string.explore))
        predictionCards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "predictionList" }
        content.addView(predictionCards, lp())
        predictionCards.addView(text(uiString(R.string.loading), 12f, muted), lp())
        subscribePredictions()
    }

    private fun renderExplore() {
        content.addView(text(uiString(R.string.explore), 23f, ink, true), lp())
        val search = edit(uiString(R.string.search_hint), false).apply { tag = "search"; inputType = android.text.InputType.TYPE_CLASS_TEXT }
        search.setSingleLine(true)
        search.setText(searchQuery)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty()
                searchUpdate?.let(searchHandler::removeCallbacks)
                searchUpdate = Runnable { if (currentPage == "explore" && !isDestroyed) reloadFeed() }
                searchHandler.postDelayed(searchUpdate!!, 300) }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        content.addView(search, lp().apply { topMargin = dp(12); bottomMargin = dp(12) })
        val sorting=android.widget.Spinner(this).apply{tag="tabs"}
        val sorts=listOf("recent","kickoff","market")
        sorting.adapter=android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(uiString(R.string.sort_recent),uiString(R.string.sort_kickoff),uiString(R.string.sort_market)))
        sorting.setSelection(sorts.indexOf(feedSort).coerceAtLeast(0));var firstSort=true
        sorting.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?)=Unit
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){if(firstSort){firstSort=false;return};feedSort=sorts[position];reloadFeed()}
        }
        content.addView(sorting,lp())
        val markets = android.widget.Spinner(this).apply { tag = "marketFilters" }
        content.addView(markets, lp().apply { bottomMargin = dp(12) })
        val requestScreen = screenVersion
        categoryListener = db?.collection("market_categories")?.whereEqualTo("active", true)?.addSnapshotListener { snapshot, error ->
            if (requestScreen != screenVersion || isDestroyed || error != null) return@addSnapshotListener
            val categories = snapshot?.documents?.sortedBy { it.getLong("order") ?: 0 }.orEmpty()
            val language = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
            val names = listOf(uiString(R.string.all_markets)) + categories.map { (it.get("name") as? Map<*, *>)?.let { name -> name[language] as? String ?: name["pt-BR"] as? String } ?: it.id }
            markets.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            markets.setSelection((categories.indexOfFirst { it.id == selectedMarketId } + 1).coerceAtLeast(0))
            markets.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedMarketId = if (position == 0) "" else categories[position - 1].id
                    reloadFeed()
                }
            }
        }
        content.addView(button(uiString(R.string.apply_filters), false) { showFilterDialog() }.apply { tag = "filterButton" }, lp())
        content.addView(text(uiString(R.string.filter_scope), 11f, muted).apply { tag = "filtersExplanation" }, lp())
        predictionCards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "predictionList" }
        content.addView(predictionCards, lp())
        predictionCards.addView(text(uiString(R.string.loading), 12f, muted), lp())
        subscribePredictions()
    }

    private fun feedFilters():Map<String,Any> = emptyMap()
    private fun subscribePredictions() {
        if(!firebaseConfigured)return
        predictionListener?.remove()
        val requestScreen=screenVersion
        predictionListener=db?.collection("public_predictions")?.whereEqualTo("editorialState","published")?.limit(250)
            ?.addSnapshotListener { _,error ->
                if(requestScreen!=screenVersion||isDestroyed)return@addSnapshotListener
                if(error!=null){showTaskError(error);return@addSnapshotListener}
                reloadFeed()
            }
        reloadFeed()
    }
    private fun reloadFeed(){nextFeedCursor=null;nextFeedDocument=null;predictions=emptyList();feedRequest++;loadFeedPage(null,feedRequest)}
    private fun loadFeedPage(cursor:String?,request:Int){
        val requestScreen=screenVersion
        var query=db?.collection("public_predictions")?.whereEqualTo("editorialState","published")?.orderBy("updatedAt",Query.Direction.DESCENDING)?.limit(250)
        if(cursor!=null&&nextFeedDocument!=null)query=query?.startAfter(nextFeedDocument!!)
        query?.get()?.addOnSuccessListener { snapshot ->
                if(requestScreen!=screenVersion||request!=feedRequest||isDestroyed)return@addOnSuccessListener
                val all=predictions+snapshot.documents.mapNotNull { Prediction.fromMap(it.id,it.data) }
                val filtered=all.filter { p ->
                    (selectedMarketId.isBlank() || p.marketId==selectedMarketId) &&
                    (resultFilter.isBlank() || p.resultStatus.wireValue==resultFilter) &&
                    (competitionFilter.isBlank() || p.competition.contains(competitionFilter,true)) &&
                    (searchQuery.isBlank() || listOf(p.homeTeam,p.awayTeam,p.competition,p.selection).any{it.contains(searchQuery,true)}) &&
                    (minimumOdds==null || (p.odds?.toDoubleOrNull() ?: 0.0)>=minimumOdds!!) &&
                    (maximumOdds==null || (p.odds?.toDoubleOrNull() ?: Double.MAX_VALUE)<=maximumOdds!!) &&
                    (fromDate==null || (p.startsAt?.time ?: 0L)>=fromDate!!) && (untilDate==null || (p.startsAt?.time ?: Long.MAX_VALUE)<untilDate!!)
                }
                val comparator:Comparator<Prediction> = when(feedSort){
                    "kickoff"->compareBy<Prediction>{it.startsAt?.time?:Long.MAX_VALUE}
                    "market"->compareBy<Prediction,String>(String.CASE_INSENSITIVE_ORDER){it.marketName}
                    else->compareByDescending<Prediction>{it.startsAt?.time?:0L}
                }
                predictions=filtered.sortedWith(comparator)
                nextFeedDocument=snapshot.documents.lastOrNull()?.takeIf{snapshot.size()==250}
                nextFeedCursor=nextFeedDocument?.id
                if(cursor==null) { savedIds.clear(); savedIds.addAll(getSharedPreferences("score_master",MODE_PRIVATE).getStringSet("saved_ids",emptySet()).orEmpty()) }
                displayPredictions(predictions)
            }?.addOnFailureListener { if(requestScreen==screenVersion&&request==feedRequest&&!isDestroyed)showTaskError(it) }
    }
    private fun jsonMap(value:org.json.JSONObject):Map<String,Any?> {
        fun convert(item:Any?):Any?=when(item){org.json.JSONObject.NULL->null;is org.json.JSONObject->jsonMap(item);is org.json.JSONArray->(0 until item.length()).map{convert(item.opt(it))};else->item}
        return value.keys().asSequence().associateWith{convert(value.opt(it))}
    }
    private fun displayPredictions(items: List<Prediction>) {
        if(!::predictionCards.isInitialized||currentPage !in listOf("home","explore"))return
        predictionCards.removeAllViews()
        if(items.isEmpty())predictionCards.addView(text(uiString(R.string.no_predictions),13f,muted),lp())
        items.forEach{addPredictionCard(it,it.id in savedIds)}
        if(nextFeedCursor!=null)predictionCards.addView(button(uiString(R.string.load_more),false){clicked->clicked.isEnabled=false;loadFeedPage(nextFeedCursor,feedRequest)},lp())
    }

    private fun showFilterDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val competition = edit(uiString(R.string.competition_filter), false).apply { inputType = android.text.InputType.TYPE_CLASS_TEXT; setText(competitionFilter) }
        val min = edit(uiString(R.string.min_odds), false).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(minimumOdds?.toString().orEmpty()) }
        val max = edit(uiString(R.string.max_odds), false).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(maximumOdds?.toString().orEmpty()) }
        val from = edit(uiString(R.string.date_from), false).apply { inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_DATE }
        val until = edit(uiString(R.string.date_until), false).apply { inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_DATE }
        val status = android.widget.Spinner(this)
        val statuses = listOf("", "pending", "won", "lost", "voided", "postponed", "cancelled")
        status.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf(uiString(R.string.all_results)) + com.scoremaster.app.domain.ResultStatus.entries.map(::statusLabel))
        status.setSelection(statuses.indexOf(resultFilter).coerceAtLeast(0))
        listOf(competition, min, max, from, until, status).forEach { panel.addView(it, lp().apply { topMargin = dp(6) }) }
        val scroll = ScrollView(this).apply { addView(panel) }
        val dialog = android.app.AlertDialog.Builder(this).setTitle(uiString(R.string.apply_filters)).setView(scroll)
            .setNegativeButton(uiString(R.string.cancel_label), null)
            .setPositiveButton(uiString(R.string.apply_filters), null).create()
        dialog.setOnShowListener {
            dialog.window?.decorView?.let { frontend.decorate(it, "dialogs") }
            dialog.window?.setGravity(Gravity.BOTTOM)
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
            dialog.window?.decorView?.let{frontend.apply(it,"bottomSheets")}
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                fun date(field: EditText): Long? {
                    val raw = field.text.toString().trim()
                    if (raw.isEmpty()) return null
                    val parsed = if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(raw)) runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply { isLenient = false }.parse(raw)?.time }.getOrNull() else null
                    if (parsed == null) field.error = uiString(R.string.invalid_filters)
                    return parsed
                }
                val start = date(from); val end = date(until)
                val low = min.text.toString().replace(",", ".").toDoubleOrNull()
                val high = max.text.toString().replace(",", ".").toDoubleOrNull()
                if ((from.text.isNotBlank() && start == null) || (until.text.isNotBlank() && end == null) ||
                    (min.text.isNotBlank() && (low == null || !low.isFinite() || low <= 1)) ||
                    (max.text.isNotBlank() && (high == null || !high.isFinite() || high <= 1)) ||
                    (low != null && high != null && low > high) || (start != null && end != null && start > end)) {
                    toast(uiString(R.string.invalid_filters)); return@setOnClickListener
                }
                competitionFilter = competition.text.toString().trim()
                minimumOdds = low; maximumOdds = high
                fromDate = start; untilDate = end?.let { java.util.Calendar.getInstance().apply { timeInMillis = it; add(java.util.Calendar.DAY_OF_MONTH, 1) }.timeInMillis }
                resultFilter = statuses[status.selectedItemPosition]
                reloadFeed()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun renderSaved() {
        content.addView(text(uiString(R.string.saved), 23f, ink, true), lp())
        content.addView(text(uiString(R.string.disclaimer), 11f, muted), lp())
        val choices=listOf("","pending","won","lost","voided","postponed","cancelled")
        val select=android.widget.Spinner(this).apply{tag="filters"}
        select.adapter=android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(uiString(R.string.all_results))+ResultStatus.entries.map(::statusLabel))
        select.setSelection(choices.indexOf(savedResultFilter).coerceAtLeast(0))
        select.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?)=Unit
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){savedResultFilter=choices[position];displaySavedItems()}
        }
        content.addView(select,lp())
        predictionCards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "predictionList" }
        content.addView(predictionCards, lp())
        predictionCards.addView(text(uiString(R.string.loading),13f,muted),lp())
        startUserSubscriptions()
    }

    private fun displaySavedItems(){
        if(currentPage!="saved"||!::predictionCards.isInitialized)return
        predictionCards.removeAllViews()
        val selected=savedItems.filter{savedResultFilter.isEmpty()||it.resultStatus.wireValue==savedResultFilter}
        if(selected.isEmpty())predictionCards.addView(text(uiString(R.string.no_saved),13f,muted),lp())
        selected.forEach{addPredictionCard(it,true)}
        if(savedItems.size>=savedLimit)predictionCards.addView(button(uiString(R.string.load_more),false){savedLimit+=50;startUserSubscriptions()},lp())
    }

    private fun renderStats() {
        val requestScreen=screenVersion
        content.addView(text(uiString(R.string.statistics),23f,ink,true),lp())
        content.addView(text("Estatísticas calculadas dos primeiros 250 palpites publicados",11f,muted),lp())
        db?.collection("public_predictions")?.whereEqualTo("editorialState","published")?.limit(250)?.get()
            ?.addOnSuccessListener { snapshot ->
                if(requestScreen!=screenVersion||isDestroyed)return@addOnSuccessListener
                val items=snapshot.documents.mapNotNull{Prediction.fromMap(it.id,it.data)}
                val wins=items.count{it.resultStatus==ResultStatus.WON};val losses=items.count{it.resultStatus==ResultStatus.LOST}
                val pending=items.count{it.resultStatus==ResultStatus.PENDING};val sample=wins+losses
                content.removeAllViews();content.addView(text(uiString(R.string.global_statistics),18f,ink,true),lp())
                addStatsBlock(mapOf("wins" to wins,"losses" to losses,"pending" to pending,"sampleSize" to sample,"excluded" to items.size-sample,"accuracyPercent" to if(sample==0)null else (wins*100.0/sample).let{String.format(Locale.ROOT,"%.1f",it)}),uiString(R.string.global_label))
                content.addView(text("Estatísticas pessoais e métricas privadas não existem neste modo público.",11f,muted),lp())
            }?.addOnFailureListener{if(requestScreen==screenVersion)showError(it)}
    }

    private fun addStatsBlock(data: Map<*, *>, prefix: String) {
        val wins = (data["wins"] as? Number)?.toInt() ?: 0
        val losses = (data["losses"] as? Number)?.toInt() ?: 0
        val pending = (data["pending"] as? Number)?.toInt() ?: 0
        val sample = (data["sampleSize"] as? Number)?.toInt() ?: (wins + losses)
        val accuracy = data["accuracyPercent"]
        addMetric("$prefix · ${uiString(R.string.wins_label)}", wins.toString())
        addMetric("$prefix · ${uiString(R.string.losses_label)}", losses.toString())
        addMetric("$prefix · ${uiString(R.string.pending).lowercase(Locale.getDefault())}", pending.toString())
        addMetric("$prefix · ${uiString(R.string.sample_label)}", sample.toString())
        addMetric("$prefix · ${uiString(R.string.excluded_label)}", ((data["excluded"] as? Number)?.toInt() ?: 0).toString())
        addMetric("$prefix · ${uiString(R.string.accuracy_label)}", if (sample == 0 || accuracy == null) uiString(R.string.no_stats) else "$accuracy%")
    }

    private fun renderSettings() {
        content.addView(text(uiString(R.string.settings),23f,ink,true),lp())
        content.addView(text("Aplicativo público · favoritos armazenados somente neste aparelho",13f,muted).apply{setPadding(0,dp(8),0,dp(16))},lp())
        content.addView(button(uiString(R.string.support_telegram),true){openTelegram()}.apply{tag="support"},lp())
        if(frontend.value?.optBoolean("themeSelectionEnabled",true)!=false){
            val themes=listOf("system","light","dark");val select=android.widget.Spinner(this)
            select.adapter=android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(uiString(R.string.theme_system),uiString(R.string.theme_light),uiString(R.string.theme_dark)))
            val prefs=getSharedPreferences("score_master",MODE_PRIVATE);select.setSelection(themes.indexOf(prefs.getString("theme","system")).coerceAtLeast(0));var first=true
            select.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:android.widget.AdapterView<*>?)=Unit;override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){if(first){first=false;return};prefs.edit().putString("theme",themes[position]).apply();applyFrontendPalette();renderApp("settings")}}
            content.addView(text(uiString(R.string.theme_label),12f,muted),lp());content.addView(select,lp())
        }
        val choices=listOf("Português (Brasil)" to "pt-BR","English" to "en","Español" to "es")
        val language=android.widget.Spinner(this);language.adapter=android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,choices.map{it.first})
        content.addView(text(uiString(R.string.language_label),12f,muted),lp());content.addView(language,lp())
        val current=getSharedPreferences("score_master",MODE_PRIVATE).getString("language","pt-BR")?:"pt-BR";language.setSelection(choices.indexOfFirst{it.second==current}.coerceAtLeast(0));var firstLang=true
        language.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{override fun onNothingSelected(parent:android.widget.AdapterView<*>?)=Unit;override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){if(firstLang){firstLang=false;return};getSharedPreferences("score_master",MODE_PRIVATE).edit().putString("language",choices[position].second).apply();recreate()}}
        content.addView(text("Notificações push e campanhas não estão disponíveis sem um servidor pago. As atualizações do conteúdo aparecem ao abrir ou atualizar o aplicativo.",12f,muted).apply{setPadding(0,dp(18),0,dp(12))},lp())
        for((key,label) in listOf("privacy" to R.string.privacy_policy,"terms" to R.string.terms_label,"about" to R.string.about_label,"contact" to R.string.contact_label))content.addView(button(uiString(label),false){showInstitutionalDocument(key,label)},lp())
        val faq=frontend.value?.optJSONArray("faq");if(faq!=null&&faq.length()>0)content.addView(button(uiString(R.string.faq_label),false){showInstitutionalDocument("faq",R.string.faq_label)},lp())
        content.addView(text(uiFormat(R.string.app_version,packageManager.getPackageInfo(packageName,0).versionName.orEmpty()),12f,muted).apply{tag="footer"},lp())
    }

    private fun languageCode() = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
    private fun showInstitutionalDocument(key:String,label:Int) {
        val document = frontend.value?.optJSONObject("documents")?.optJSONObject(key)
        val body = frontend.localized(document?.optJSONObject("body")) ?: if(key=="privacy") uiString(R.string.privacy_text) else uiString(R.string.content_not_published)
        val panel = text(body,14f,ink).apply {setPadding(dp(18),dp(14),dp(18),dp(14))}
        android.app.AlertDialog.Builder(this).setTitle(frontend.localized(document?.optJSONObject("title"))?:uiString(label))
            .setView(ScrollView(this).apply{addView(panel)}).setPositiveButton(uiString(R.string.close_label),null).show().also {it.window?.decorView?.let{view->frontend.decorate(view,"dialogs")}}
    }

    private fun addPredictionCard(p: Prediction, isSaved: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(surface, 14f)
        }
        card.tag = "predictionCard"
        frontend.apply(card, "predictionCard")
        card.isClickable = true
        card.setOnClickListener { renderPredictionDetail(p.id) }
        card.addView(text(p.competition, 10f, muted), lp())
        card.addView(text("${p.homeTeam}  ×  ${p.awayTeam}", 16f, ink, true).apply { setPadding(0, dp(7), 0, dp(4)) }, lp())
        val whenText = p.startsAt?.let { SimpleDateFormat("EEE d MMM · HH:mm", Locale.getDefault()).format(it) }.orEmpty()
        if (whenText.isNotBlank()) card.addView(text(whenText, 10f, muted), lp())
        card.addView(text("${p.marketName} · ${p.selection}", 12f, ink).apply { setPadding(0, dp(9), 0, dp(6)) }, lp())
        val oddsText = p.odds?.let { uiFormat(R.string.odds_value, it) } ?: uiString(R.string.odds_missing)
        card.addView(text("$oddsText     ·     ${statusLabel(p.resultStatus)}", 11f, green), lp())
        val button = button(if (isSaved) uiString(R.string.remove) else uiString(R.string.save), !isSaved) {
            saveOrRemove(p.id, p.id in savedIds, it)
        }
        card.addView(button, lp().apply { topMargin = dp(10) })
        predictionCards.addView(card, lp().apply { bottomMargin = dp(11) })
    }

    private fun saveOrRemove(id:String,remove:Boolean,button:Button){
        val prefs=getSharedPreferences("score_master",MODE_PRIVATE);val updated=prefs.getStringSet("saved_ids",emptySet()).orEmpty().toMutableSet()
        val editor=prefs.edit()
        if(remove){updated.remove(id);savedIds.remove(id)}else{updated.add(id);savedIds.add(id)}
        if(remove)editor.remove("saved_snapshot_$id") else predictions.firstOrNull{it.id==id}?.let{p->
            val data=mapOf("homeTeam" to p.homeTeam,"awayTeam" to p.awayTeam,"competition" to p.competition,"marketName" to mapOf("pt-BR" to p.marketName),"marketId" to p.marketId,"selection" to p.selection,"odds" to p.odds,"startsAt" to p.startsAt?.time,"resultStatus" to p.resultStatus.wireValue,"country" to p.country,"analysis" to p.analysis,"sources" to p.sources,"legs" to p.legs)
            editor.putString("saved_snapshot_$id",org.json.JSONObject(data).toString())
        }
        editor.putStringSet("saved_ids",updated).apply();savedItems=savedIds.mapNotNull{savedId->prefs.getString("saved_snapshot_$savedId",null)?.let{raw->runCatching{Prediction.fromMap(savedId,jsonMap(org.json.JSONObject(raw)))}.getOrNull()}}.filterNotNull()
        toast(getString(if(remove)R.string.removed_success else R.string.saved_success))
        if(currentPage=="saved")displaySavedItems() else displayPredictions(predictions)
        button.text=uiString(if(id in savedIds)R.string.remove else R.string.save)
    }

    private fun startUserSubscriptions() {
        savedIds.clear()
        val prefs=getSharedPreferences("score_master",MODE_PRIVATE)
        savedIds.addAll(prefs.getStringSet("saved_ids",emptySet()).orEmpty())
        savedItems=savedIds.mapNotNull{savedId->prefs.getString("saved_snapshot_$savedId",null)?.let{raw->runCatching{Prediction.fromMap(savedId,jsonMap(org.json.JSONObject(raw)))}.getOrNull()}}.filterNotNull()
        if(currentPage=="saved" && ::predictionCards.isInitialized)displaySavedItems()
        if(currentPage in listOf("home","explore") && ::predictionCards.isInitialized)displayPredictions(predictions)
    }

    private fun renderPredictionDetail(id:String){
        screenVersion++;val version=screenVersion;predictionListener?.remove();predictionListener=null;currentPage="detail";pendingPredictionId=id
        root=baseRoot();val header=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER_VERTICAL;setPadding(dp(14),dp(10),dp(14),dp(10))}
        header.addView(button("‹  ${uiString(R.string.explore)}",false){pendingPredictionId=null;renderApp("explore")},lp());root.addView(header,lp())
        val scroller=ScrollView(this);content=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setPadding(dp(17),dp(18),dp(17),dp(25))};content.addView(text(uiString(R.string.loading),13f,muted),lp());scroller.addView(content);root.addView(scroller,lp(ViewGroup.LayoutParams.MATCH_PARENT,0,1f));showRoot()
        db?.collection("public_predictions")?.document(id)?.get()?.addOnSuccessListener{doc->
            if(version!=screenVersion||isDestroyed)return@addOnSuccessListener
            if(!doc.exists()||doc.getString("editorialState")!="published"){showTaskError(IllegalStateException("Conteúdo não encontrado."));renderApp("explore");return@addOnSuccessListener}
            val p=Prediction.fromMap(id,doc.data)?:return@addOnSuccessListener;content.removeAllViews()
            if(predictions.none{it.id==p.id})predictions=predictions+p
            content.addView(text(p.competition,12f,muted),lp());content.addView(text("${p.homeTeam} × ${p.awayTeam}",23f,ink,true),lp());content.addView(text(p.marketName,13f,muted),lp());content.addView(text(p.selection,17f,ink,true),lp())
            content.addView(text("${p.odds?.let{uiFormat(R.string.odds_value,it)}?:uiString(R.string.odds_missing)} · ${statusLabel(p.resultStatus)}",12f,green),lp())
            content.addView(button(uiString(if(id in savedIds)R.string.remove else R.string.save),id !in savedIds){saveOrRemove(id,id in savedIds,it)},lp())
            p.analysis?.let{content.addView(text(it,13f,ink),lp())};for(source in p.sources)content.addView(button(source,false){openHttps(source)},lp())
            content.addView(text("Histórico detalhado não está disponível sem Cloud Functions.",11f,muted),lp())
        }?.addOnFailureListener{if(version==screenVersion)showTaskError(it)}
    }

    private fun openPendingTarget(){
        val url=pendingTargetUrl?:return;pendingTargetUrl=null
        if(frontend.approvedHttps(url))openHttps(url)else toast(uiString(R.string.not_available))
    }
    private fun openHttps(url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null) { toast(uiString(R.string.not_available)); return }
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { toast(uiString(R.string.retry_later)) }
    }

    private fun renderInbox(){content.addView(text(uiString(R.string.notifications_title),23f,ink,true),lp());content.addView(text("Notificações push exigem processamento de servidor. No plano gratuito, consulte os palpites publicados na tela inicial.",13f,muted),lp());content.addView(button(uiString(R.string.back_label),false){renderApp("settings")},lp())}

    private fun openTelegram() {
        val telegram = Uri.parse("tg://resolve?domain=haardydev")
        try { startActivity(Intent(Intent.ACTION_VIEW, telegram)) }
        catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/haardydev"))) }
            catch (_: Exception) { toast(uiString(R.string.retry_later)) }
        }
    }

    private fun statusLabel(status: ResultStatus): String = when (status) {
        ResultStatus.PENDING -> uiString(R.string.pending)
        ResultStatus.WON -> uiString(R.string.won)
        ResultStatus.LOST -> uiString(R.string.lost)
        ResultStatus.VOIDED -> uiString(R.string.voided)
        ResultStatus.POSTPONED -> uiString(R.string.postponed)
        ResultStatus.CANCELLED -> uiString(R.string.cancelled)
    }

    private fun showLoading() {
        content.addView(text(uiString(R.string.loading), 12f, muted).apply { setPadding(0, dp(12), 0, 0) }, lp())
    }

    private fun showError(error: Exception) {
        content.removeAllViews()
        content.addView(text(uiString(R.string.retry_later), 13f, Color.rgb(240, 140, 140)), lp())
        content.addView(button(uiString(R.string.retry), false) { renderApp(currentPage) }, lp().apply { topMargin = dp(8) })
    }

    private fun showTaskError(error: Exception) {
        val message = when {
            !firebaseConfigured -> uiString(R.string.backend_missing)
            else -> uiString(R.string.retry_later)
        }
        toast(message)
    }

    private fun sectionTitle(value: String) {
        content.addView(text(value, 15f, ink, true).apply { tag = "sectionTitle"; setPadding(0, 0, 0, dp(10)) }, lp())
    }

    private fun addMetric(label: String, value: String) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(13), dp(13), dp(13)); background = rounded(surface, 12f) }
        card.addView(text(label, 12f, muted), lp(0, -2, 1f))
        card.addView(text(value, 15f, ink, true), lp())
        card.tag = "statisticsCard"
        frontend.apply(card, "statisticsCard")
        content.addView(card, lp().apply { bottomMargin = dp(8) })
    }

    private fun baseRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
    }

    private fun showRoot() {
        val initial = intArrayOf(root.paddingLeft, root.paddingTop, root.paddingRight, root.paddingBottom)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout())
            val keyboard = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime())
            view.setPadding(initial[0] + bars.left, initial[1] + bars.top, initial[2] + bars.right, initial[3] + maxOf(bars.bottom, keyboard.bottom))
            insets
        }
        setContentView(root)
        androidx.core.view.ViewCompat.requestApplyInsets(root)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
        frontend.apply(this, "text")
    }

    private fun edit(hintText: String, secret: Boolean): EditText = EditText(this).apply {
        hint = hintText; textSize = 14f; setTextColor(ink); setHintTextColor(muted)
        setPadding(dp(13), dp(10), dp(13), dp(10))
        background = rounded(surface, 11f)
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        else inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        frontend.apply(this, "field")
    }

    private fun button(label: String, primary: Boolean = false, action: (Button) -> Unit): Button = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false
        setTextColor(if (primary) Color.rgb(4, 34, 24) else ink)
        background = rounded(if (primary) green else line, 10f)
        setOnClickListener { action(this) }
        frontend.apply(this, "button")
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
        if (color == surface) setStroke(dp(1), line)
    }

    private fun lp(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
        LinearLayout.LayoutParams(width, height, weight)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

}
