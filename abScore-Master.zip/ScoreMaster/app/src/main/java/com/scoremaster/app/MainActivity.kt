package com.scoremaster.app

import android.Manifest
import android.app.Activity
import android.app.NotificationChannel
import android.app.NotificationManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.EmailAuthProvider
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessaging
import com.scoremaster.app.domain.ResultStatus
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : Activity() {
    private var bg = Color.rgb(13, 20, 20)
    private var surface = Color.rgb(20, 29, 29)
    private var line = Color.rgb(39, 54, 52)
    private var ink = Color.rgb(239, 246, 242)
    private var muted = Color.rgb(149, 164, 157)
    private var green = Color.rgb(24, 183, 119)

    private val remoteImages = RemoteImages()
    private lateinit var frontend: FrontendConfiguration
    private var configListener: ListenerRegistration? = null
    private var profileListener: ListenerRegistration? = null
    private var exportFile: java.io.File? = null
    private var exportWriter: java.io.BufferedWriter? = null
    private lateinit var root: LinearLayout
    private lateinit var configuredContent: LinearLayout
    private lateinit var content: LinearLayout
    private var predictionListener: ListenerRegistration? = null
    private var savedListener: ListenerRegistration? = null
    private var inboxListener: ListenerRegistration? = null
    private var predictions = emptyList<Prediction>()
    private val savedIds = linkedSetOf<String>()
    private val feedSavedIds = linkedSetOf<String>()
    private var savedItems = emptyList<Prediction>()
    private var savedLimit = 50
    private var savedResultFilter = ""
    private var screenVersion = 0
    private var currentPage = "home"
    private var searchQuery = ""
    private var selectedMarketId = ""
    private var nextFeedCursor: String? = null
    private var feedRequest = 0
    private var feedSort = "kickoff"
    private var inboxLimit = 50
    private var resultFilter = ""
    private var competitionFilter = ""
    private var minimumOdds: Double? = null
    private var maximumOdds: Double? = null
    private var fromDate: Long? = null
    private var untilDate: Long? = null
    private lateinit var predictionCards: LinearLayout
    private val searchHandler = android.os.Handler(android.os.Looper.getMainLooper())
    private var searchUpdate: Runnable? = null
    private var categoryListener: ListenerRegistration? = null
    private var pendingPredictionId: String? = null
    private var pendingTargetUrl: String? = null
    private var profileRegisteredForUid: String? = null
    private var tokenRegisteredForUid: String? = null

    private val firebaseConfigured: Boolean
        get() = FirebaseApp.getApps(applicationContext).isNotEmpty()
    private val auth: FirebaseAuth?
        get() = if (firebaseConfigured) FirebaseAuth.getInstance() else null
    private val db: FirebaseFirestore?
        get() = if (firebaseConfigured) FirebaseFirestore.getInstance() else null
    private val functions: FirebaseFunctions?
        get() = if (firebaseConfigured) FirebaseFunctions.getInstance() else null

    override fun attachBaseContext(newBase: Context) {
        val language = newBase.getSharedPreferences("score_master", MODE_PRIVATE)
            .getString("language", null)
        if (language.isNullOrBlank()) {
            super.attachBaseContext(newBase)
            return
        }
        val config = Configuration(newBase.resources.configuration)
        val selectedLocale = Locale.forLanguageTag(language)
        Locale.setDefault(selectedLocale)
        config.setLocale(selectedLocale)
        super.attachBaseContext(newBase.createConfigurationContext(config))
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        frontend = FrontendConfiguration(this)
        applyFrontendPalette()
        subscribeFrontend()
        window.statusBarColor = bg
        window.navigationBarColor = bg
        createNotificationChannel()
        pendingTargetUrl = intent.getStringExtra("targetUrl")
        pendingPredictionId = intent.getStringExtra("predictionId")
        if (intent.getBooleanExtra("openNotifications", false)) currentPage = "notifications"
        intent.getStringExtra("targetScreen")?.takeIf { it in listOf("home", "explore", "saved", "stats", "settings", "notifications") }?.let { currentPage = it }
        render()
    }

    override fun onResume() {
        super.onResume()
        val user = auth?.currentUser ?: return
        user.reload().addOnSuccessListener {
            if (user.isEmailVerified) {
                user.getIdToken(true).addOnSuccessListener {
                    if (isDestroyed || auth?.currentUser?.uid != user.uid) return@addOnSuccessListener
                    startUserSubscriptions()
                    val deepLink = pendingPredictionId
                    if (deepLink != null) renderPredictionDetail(deepLink) else renderApp(if (currentPage == "login") "home" else currentPage)
                }.addOnFailureListener { showTaskError(it) }
            } else render()
        }
    }

    override fun onDestroy() {
        predictionListener?.remove()
        savedListener?.remove()
        inboxListener?.remove()
        configListener?.remove()
        profileListener?.remove()
        exportWriter?.close()
        categoryListener?.remove()
        screenVersion++
        remoteImages.close()
        searchHandler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    private fun render() {
        predictionListener?.remove()
        predictionListener = null
        val user = auth?.currentUser
        when {
            !firebaseConfigured -> renderAuthGate(configurationMissing = true)
            user == null -> renderAuthGate(configurationMissing = false)
            !user.isEmailVerified -> renderVerificationGate(user.email.orEmpty())
            else -> {
                startUserSubscriptions()
                val deepLink = pendingPredictionId
                if (deepLink != null) renderPredictionDetail(deepLink) else renderApp(if (currentPage == "login") "home" else currentPage)
            }
        }
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        pendingTargetUrl = intent.getStringExtra("targetUrl")
        pendingPredictionId = intent.getStringExtra("predictionId")
        pendingPredictionId?.let { if (auth?.currentUser?.isEmailVerified == true) renderPredictionDetail(it) }
        if (pendingPredictionId == null && intent.getBooleanExtra("openNotifications", false) && auth?.currentUser?.isEmailVerified == true) {
            val target = intent.getStringExtra("targetScreen")?.takeIf { it in listOf("home", "explore", "saved", "stats", "settings", "notifications") } ?: "notifications"
            renderApp(target)
            openPendingTarget()
        }
    }

    @Deprecated("Deprecated in Android SDK; retained for devices using the platform back button")
    override fun onBackPressed() {
        if (currentPage == "detail") {
            pendingPredictionId = null
            renderApp("explore")
        } else super.onBackPressed()
    }

    private fun renderAuthGate(configurationMissing: Boolean) {
        currentPage = "login"
        screenVersion++
        inboxListener?.remove()
        savedListener?.remove()
        savedListener = null
        savedIds.clear()
        tokenRegisteredForUid = null
        profileRegisteredForUid = null
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(bg)
            setPadding(dp(22), dp(28), dp(22), dp(24))
        }
        val scroll = ScrollView(this)
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val logo = android.widget.ImageView(this).apply {
            setImageResource(R.drawable.score_master_logo)
            contentDescription = "Score Master"
            frontend.image("logo")?.let { asset -> remoteImages.load(asset.getString("url"), this); contentDescription = frontend.localized(asset.optJSONObject("alt")) }
            scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
        }
        panel.addView(logo, lp(dp(58), dp(54)).apply { gravity = Gravity.CENTER_HORIZONTAL; bottomMargin = dp(20) })
        panel.addView(text(uiString(R.string.sign_in_title), 25f, ink, true))
        panel.addView(text(uiString(R.string.welcome_body), 14f, muted).apply { setPadding(0, dp(9), 0, dp(20)) })
        val email = edit(uiString(R.string.email), false)
        val password = edit(uiString(R.string.password), true)
        panel.addView(email, lp()); panel.addView(password, lp().apply { topMargin = dp(10) })
        if (configurationMissing) {
            panel.addView(text(uiString(R.string.backend_missing), 13f, Color.rgb(241, 190, 90)).apply {
                setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(Color.rgb(49, 42, 26), 12f)
            }, lp().apply { topMargin = dp(15) })
        }
        val signIn = button(uiString(R.string.login), true) { signIn(email.text.toString(), password.text.toString()) }
        val signUp = button(uiString(R.string.register), false) { signUp(email.text.toString(), password.text.toString()) }.apply { tag = "register" }
        val reset = button(uiString(R.string.forgot_password), false) { resetPassword(email.text.toString()) }
        if (configurationMissing) listOf(signIn, signUp, reset).forEach { it.isEnabled = false; it.alpha = 0.45f }
        panel.addView(signIn, lp().apply { topMargin = dp(15) })
        panel.addView(signUp, lp().apply { topMargin = dp(8) })
        panel.addView(reset, lp().apply { topMargin = dp(4) })
        panel.addView(text(uiString(R.string.disclaimer), 11f, muted).apply { setPadding(0, dp(22), 0, 0) }, lp())
        configuredContent=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        panel.addView(configuredContent,lp());addConfiguredBlocks("login");addConfiguredBlocks("register")
        scroll.addView(panel)
        root.addView(scroll, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frontend.decorate(root, when (currentPage) { "detail" -> "details"; "home" -> "banners"; "saved" -> "history"; "stats" -> "statisticsCard"; else -> currentPage })
        showRoot()
    }

    private fun renderVerificationGate(email: String) {
        currentPage = "login"
        screenVersion++
        root = baseRoot()
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(22), dp(24), dp(22), dp(16)) }
        panel.addView(text(uiString(R.string.email_verification), 19f, ink, true))
        panel.addView(text(email, 13f, muted).apply { setPadding(0, dp(10), 0, dp(16)) })
        panel.addView(button(uiString(R.string.verification_sent)) {
            auth?.currentUser?.sendEmailVerification()?.addOnSuccessListener { toast(uiString(R.string.verification_sent)) }
                ?.addOnFailureListener { showTaskError(it) }
        }, lp())
        panel.addView(button(uiString(R.string.login), false) { auth?.currentUser?.reload()?.addOnSuccessListener {
            auth?.currentUser?.getIdToken(true)?.addOnSuccessListener { render() }
        } }, lp().apply { topMargin = dp(8) })
        panel.addView(button(uiString(R.string.logout), false) { auth?.signOut(); render() }, lp().apply { topMargin = dp(8) })
        root.addView(panel, lp())
        frontend.decorate(root, when (currentPage) { "detail" -> "details"; "home" -> "banners"; "saved" -> "history"; "stats" -> "statisticsCard"; else -> currentPage })
        showRoot()
    }

    private fun signIn(email: String, password: String) {
        if (email.isBlank() || password.isBlank()) { toast(uiString(R.string.retry_later)); return }
        val firebaseAuth = auth ?: run { toast(uiString(R.string.backend_missing)); return }
        firebaseAuth.signInWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { render() }
            .addOnFailureListener { showTaskError(it) }
    }

    private fun signUp(email: String, password: String) {
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches() || password.length < 8) {
            toast(uiString(R.string.required_fields)); return
        }
        val firebaseAuth = auth ?: run { toast(uiString(R.string.backend_missing)); return }
        firebaseAuth.createUserWithEmailAndPassword(email.trim(), password)
            .addOnSuccessListener { result ->
                result.user?.sendEmailVerification()?.addOnSuccessListener {
                    toast(uiString(R.string.verification_sent)); render()
                }?.addOnFailureListener { showTaskError(it) } ?: render()
            }
            .addOnFailureListener { showTaskError(it) }
    }

    private fun resetPassword(email: String) {
        if (!android.util.Patterns.EMAIL_ADDRESS.matcher(email.trim()).matches()) { toast(uiString(R.string.retry_later)); return }
        val firebaseAuth = auth ?: run { toast(uiString(R.string.backend_missing)); return }
        firebaseAuth.sendPasswordResetEmail(email.trim())
            .addOnSuccessListener { toast(uiString(R.string.reset_sent)) }
            .addOnFailureListener { showTaskError(it) }
    }

    private fun renderApp(page: String) {
        if(auth?.currentUser?.isEmailVerified!=true){render();return}
        categoryListener?.remove()
        screenVersion++
        inboxListener?.remove()
        inboxListener = null
        predictionListener?.remove()
        predictionListener = null
        currentPage = page
        root = baseRoot()
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(18), dp(14), dp(18), dp(14))
            background = rounded(surface, 0f)
        }
        header.addView(android.widget.ImageView(this).apply {
            setImageResource(R.drawable.score_master_logo)
            contentDescription = "Score Master"
            frontend.image("logo")?.let { asset -> remoteImages.load(asset.getString("url"), this); contentDescription = frontend.localized(asset.optJSONObject("alt")) }
        }, lp(dp(42), dp(42)))
        header.addView(text("Score Master", 17f, ink, true).apply { setPadding(dp(10), 0, 0, 0) }, lp(0, -2, 1f))
        header.tag = "header"
        frontend.apply(header, "header")
        root.addView(header, lp())
        val scroller = ScrollView(this).apply { fillViewport = true }
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(18), dp(17), dp(24)) }
        configuredContent = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), 0, dp(17), dp(16)) }
        val scrollBody = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        scrollBody.addView(content, lp())
        scrollBody.addView(configuredContent, lp())
        scroller.addView(scrollBody)
        root.addView(scroller, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER; setPadding(dp(4), dp(7), dp(4), dp(7)); background = rounded(surface, 0f) }
        val items = listOf("home" to R.string.home, "explore" to R.string.explore, "saved" to R.string.saved, "stats" to R.string.statistics, "settings" to R.string.settings)
        items.forEach { (id, label) ->
            val b = Button(this).apply {
                text = uiString(label)
                textSize = 10f
                isAllCaps = false
                setTextColor(if (currentPage == id) green else muted)
                setBackgroundColor(Color.TRANSPARENT)
                setOnClickListener { renderApp(id) }
            }
            b.minHeight=dp(48)
            nav.addView(b, LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f))
        }
        nav.tag = "navigation"
        frontend.apply(nav, "navigation")
        root.addView(nav, lp())
        frontend.decorate(root, when (currentPage) { "detail" -> "details"; "home" -> "banners"; "saved" -> "history"; "stats" -> "statisticsCard"; else -> currentPage })
        showRoot()
        when (page) {
            "home" -> renderHome()
            "explore" -> renderExplore()
            "saved" -> renderSaved()
            "stats" -> renderStats()
            "notifications" -> renderInbox()
            else -> renderSettings()
        }
        frontend.arrange(content, page)
        addConfiguredBlocks(page)
        frontend.decorate(content,when(page){"home"->"banners";"stats"->"statisticsCard";"saved"->"history";else->page})
        openPendingTarget()
    }

    private fun uiString(id: Int): String {
        val key = resources.getResourceEntryName(id)
        if (key in setOf("disclaimer", "email_verification", "backend_missing", "auth_required", "pending", "won", "lost", "voided", "postponed", "cancelled")) return getString(id)
        return frontend.text(key) ?: getString(id)
    }
    private fun uiFormat(id:Int,vararg arguments:Any):String = runCatching {String.format(Locale.getDefault(),uiString(id),*arguments)}.getOrElse {getString(id,*arguments)}

    private fun applyFrontendPalette() {
        bg = frontend.color("background", Color.rgb(13, 20, 20)); surface = frontend.color("surface", Color.rgb(20, 29, 29))
        line = frontend.color("line", Color.rgb(39, 54, 52)); ink = frontend.color("ink", Color.rgb(239, 246, 242))
        muted = frontend.color("muted", Color.rgb(149, 164, 157)); green = frontend.color("accent", Color.rgb(24, 183, 119))
        val preference = getSharedPreferences("score_master",MODE_PRIVATE).getString("theme","system")
        val systemDark = resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK == Configuration.UI_MODE_NIGHT_YES
        if (frontend.value?.optBoolean("themeSelectionEnabled",true) != false && (preference == "light" || (preference == "system" && !systemDark))) {
            bg = frontend.lightColor("background",Color.rgb(243,247,245)); surface = frontend.lightColor("surface",Color.WHITE)
            line = frontend.lightColor("line",Color.rgb(196,208,202)); ink = frontend.lightColor("ink",Color.rgb(16,37,28))
            muted = frontend.lightColor("muted",Color.rgb(66,92,80)); green = frontend.lightColor("accent",Color.rgb(8,122,75))
        }
    }

    private fun subscribeFrontend() {
        configListener = db?.collection("app_config")?.document("current")?.addSnapshotListener { doc, error ->
            if (error != null || isDestroyed) return@addSnapshotListener
            val data = doc?.get("configuration") as? Map<*, *> ?: return@addSnapshotListener
            val candidate = org.json.JSONObject(data)
            if (candidate.toString() == frontend.value?.toString()) return@addSnapshotListener
            if (!frontend.accept(candidate)) {
                android.util.Log.w("ScoreMaster", "Configuração incompatível ignorada; última configuração válida preservada.")
                return@addSnapshotListener
            }
            applyFrontendPalette()
            if (currentPage == "detail") { pendingPredictionId?.let(::renderPredictionDetail); return@addSnapshotListener }
            render()
        }
    }

    private fun addConfiguredBlocks(page: String) {
        val blocks = frontend.value?.optJSONObject("pages")?.optJSONArray(page) ?: return
        for (i in 0 until blocks.length()) {
            val block = blocks.optJSONObject(i) ?: continue
            if (!block.optBoolean("visible", true)) continue
            val label = frontend.localized(block.optJSONObject("text")).orEmpty()
            val view: View = when (block.optString("type")) {
                "button" -> button(label, false) {
                    val action = block.optString("action")
                    if (action == "support:telegram") openTelegram()
                    else if (action in FrontendConfiguration.allowedActions) renderApp(action.substringAfter(":"))
                }
                "image" -> android.widget.ImageView(this).apply {
                    adjustViewBounds = true
                    minimumHeight = dp(80)
                    scaleType = android.widget.ImageView.ScaleType.FIT_CENTER
                    remoteImages.load(block.optString("imageUrl"), this)
                }
                "divider" -> View(this).apply { setBackgroundColor(line); minimumHeight = dp(1) }
                else -> text(label, 14f, ink)
            }
            view.contentDescription = frontend.localized(block.optJSONObject("accessibility")) ?: label
            configuredContent.addView(view, lp().apply { topMargin = dp(8) })
            frontend.apply(view, "text", block.optJSONObject("style"))
        }
    }

    private fun renderHome() {
        content.addView(text(uiString(R.string.welcome_title), 24f, ink, true).apply { tag = "welcomeTitle" }, lp())
        content.addView(text(uiString(R.string.welcome_body), 13f, muted).apply { tag = "welcomeBody"; setPadding(0, dp(5), 0, dp(15)) }, lp())
        content.addView(text(uiString(R.string.disclaimer), 11f, Color.rgb(203, 191, 146)).apply {
            setPadding(dp(12), dp(12), dp(12), dp(12)); background = rounded(Color.rgb(43, 39, 27), 12f)
        }, lp().apply { bottomMargin = dp(15) })
        sectionTitle(uiString(R.string.explore))
        predictionCards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "predictionList" }
        content.addView(predictionCards, lp())
        predictionCards.addView(text(uiString(R.string.loading), 12f, muted), lp())
        subscribePredictions()
    }

    private fun renderExplore() {
        content.addView(text(uiString(R.string.explore), 23f, ink, true), lp())
        val search = edit(uiString(R.string.search_hint), false).apply { tag = "search"; inputType = android.text.InputType.TYPE_CLASS_TEXT }
        search.setSingleLine(true)
        search.setText(searchQuery)
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { searchQuery = s?.toString().orEmpty()
                searchUpdate?.let(searchHandler::removeCallbacks)
                searchUpdate = Runnable { if (currentPage == "explore" && !isDestroyed) reloadFeed() }
                searchHandler.postDelayed(searchUpdate!!, 300) }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        content.addView(search, lp().apply { topMargin = dp(12); bottomMargin = dp(12) })
        val sorting=android.widget.Spinner(this).apply{tag="tabs"}
        val sorts=listOf("recent","kickoff","market")
        sorting.adapter=android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(uiString(R.string.sort_recent),uiString(R.string.sort_kickoff),uiString(R.string.sort_market)))
        sorting.setSelection(sorts.indexOf(feedSort).coerceAtLeast(0));var firstSort=true
        sorting.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?)=Unit
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){if(firstSort){firstSort=false;return};feedSort=sorts[position];reloadFeed()}
        }
        content.addView(sorting,lp())
        val markets = android.widget.Spinner(this).apply { tag = "marketFilters" }
        content.addView(markets, lp().apply { bottomMargin = dp(12) })
        val requestScreen = screenVersion
        categoryListener = db?.collection("market_categories")?.whereEqualTo("active", true)?.addSnapshotListener { snapshot, error ->
            if (requestScreen != screenVersion || isDestroyed || error != null) return@addSnapshotListener
            val categories = snapshot?.documents?.sortedBy { it.getLong("order") ?: 0 }.orEmpty()
            val language = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
            val names = listOf(uiString(R.string.all_markets)) + categories.map { (it.get("name") as? Map<*, *>)?.let { name -> name[language] as? String ?: name["pt-BR"] as? String } ?: it.id }
            markets.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, names)
            markets.setSelection((categories.indexOfFirst { it.id == selectedMarketId } + 1).coerceAtLeast(0))
            markets.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                    selectedMarketId = if (position == 0) "" else categories[position - 1].id
                    reloadFeed()
                }
            }
        }
        content.addView(button(uiString(R.string.apply_filters), false) { showFilterDialog() }.apply { tag = "filterButton" }, lp())
        content.addView(text(uiString(R.string.filter_scope), 11f, muted).apply { tag = "filtersExplanation" }, lp())
        predictionCards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "predictionList" }
        content.addView(predictionCards, lp())
        predictionCards.addView(text(uiString(R.string.loading), 12f, muted), lp())
        subscribePredictions()
    }

    private fun feedFilters():Map<String,Any> = if(currentPage=="home") emptyMap() else buildMap {
        put("search",searchQuery);put("marketId",selectedMarketId);put("resultStatus",resultFilter);put("competition",competitionFilter)
        minimumOdds?.let{put("minimumOdds",it)};maximumOdds?.let{put("maximumOdds",it)};fromDate?.let{put("fromDate",it)};untilDate?.let{put("untilDate",it)}
    }
    private fun subscribePredictions() {
        if(!firebaseConfigured)return
        predictionListener?.remove()
        val requestScreen=screenVersion
        predictionListener=db?.collection("predictions")?.whereEqualTo("editorialState","published")?.orderBy("updatedAt",Query.Direction.DESCENDING)?.limit(1)
            ?.addSnapshotListener { snapshot,error ->
                if(requestScreen!=screenVersion||isDestroyed)return@addSnapshotListener
                if(error!=null){showTaskError(error);return@addSnapshotListener}
                if(snapshot?.metadata?.isFromCache==false)reloadFeed()
            }
        reloadFeed()
    }
    private fun reloadFeed(){nextFeedCursor=null;feedRequest++;loadFeedPage(null,feedRequest)}
    private fun loadFeedPage(cursor:String?,request:Int){
        val requestScreen=screenVersion
        val payload=mutableMapOf<String,Any>("filters" to feedFilters(),"sort" to if(currentPage=="home")"recent" else feedSort)
        if(cursor!=null)payload["cursor"]=cursor
        functions?.getHttpsCallable("listPublishedPredictions")?.call(payload)?.addOnSuccessListener { result ->
            if(requestScreen!=screenVersion||request!=feedRequest||isDestroyed)return@addOnSuccessListener
            val response=result.data as? Map<*,*>?:return@addOnSuccessListener
            val rows=response["items"] as? List<*>?:emptyList<Any>()
            val items=rows.mapNotNull{val row=it as? Map<*,*>?:return@mapNotNull null;Prediction.fromMap(row["predictionId"] as? String?:return@mapNotNull null,row["snapshot"] as? Map<*,*>)}
            if(cursor==null){predictions=items;feedSavedIds.clear()}else predictions=predictions+items
            feedSavedIds.addAll((response["savedIds"] as? List<*>)?.filterIsInstance<String>().orEmpty());savedIds.addAll(feedSavedIds)
            nextFeedCursor=response["nextCursor"] as? String
            if(cursor==null){getSharedPreferences("feed_cache_${auth?.currentUser?.uid}",MODE_PRIVATE).edit().putString("data",org.json.JSONObject(response).toString()).putString("filter",org.json.JSONObject(payload).toString()).apply()}
            displayPredictions(predictions)
        }?.addOnFailureListener{error ->
            if(requestScreen!=screenVersion||request!=feedRequest||isDestroyed)return@addOnFailureListener
            if(cursor==null){
                val prefs=getSharedPreferences("feed_cache_${auth?.currentUser?.uid}",MODE_PRIVATE)
                if(prefs.getString("filter",null)==org.json.JSONObject(payload).toString())runCatching {
                    val cached=org.json.JSONObject(prefs.getString("data","")!!);val rows=cached.getJSONArray("items")
                    predictions=(0 until rows.length()).mapNotNull{val row=rows.getJSONObject(it);val data=row.getJSONObject("snapshot");Prediction.fromMap(row.getString("predictionId"),jsonMap(data))};nextFeedCursor=null;displayPredictions(predictions)
                    predictionCards.addView(text(uiString(R.string.offline_cached),12f,muted),lp())
                }
            }
            showTaskError(error)
        }
    }
    private fun jsonMap(value:org.json.JSONObject):Map<String,Any?> {
        fun convert(item:Any?):Any?=when(item){org.json.JSONObject.NULL->null;is org.json.JSONObject->jsonMap(item);is org.json.JSONArray->(0 until item.length()).map{convert(item.opt(it))};else->item}
        return value.keys().asSequence().associateWith{convert(value.opt(it))}
    }
    private fun displayPredictions(items: List<Prediction>) {
        if(!::predictionCards.isInitialized||currentPage !in listOf("home","explore"))return
        predictionCards.removeAllViews()
        if(items.isEmpty())predictionCards.addView(text(uiString(R.string.no_predictions),13f,muted),lp())
        items.forEach{addPredictionCard(it,it.id in savedIds)}
        if(nextFeedCursor!=null)predictionCards.addView(button(uiString(R.string.load_more),false){clicked->clicked.isEnabled=false;loadFeedPage(nextFeedCursor,feedRequest)},lp())
    }

    private fun showFilterDialog() {
        val panel = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(16), dp(8), dp(16), dp(8)) }
        val competition = edit(uiString(R.string.competition_filter), false).apply { inputType = android.text.InputType.TYPE_CLASS_TEXT; setText(competitionFilter) }
        val min = edit(uiString(R.string.min_odds), false).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(minimumOdds?.toString().orEmpty()) }
        val max = edit(uiString(R.string.max_odds), false).apply { inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(maximumOdds?.toString().orEmpty()) }
        val from = edit(uiString(R.string.date_from), false).apply { inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_DATE }
        val until = edit(uiString(R.string.date_until), false).apply { inputType = android.text.InputType.TYPE_CLASS_DATETIME or android.text.InputType.TYPE_DATETIME_VARIATION_DATE }
        val status = android.widget.Spinner(this)
        val statuses = listOf("", "pending", "won", "lost", "voided", "postponed", "cancelled")
        status.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, listOf(uiString(R.string.all_results)) + com.scoremaster.app.domain.ResultStatus.entries.map(::statusLabel))
        status.setSelection(statuses.indexOf(resultFilter).coerceAtLeast(0))
        listOf(competition, min, max, from, until, status).forEach { panel.addView(it, lp().apply { topMargin = dp(6) }) }
        val scroll = ScrollView(this).apply { addView(panel) }
        val dialog = android.app.AlertDialog.Builder(this).setTitle(uiString(R.string.apply_filters)).setView(scroll)
            .setNegativeButton(uiString(R.string.cancel_label), null)
            .setPositiveButton(uiString(R.string.apply_filters), null).create()
        dialog.setOnShowListener {
            dialog.window?.decorView?.let { frontend.decorate(it, "dialogs") }
            dialog.window?.setGravity(Gravity.BOTTOM)
            dialog.window?.setLayout(ViewGroup.LayoutParams.MATCH_PARENT,ViewGroup.LayoutParams.WRAP_CONTENT)
            dialog.window?.decorView?.let{frontend.apply(it,"bottomSheets")}
            dialog.getButton(android.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                fun date(field: EditText): Long? {
                    val raw = field.text.toString().trim()
                    if (raw.isEmpty()) return null
                    val parsed = if (Regex("\\d{4}-\\d{2}-\\d{2}").matches(raw)) runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.ROOT).apply { isLenient = false }.parse(raw)?.time }.getOrNull() else null
                    if (parsed == null) field.error = uiString(R.string.invalid_filters)
                    return parsed
                }
                val start = date(from); val end = date(until)
                val low = min.text.toString().replace(",", ".").toDoubleOrNull()
                val high = max.text.toString().replace(",", ".").toDoubleOrNull()
                if ((from.text.isNotBlank() && start == null) || (until.text.isNotBlank() && end == null) ||
                    (min.text.isNotBlank() && (low == null || !low.isFinite() || low <= 1)) ||
                    (max.text.isNotBlank() && (high == null || !high.isFinite() || high <= 1)) ||
                    (low != null && high != null && low > high) || (start != null && end != null && start > end)) {
                    toast(uiString(R.string.invalid_filters)); return@setOnClickListener
                }
                competitionFilter = competition.text.toString().trim()
                minimumOdds = low; maximumOdds = high
                fromDate = start; untilDate = end?.let { java.util.Calendar.getInstance().apply { timeInMillis = it; add(java.util.Calendar.DAY_OF_MONTH, 1) }.timeInMillis }
                resultFilter = statuses[status.selectedItemPosition]
                reloadFeed()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun renderSaved() {
        content.addView(text(uiString(R.string.saved), 23f, ink, true), lp())
        content.addView(text(uiString(R.string.disclaimer), 11f, muted), lp())
        val choices=listOf("","pending","won","lost","voided","postponed","cancelled")
        val select=android.widget.Spinner(this).apply{tag="filters"}
        select.adapter=android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(uiString(R.string.all_results))+ResultStatus.entries.map(::statusLabel))
        select.setSelection(choices.indexOf(savedResultFilter).coerceAtLeast(0))
        select.onItemSelectedListener=object:android.widget.AdapterView.OnItemSelectedListener{
            override fun onNothingSelected(parent:android.widget.AdapterView<*>?)=Unit
            override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long){savedResultFilter=choices[position];displaySavedItems()}
        }
        content.addView(select,lp())
        predictionCards = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; tag = "predictionList" }
        content.addView(predictionCards, lp())
        predictionCards.addView(text(uiString(R.string.loading),13f,muted),lp())
        startUserSubscriptions()
    }

    private fun displaySavedItems(){
        if(currentPage!="saved"||!::predictionCards.isInitialized)return
        predictionCards.removeAllViews()
        val selected=savedItems.filter{savedResultFilter.isEmpty()||it.resultStatus.wireValue==savedResultFilter}
        if(selected.isEmpty())predictionCards.addView(text(uiString(R.string.no_saved),13f,muted),lp())
        selected.forEach{addPredictionCard(it,true)}
        if(savedItems.size>=savedLimit)predictionCards.addView(button(uiString(R.string.load_more),false){savedLimit+=50;startUserSubscriptions()},lp())
    }

    private fun renderStats() {
        val requestScreen = screenVersion
        content.addView(text(uiString(R.string.statistics), 23f, ink, true), lp())
        content.addView(text(uiString(R.string.server_updated), 11f, muted).apply { setPadding(0, dp(4), 0, dp(14)) }, lp())
        if (!firebaseConfigured) { content.addView(text(uiString(R.string.backend_missing), 13f, muted), lp()); return }
        showLoading()
        val callable = functions ?: return
        val generalTask = callable.getHttpsCallable("getGlobalStats").call(emptyMap<String, Any>())
        val personalTask = callable.getHttpsCallable("getPersonalStats").call(emptyMap<String, Any>())
        generalTask.addOnSuccessListener { generalResult ->
            personalTask.addOnSuccessListener { personalResult ->
                if (requestScreen != screenVersion || isDestroyed) return@addOnSuccessListener
                content.removeAllViews()
                content.addView(text(uiString(R.string.global_statistics), 18f, ink, true), lp())
                addStatsBlock(generalResult.data as? Map<*, *> ?: emptyMap<Any, Any>(), uiString(R.string.global_label))
                content.addView(text(uiString(R.string.personal_statistics), 18f, ink, true).apply { setPadding(0, dp(18), 0, dp(8)) }, lp())
                addStatsBlock(personalResult.data as? Map<*, *> ?: emptyMap<Any, Any>(), uiString(R.string.personal_label))
                content.addView(text(uiString(R.string.stats_explanation), 11f, muted), lp().apply { topMargin = dp(10) })
                frontend.decorate(content,"statisticsCard")
            }.addOnFailureListener { if (requestScreen == screenVersion && !isDestroyed) showError(it) }
        }.addOnFailureListener { if (requestScreen == screenVersion && !isDestroyed) showError(it) }
    }

    private fun addStatsBlock(data: Map<*, *>, prefix: String) {
        val wins = (data["wins"] as? Number)?.toInt() ?: 0
        val losses = (data["losses"] as? Number)?.toInt() ?: 0
        val pending = (data["pending"] as? Number)?.toInt() ?: 0
        val sample = (data["sampleSize"] as? Number)?.toInt() ?: (wins + losses)
        val accuracy = data["accuracyPercent"]
        addMetric("$prefix · ${uiString(R.string.wins_label)}", wins.toString())
        addMetric("$prefix · ${uiString(R.string.losses_label)}", losses.toString())
        addMetric("$prefix · ${uiString(R.string.pending).lowercase(Locale.getDefault())}", pending.toString())
        addMetric("$prefix · ${uiString(R.string.sample_label)}", sample.toString())
        addMetric("$prefix · ${uiString(R.string.excluded_label)}", ((data["excluded"] as? Number)?.toInt() ?: 0).toString())
        addMetric("$prefix · ${uiString(R.string.accuracy_label)}", if (sample == 0 || accuracy == null) uiString(R.string.no_stats) else "$accuracy%")
    }

    private fun renderSettings() {
        content.addView(text(uiString(R.string.settings), 23f, ink, true), lp())
        content.addView(text(uiFormat(R.string.account_label, auth?.currentUser?.email.orEmpty()), 13f, muted).apply { setPadding(0, dp(8), 0, dp(16)) }, lp())
        content.addView(button(uiString(R.string.support_telegram), true) { openTelegram() }.apply { tag = "support" }, lp())
        content.addView(text(uiFormat(R.string.app_version,packageManager.getPackageInfo(packageName,0).versionName.orEmpty()),12f,muted).apply { tag = "footer" },lp())
        if (frontend.value?.optBoolean("themeSelectionEnabled",true) != false) {
            val themes = listOf("system","light","dark")
            val select = android.widget.Spinner(this).apply { tag = "menus" }
            select.adapter = android.widget.ArrayAdapter(this,android.R.layout.simple_spinner_dropdown_item,listOf(uiString(R.string.theme_system),uiString(R.string.theme_light),uiString(R.string.theme_dark)))
            val chosen = getSharedPreferences("score_master",MODE_PRIVATE).getString("theme","system")
            select.setSelection(themes.indexOf(chosen).coerceAtLeast(0))
            var first = true
            select.onItemSelectedListener = object:android.widget.AdapterView.OnItemSelectedListener {
                override fun onNothingSelected(parent:android.widget.AdapterView<*>?) = Unit
                override fun onItemSelected(parent:android.widget.AdapterView<*>?,view:View?,position:Int,id:Long) {
                    if(first){first=false;return}
                    val mode=themes[position]
                    if(mode != chosen) functions?.getHttpsCallable("updateMyPreferences")?.call(mapOf("theme" to mode,"language" to languageCode()))
                        ?.addOnSuccessListener { getSharedPreferences("score_master",MODE_PRIVATE).edit().putString("theme",mode).apply();applyFrontendPalette();renderApp("settings") }
                        ?.addOnFailureListener { showTaskError(it) }
                }
            }
            content.addView(text(uiString(R.string.theme_label),12f,muted),lp());content.addView(select,lp())
        }
        val language = android.widget.Spinner(this)
        val choices = listOf("Português (Brasil)" to "pt-BR", "English" to "en", "Español" to "es")
        language.adapter = android.widget.ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, choices.map { it.first })
        content.addView(text(uiString(R.string.language_label), 12f, muted).apply { setPadding(0, dp(15), 0, dp(6)) }, lp())
        content.addView(language, lp())
        val current = getSharedPreferences("score_master", MODE_PRIVATE).getString("language", "pt-BR") ?: "pt-BR"
        language.setSelection(choices.indexOfFirst { it.second == current }.coerceAtLeast(0))
        var ignoreInitialLanguageEvent = true
        language.onItemSelectedListener = object : android.widget.AdapterView.OnItemSelectedListener {
            override fun onNothingSelected(parent: android.widget.AdapterView<*>?) = Unit
            override fun onItemSelected(parent: android.widget.AdapterView<*>?, view: View?, position: Int, id: Long) {
                if (ignoreInitialLanguageEvent) { ignoreInitialLanguageEvent = false; return }
                val chosen = choices[position].second
                if (chosen != current) {
                    functions?.getHttpsCallable("updateMyPreferences")?.call(mapOf("language" to chosen))
                        ?.addOnSuccessListener {
                            getSharedPreferences("score_master", MODE_PRIVATE).edit().putString("language", chosen).apply()
                            recreate()
                        }?.addOnFailureListener { showTaskError(it) }
                }
            }
        }
        content.addView(text(uiString(R.string.disclaimer), 11f, muted).apply { setPadding(0, dp(18), 0, dp(12)) }, lp())
        content.addView(button(uiString(R.string.notifications_title), false) { renderApp("notifications") }, lp())
        content.addView(button(uiString(R.string.enable_notifications), false) {
            functions?.getHttpsCallable("updateMyPreferences")?.call(mapOf("language" to current, "notificationsEnabled" to true))
                ?.addOnSuccessListener { requestNotificationPermissionIfNeeded(); toast(uiString(R.string.preference_saved)) }
                ?.addOnFailureListener { showTaskError(it) }
        }, lp())
        content.addView(button(uiString(R.string.disable_notifications), false) {
            functions?.getHttpsCallable("updateMyPreferences")?.call(mapOf("language" to current, "notificationsEnabled" to false))
                ?.addOnSuccessListener { toast(uiString(R.string.notifications_disabled)) }
                ?.addOnFailureListener { showTaskError(it) }
        }, lp())
        for ((category, title) in listOf("general" to R.string.notifications_general, "predictions" to R.string.notifications_predictions, "results" to R.string.notifications_results)) {
            val requestScreen = screenVersion
            val toggle = android.widget.Switch(this).apply { text = uiString(title); setTextColor(ink); isEnabled = false }
            content.addView(toggle, lp())
            auth?.currentUser?.uid?.let { uid -> db?.collection("users")?.document(uid)?.get()
                ?.addOnSuccessListener { profile ->
                    if (requestScreen != screenVersion || currentPage != "settings") return@addOnSuccessListener
                    toggle.isChecked = profile.getBoolean("preferences.categories.$category") != false
                    toggle.isEnabled = true
                    var reverting = false
                    toggle.setOnCheckedChangeListener { _, enabled ->
                        if (!reverting) {
                            toggle.isEnabled = false
                            functions?.getHttpsCallable("updateMyPreferences")?.call(mapOf("language" to current, "categories" to mapOf(category to enabled)))
                                ?.addOnSuccessListener { toggle.isEnabled = true }
                                ?.addOnFailureListener { reverting = true; toggle.isChecked = !enabled; reverting = false; toggle.isEnabled = true; showTaskError(it) }
                        }
                    }
                }?.addOnFailureListener { showTaskError(it) }
            }
        }
        for ((key,label) in listOf("privacy" to R.string.privacy_policy,"terms" to R.string.terms_label,"about" to R.string.about_label,"contact" to R.string.contact_label)) {
            content.addView(button(uiString(label),false) { showInstitutionalDocument(key,label) },lp())
        }
        val faq = frontend.value?.optJSONArray("faq")
        if (faq != null && faq.length()>0) content.addView(button(uiString(R.string.faq_label),false) {
            val panel=LinearLayout(this).apply { orientation=LinearLayout.VERTICAL;setPadding(dp(18),dp(14),dp(18),dp(14)) }
            for(index in 0 until faq.length()){val entry=faq.getJSONObject(index);panel.addView(text(frontend.localized(entry.optJSONObject("question")).orEmpty(),16f,ink,true),lp());panel.addView(text(frontend.localized(entry.optJSONObject("answer")).orEmpty(),14f,ink),lp().apply{bottomMargin=dp(18)})}
            android.app.AlertDialog.Builder(this).setTitle(uiString(R.string.faq_label)).setView(ScrollView(this).apply{addView(panel)}).setPositiveButton(uiString(R.string.close_label),null).show()
        },lp())
        content.addView(button(uiString(R.string.export_data), false) { callAccountFunction("requestAccountExport") }, lp())
        content.addView(button(uiString(R.string.delete_account), false) { confirmDeleteAccount() }, lp().apply { topMargin = dp(7) })
        content.addView(button(uiString(R.string.logout), false) { logoutAccount(); }, lp().apply { topMargin = dp(7) })
    }

    private fun languageCode() = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
    private fun showInstitutionalDocument(key:String,label:Int) {
        val document = frontend.value?.optJSONObject("documents")?.optJSONObject(key)
        val body = frontend.localized(document?.optJSONObject("body")) ?: if(key=="privacy") uiString(R.string.privacy_text) else uiString(R.string.content_not_published)
        val panel = text(body,14f,ink).apply {setPadding(dp(18),dp(14),dp(18),dp(14))}
        android.app.AlertDialog.Builder(this).setTitle(frontend.localized(document?.optJSONObject("title"))?:uiString(label))
            .setView(ScrollView(this).apply{addView(panel)}).setPositiveButton(uiString(R.string.close_label),null).show().also {it.window?.decorView?.let{view->frontend.decorate(view,"dialogs")}}
    }

    private fun addPredictionCard(p: Prediction, isSaved: Boolean) {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(13), dp(14), dp(13))
            background = rounded(surface, 14f)
        }
        card.tag = "predictionCard"
        frontend.apply(card, "predictionCard")
        card.isClickable = true
        card.setOnClickListener { renderPredictionDetail(p.id) }
        card.addView(text(p.competition, 10f, muted), lp())
        card.addView(text("${p.homeTeam}  ×  ${p.awayTeam}", 16f, ink, true).apply { setPadding(0, dp(7), 0, dp(4)) }, lp())
        val whenText = p.startsAt?.let { SimpleDateFormat("EEE d MMM · HH:mm", Locale.getDefault()).format(it) }.orEmpty()
        if (whenText.isNotBlank()) card.addView(text(whenText, 10f, muted), lp())
        card.addView(text("${p.marketName} · ${p.selection}", 12f, ink).apply { setPadding(0, dp(9), 0, dp(6)) }, lp())
        val oddsText = p.odds?.let { uiFormat(R.string.odds_value, it) } ?: uiString(R.string.odds_missing)
        card.addView(text("$oddsText     ·     ${statusLabel(p.resultStatus)}", 11f, green), lp())
        val button = button(if (isSaved) uiString(R.string.remove) else uiString(R.string.save), !isSaved) {
            saveOrRemove(p.id, p.id in savedIds, it)
        }
        card.addView(button, lp().apply { topMargin = dp(10) })
        predictionCards.addView(card, lp().apply { bottomMargin = dp(11) })
    }

    private fun saveOrRemove(id: String, remove: Boolean, button: Button) {
        val functionName = if (remove) "unsavePrediction" else "savePrediction"
        button.isEnabled = false
        button.text = uiString(R.string.syncing)
        functions?.getHttpsCallable(functionName)?.call(mapOf("predictionId" to id))
            ?.addOnSuccessListener {
                button.isEnabled = true
                if (remove) {savedIds.remove(id);feedSavedIds.remove(id)} else {savedIds.add(id);feedSavedIds.add(id)}
                toast(getString(if (remove) R.string.removed_success else R.string.saved_success))
                button.text = getString(if (id in savedIds) R.string.remove else R.string.save)
                if (currentPage == "explore" || currentPage == "home") displayPredictions(predictions)
                if (currentPage == "saved") renderApp("saved")
            }
            ?.addOnFailureListener {
                button.isEnabled = true
                button.text = getString(if (remove) R.string.remove else R.string.save)
                showTaskError(it)
            } ?: run { button.isEnabled = true; button.text = uiString(R.string.save); toast(uiString(R.string.backend_missing)) }
    }

    private fun startUserSubscriptions() {
        val uid = auth?.currentUser?.uid ?: return
        if (profileRegisteredForUid != uid) {
            profileRegisteredForUid=uid;profileListener?.remove()
            profileListener=db?.collection("users")?.document(uid)?.addSnapshotListener { profile,error ->
                if(error!=null || auth?.currentUser?.uid!=uid)return@addSnapshotListener
                if(profile?.getBoolean("disabled")==true){clearAccountSession();render();return@addSnapshotListener}
                val language=profile?.getString("language")?.takeIf{it in listOf("pt-BR","en","es")}
                val theme=profile?.getString("theme")?.takeIf{it in listOf("system","light","dark")}
                val prefs=getSharedPreferences("score_master",MODE_PRIVATE)
                var reload=false
                if(language!=null&&language!=prefs.getString("language","pt-BR")){prefs.edit().putString("language",language).apply();reload=true}
                if(theme!=null&&theme!=prefs.getString("theme","system")){prefs.edit().putString("theme",theme).apply();reload=true}
                if(reload)recreate()
            }
        }
        savedListener?.remove()
        savedListener = db?.collection("users")?.document(uid)?.collection("saved_predictions")
            ?.orderBy("savedAt",Query.Direction.DESCENDING)?.limit(savedLimit.toLong())
            ?.addSnapshotListener { snapshot, error ->
                if (error != null) return@addSnapshotListener
                savedIds.clear();savedIds.addAll(feedSavedIds); savedIds.addAll(snapshot?.documents?.map { it.id }.orEmpty())
                if (currentPage == "home" || currentPage == "explore") displayPredictions(predictions)
                if (currentPage == "saved") {
                    savedItems = snapshot?.documents?.mapNotNull { Prediction.fromMap(it.id,it.get("snapshot") as? Map<*,*>) }.orEmpty()
                    displaySavedItems()
                }
                if(currentPage=="stats" && snapshot?.metadata?.isFromCache==false)renderApp("stats")
            }
        if (tokenRegisteredForUid != uid) {
            registerMessagingToken(uid)
        }
    }

    private fun registerMessagingToken(uid: String) {
        if (!firebaseConfigured) return
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            if (auth?.currentUser?.uid != uid) return@addOnSuccessListener
            functions?.getHttpsCallable("registerDeviceToken")?.call(mapOf("token" to token, "platform" to "android", "language" to resources.configuration.locale.toLanguageTag()))
                ?.addOnSuccessListener { tokenRegisteredForUid = uid }
        }
    }

    private fun renderPredictionDetail(id: String) {
        screenVersion++
        val requestScreen = screenVersion
        inboxListener?.remove()
        predictionListener?.remove()
        predictionListener = null
        currentPage = "detail"
        pendingPredictionId=id
        root = baseRoot()
        val header = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(14), dp(10), dp(14), dp(10)) }
        header.addView(button("‹  ${uiString(R.string.explore)}", false) { pendingPredictionId = null; renderApp("explore") }, lp())
        header.tag = "header"
        frontend.apply(header, "header")
        root.addView(header, lp())
        val scroller = ScrollView(this)
        content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(17), dp(18), dp(17), dp(25)) }
        content.addView(text(uiString(R.string.loading), 13f, muted), lp())
        scroller.addView(content)
        root.addView(scroller, lp(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        frontend.decorate(root, when (currentPage) { "detail" -> "details"; "home" -> "banners"; "saved" -> "history"; "stats" -> "statisticsCard"; else -> currentPage })
        showRoot()
        if (auth?.currentUser == null) return
        functions?.getHttpsCallable("getPredictionDetails")?.call(mapOf("predictionId" to id))
            ?.addOnSuccessListener { result ->
                if (requestScreen != screenVersion || isDestroyed) return@addOnSuccessListener
                content.removeAllViews()
                val response = result.data as? Map<*, *> ?: return@addOnSuccessListener
                val snapshot = response["snapshot"] as? Map<*, *> ?: return@addOnSuccessListener
                val p = Prediction.fromMap(id, snapshot) ?: return@addOnSuccessListener
                content.addView(text(p.competition, 12f, muted), lp())
                val logos=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL;gravity=Gravity.CENTER}
                for((url,name) in listOf(p.homeLogoUrl to p.homeTeam,p.awayLogoUrl to p.awayTeam)){if(url!=null){val image=android.widget.ImageView(this).apply{contentDescription=name;scaleType=android.widget.ImageView.ScaleType.FIT_CENTER};logos.addView(image,lp(dp(48),dp(48)).apply{marginEnd=dp(12)});remoteImages.load(url,image)}}
                if(logos.childCount>0)content.addView(logos,lp())
                content.addView(text("${p.homeTeam} × ${p.awayTeam}", 23f, ink, true), lp())
                if (p.country.isNotBlank()) content.addView(text(p.country, 12f, muted), lp())
                p.startsAt?.let { content.addView(text(SimpleDateFormat("EEE d MMM yyyy · HH:mm z", Locale.getDefault()).format(it), 12f, muted), lp()) }
                content.addView(text(p.marketName, 13f, muted), lp())
                content.addView(text(p.selection, 17f, ink, true), lp())
                content.addView(text("${p.odds?.let { uiFormat(R.string.odds_value, it) } ?: uiString(R.string.odds_missing)} · ${statusLabel(p.resultStatus)}", 12f, green), lp())
                val saved = response["saved"] == true
                if(saved) savedIds.add(p.id) else savedIds.remove(p.id)
                if (response["archived"] != true || saved) content.addView(button(uiString(if (saved) R.string.remove else R.string.save), !saved) { saveOrRemove(p.id, p.id in savedIds, it) }, lp())
                p.analysis?.let { content.addView(text(it, 13f, ink), lp()) }
                val language = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
                for (leg in p.legs) {
                    val selection = leg["selection"] as? Map<*, *>
                    val label = selection?.get(language) as? String ?: selection?.get("pt-BR") as? String ?: continue
                    content.addView(text("${uiString(R.string.leg_label)} · $label · ${statusLabel(ResultStatus.fromWire(leg["resultStatus"] as? String))}", 13f, ink), lp())
                }
                for (source in p.sources) content.addView(button(source, false) { openHttps(source) }, lp())
                val history = response["history"] as? List<*> ?: emptyList<Any>()
                for (item in history) {
                    val row = item as? Map<*, *> ?: continue
                    val date = (row["createdAtMillis"] as? Number)?.toLong()?.let { SimpleDateFormat("d MMM yyyy HH:mm", Locale.getDefault()).format(Date(it)) }.orEmpty()
                    content.addView(text("$date · ${statusLabel(ResultStatus.fromWire(row["previousStatus"] as? String))} → ${statusLabel(ResultStatus.fromWire(row["newStatus"] as? String))}", 11f, muted), lp())
                }
                (response["nextHistoryCursor"] as? String)?.let { cursor -> addHistoryMore(id,cursor,requestScreen) }
                content.addView(text(uiString(R.string.disclaimer), 11f, muted), lp())
                configuredContent=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
                content.addView(configuredContent,lp());addConfiguredBlocks("detail")
                frontend.decorate(content,"details")
            }?.addOnFailureListener { if (requestScreen == screenVersion && !isDestroyed) { showTaskError(it); renderApp("explore") } }
    }

    private fun openPendingTarget(){
        if(auth?.currentUser?.isEmailVerified!=true)return
        val url=pendingTargetUrl?:return;pendingTargetUrl=null
        if(frontend.approvedHttps(url))openHttps(url)else toast(uiString(R.string.not_available))
    }
    private fun openHttps(url: String) {
        val uri = Uri.parse(url)
        if (uri.scheme != "https" || uri.host.isNullOrBlank() || uri.userInfo != null) { toast(uiString(R.string.not_available)); return }
        try { startActivity(Intent(Intent.ACTION_VIEW, uri)) } catch (_: Exception) { toast(uiString(R.string.retry_later)) }
    }

    private fun renderInbox() {
        val uid = auth?.currentUser?.uid ?: return
        val requestScreen = screenVersion
        content.addView(text(uiString(R.string.notifications_title), 23f, ink, true), lp())
        showLoading()
        inboxListener = db?.collection("users")?.document(uid)?.collection("notification_inbox")
            ?.orderBy("createdAt", Query.Direction.DESCENDING)?.limit(inboxLimit.toLong())?.addSnapshotListener { snapshot, error ->
                if (requestScreen != screenVersion || isDestroyed) return@addSnapshotListener
                if (error != null) { showError(error); return@addSnapshotListener }
                content.removeAllViews()
                content.addView(text(uiString(R.string.notifications_title), 23f, ink, true), lp())
                if (snapshot == null || snapshot.isEmpty) content.addView(text(uiString(R.string.no_notifications), 13f, muted), lp())
                snapshot?.documents?.forEach { doc ->
                    val card = LinearLayout(this).apply {
                        orientation = LinearLayout.VERTICAL
                        setPadding(dp(14), dp(14), dp(14), dp(14))
                        background = rounded(surface, 12f)
                    }
                    card.addView(text(doc.getString("title").orEmpty(), 16f, ink, true), lp())
                    card.addView(text(doc.getString("body").orEmpty(), 13f, muted), lp())
                    val read = doc.getTimestamp("readAt") != null
                    card.addView(button(if (read) uiString(R.string.read_label) else uiString(R.string.mark_read), false) { clicked ->
                        clicked.isEnabled = false
                        functions?.getHttpsCallable("markNotificationRead")?.call(mapOf("notificationId" to doc.id))
                            ?.addOnFailureListener { clicked.isEnabled = true; showTaskError(it) }
                    }.apply { isEnabled = !read }, lp())
                    doc.getString("url")?.takeIf(frontend::approvedHttps)?.let { url ->
                        card.addView(button(url, false) { openHttps(url) }, lp())
                    }
                    doc.getString("imageUrl")?.let { url ->
                        val image = android.widget.ImageView(this).apply { adjustViewBounds = true; minimumHeight = dp(80); contentDescription = doc.getString("title") }
                        remoteImages.load(url, image); card.addView(image, lp())
                    }
                    doc.getString("predictionId")?.let { predictionId ->
                        card.addView(button(uiString(R.string.open_prediction), false) { renderPredictionDetail(predictionId) }, lp())
                    }
                    content.addView(card, lp().apply { topMargin = dp(12) })
                }
                if ((snapshot?.size() ?: 0) >= inboxLimit) content.addView(button(uiString(R.string.load_more), false) { inboxLimit += 50; renderApp("notifications") }, lp())
                content.addView(button(uiString(R.string.back_label), false) { renderApp("settings") }, lp().apply { topMargin = dp(12) })
            }
    }

    private fun callAccountFunction(name: String) {
        if(name=="requestAccountExport") {
            if(exportWriter!=null)return
            val uid=auth?.currentUser?.uid?:return
            exportFile=java.io.File(cacheDir,"score-master-export.json")
            exportWriter=exportFile!!.bufferedWriter()
            exportWriter!!.write("{\"pages\":[")
            exportPage(emptyMap(),true,uid)
            return
        }
        functions?.getHttpsCallable(name)?.call(emptyMap<String,Any>())?.addOnSuccessListener {
            clearAccountSession();toast(uiString(R.string.account_deleted));render()
        }?.addOnFailureListener{showTaskError(it)}
    }
    private fun exportPage(payload:Map<String,Any>,first:Boolean,uid:String){
        functions?.getHttpsCallable("requestAccountExport")?.call(payload)?.addOnSuccessListener { result ->
            if(auth?.currentUser?.uid!=uid||isDestroyed){exportWriter?.close();exportWriter=null;exportFile?.delete();return@addOnSuccessListener}
            val page=result.data as? Map<*,*>?:return@addOnSuccessListener
            runCatching {if(!first)exportWriter?.write(",");exportWriter?.write(org.json.JSONObject(page).toString());exportWriter?.flush()}
                .onFailure{exportWriter?.close();exportWriter=null;showTaskError(Exception(it));return@addOnSuccessListener}
            val next=page["next"] as? Map<*,*>
            if(next!=null){exportPage(next.entries.associate{it.key.toString() to it.value!!},false,uid)}
            else{exportWriter?.write("]}");exportWriter?.close();exportWriter=null
                startActivityForResult(Intent(Intent.ACTION_CREATE_DOCUMENT).apply{type="application/json";addCategory(Intent.CATEGORY_OPENABLE);putExtra(Intent.EXTRA_TITLE,"Score-Master-dados.json")},701)}
        }?.addOnFailureListener{exportWriter?.close();exportWriter=null;exportFile?.delete();showTaskError(it)}
    }
    @Deprecated("Platform activity result API supports the minimum Android version")
    override fun onActivityResult(requestCode:Int,resultCode:Int,data:Intent?){
        super.onActivityResult(requestCode,resultCode,data)
        if(requestCode==701){
            if(resultCode==RESULT_OK){val target=data?.data;val source=exportFile;if(target!=null&&source!=null)runCatching{contentResolver.openOutputStream(target)?.use{output->source.inputStream().use{it.copyTo(output)}}?:error("No output stream")}.onSuccess{toast(uiString(R.string.export_saved))}.onFailure{showTaskError(Exception(it))}}
            exportFile?.delete();exportFile=null
        }
    }
    private fun addHistoryMore(id:String,cursor:String,version:Int) {
        content.addView(button(uiString(R.string.load_more),false) { clicked ->
            clicked.isEnabled=false
            functions?.getHttpsCallable("getPredictionDetails")?.call(mapOf("predictionId" to id,"historyCursor" to cursor))?.addOnSuccessListener { result ->
                if(version!=screenVersion||isDestroyed)return@addOnSuccessListener
                content.removeView(clicked)
                val response=result.data as? Map<*,*>?:return@addOnSuccessListener
                for(item in response["history"] as? List<*> ?: emptyList<Any>()) {
                    val row=item as? Map<*,*>?:continue
                    val date=(row["createdAtMillis"] as? Number)?.toLong()?.let { SimpleDateFormat("d MMM yyyy HH:mm",Locale.getDefault()).format(Date(it)) }.orEmpty()
                    content.addView(text("$date · ${statusLabel(ResultStatus.fromWire(row["previousStatus"] as? String))} → ${statusLabel(ResultStatus.fromWire(row["newStatus"] as? String))}",11f,muted),lp())
                }
                (response["nextHistoryCursor"] as? String)?.let { addHistoryMore(id,it,version) }
                frontend.decorate(content,"details")
            }?.addOnFailureListener { if(version==screenVersion&&!isDestroyed){clicked.isEnabled=true;showTaskError(it)} }
        },lp())
    }

    private fun logoutAccount() {
        FirebaseMessaging.getInstance().token.addOnCompleteListener { task ->
            if(task.isSuccessful) functions?.getHttpsCallable("unregisterDeviceToken")?.call(mapOf("token" to task.result))?.addOnCompleteListener { clearAccountSession(); render() }
                ?: run { clearAccountSession(); render() }
            else { clearAccountSession(); render() }
        }
    }

    private fun clearAccountSession(){
        profileListener?.remove();savedListener?.remove();inboxListener?.remove();predictionListener?.remove()
        exportWriter?.close();exportWriter=null;exportFile?.delete();exportFile=null
        feedSavedIds.clear();savedIds.clear();savedItems=emptyList();predictions=emptyList()
        profileRegisteredForUid=null;tokenRegisteredForUid=null
        getSystemService(NotificationManager::class.java)?.cancelAll()
        auth?.currentUser?.uid?.let{getSharedPreferences("feed_cache_$it",MODE_PRIVATE).edit().clear().apply()}
        auth?.signOut()
    }

    private fun confirmDeleteAccount() {
        android.app.AlertDialog.Builder(this)
            .setTitle(uiString(R.string.delete_title))
            .setMessage(uiString(R.string.delete_message))
            .setNegativeButton(uiString(R.string.cancel_label), null)
            .setPositiveButton(uiString(R.string.continue_label)) { _, _ -> reauthenticateForDeletion() }
            .show().also { dialog -> dialog.window?.decorView?.let { frontend.decorate(it, "dialogs") } }
    }

    private fun reauthenticateForDeletion() {
        val user = auth?.currentUser ?: return
        val email = user.email ?: return
        val password = edit(uiString(R.string.password), true)
        android.app.AlertDialog.Builder(this)
            .setTitle(uiString(R.string.confirm_password))
            .setView(password)
            .setNegativeButton(uiString(R.string.cancel_label), null)
            .setPositiveButton(uiString(R.string.delete_account)) { _, _ ->
                user.reauthenticate(EmailAuthProvider.getCredential(email, password.text.toString()))
                    .addOnSuccessListener {
                        user.getIdToken(true).addOnSuccessListener { callAccountFunction("deleteMyAccount") }
                            .addOnFailureListener { showTaskError(it) }
                    }.addOnFailureListener { showTaskError(it) }
            }.show().also { dialog -> dialog.window?.decorView?.let { frontend.decorate(it, "dialogs") } }
    }

    private fun openTelegram() {
        val telegram = Uri.parse("tg://resolve?domain=haardydev")
        try { startActivity(Intent(Intent.ACTION_VIEW, telegram)) }
        catch (_: Exception) {
            try { startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/haardydev"))) }
            catch (_: Exception) { toast(uiString(R.string.retry_later)) }
        }
    }

    private fun statusLabel(status: ResultStatus): String = when (status) {
        ResultStatus.PENDING -> uiString(R.string.pending)
        ResultStatus.WON -> uiString(R.string.won)
        ResultStatus.LOST -> uiString(R.string.lost)
        ResultStatus.VOIDED -> uiString(R.string.voided)
        ResultStatus.POSTPONED -> uiString(R.string.postponed)
        ResultStatus.CANCELLED -> uiString(R.string.cancelled)
    }

    private fun showLoading() {
        content.addView(text(uiString(R.string.loading), 12f, muted).apply { setPadding(0, dp(12), 0, 0) }, lp())
    }

    private fun showError(error: Exception) {
        content.removeAllViews()
        content.addView(text(uiString(R.string.retry_later), 13f, Color.rgb(240, 140, 140)), lp())
        content.addView(button(uiString(R.string.retry), false) { renderApp(currentPage) }, lp().apply { topMargin = dp(8) })
    }

    private fun showTaskError(error: Exception) {
        val message = when {
            !firebaseConfigured -> uiString(R.string.backend_missing)
            error is com.google.firebase.auth.FirebaseAuthInvalidCredentialsException -> uiString(R.string.authentication_error)
            error is com.google.firebase.functions.FirebaseFunctionsException && error.code == com.google.firebase.functions.FirebaseFunctionsException.Code.PERMISSION_DENIED -> uiString(R.string.no_permission)
            else -> uiString(R.string.retry_later)
        }
        toast(message)
    }

    private fun sectionTitle(value: String) {
        content.addView(text(value, 15f, ink, true).apply { tag = "sectionTitle"; setPadding(0, 0, 0, dp(10)) }, lp())
    }

    private fun addMetric(label: String, value: String) {
        val card = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL; setPadding(dp(13), dp(13), dp(13), dp(13)); background = rounded(surface, 12f) }
        card.addView(text(label, 12f, muted), lp(0, -2, 1f))
        card.addView(text(value, 15f, ink, true), lp())
        card.tag = "statisticsCard"
        frontend.apply(card, "statisticsCard")
        content.addView(card, lp().apply { bottomMargin = dp(8) })
    }

    private fun baseRoot() = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setBackgroundColor(bg)
    }

    private fun showRoot() {
        val initial = intArrayOf(root.paddingLeft, root.paddingTop, root.paddingRight, root.paddingBottom)
        androidx.core.view.WindowCompat.setDecorFitsSystemWindows(window, false)
        androidx.core.view.ViewCompat.setOnApplyWindowInsetsListener(root) { view, insets ->
            val bars = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.systemBars() or androidx.core.view.WindowInsetsCompat.Type.displayCutout())
            val keyboard = insets.getInsets(androidx.core.view.WindowInsetsCompat.Type.ime())
            view.setPadding(initial[0] + bars.left, initial[1] + bars.top, initial[2] + bars.right, initial[3] + maxOf(bars.bottom, keyboard.bottom))
            insets
        }
        setContentView(root)
        androidx.core.view.ViewCompat.requestApplyInsets(root)
    }

    private fun text(value: String, size: Float, color: Int, bold: Boolean = false) = TextView(this).apply {
        text = value; textSize = size; setTextColor(color); if (bold) setTypeface(typeface, Typeface.BOLD)
        includeFontPadding = true
        frontend.apply(this, "text")
    }

    private fun edit(hintText: String, secret: Boolean): EditText = EditText(this).apply {
        hint = hintText; textSize = 14f; setTextColor(ink); setHintTextColor(muted)
        setPadding(dp(13), dp(10), dp(13), dp(10))
        background = rounded(surface, 11f)
        if (secret) inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_PASSWORD
        else inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
        frontend.apply(this, "field")
    }

    private fun button(label: String, primary: Boolean = false, action: (Button) -> Unit): Button = Button(this).apply {
        text = label; textSize = 13f; isAllCaps = false
        setTextColor(if (primary) Color.rgb(4, 34, 24) else ink)
        background = rounded(if (primary) green else line, 10f)
        setOnClickListener { action(this) }
        frontend.apply(this, "button")
    }

    private fun rounded(color: Int, radius: Float): GradientDrawable = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius.toInt()).toFloat()
        if (color == surface) setStroke(dp(1), line)
    }

    private fun lp(width: Int = ViewGroup.LayoutParams.MATCH_PARENT, height: Int = ViewGroup.LayoutParams.WRAP_CONTENT, weight: Float = 0f) =
        LinearLayout.LayoutParams(width, height, weight)

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()

    private fun createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel("score_updates", uiString(R.string.notification_channel), NotificationManager.IMPORTANCE_DEFAULT)
                .apply { description = uiString(R.string.notification_channel_description) }
            getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
        }
    }

    private fun requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), 901)
        }
    }
}
