package com.scoremaster.app

import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import org.json.JSONObject
import java.util.Locale

/** Declarative configuration; never executes remote HTML, scripts or class names. */
internal class FrontendConfiguration(private val context: Context) {
    private val preferences = context.getSharedPreferences("frontend_config", Context.MODE_PRIVATE)
    var value: JSONObject? = null
        private set
    init { preferences.getString("last_valid", null)?.let { runCatching { accept(JSONObject(it), false) } } }

    fun accept(candidate: JSONObject, persist: Boolean = true): Boolean {
        if (candidate.optInt("schemaVersion") != 1 || candidate.toString().length > 180000) return false
        for (key in listOf("theme", "components", "texts", "pages")) if (candidate.optJSONObject(key) == null) return false
        val theme = candidate.getJSONObject("theme")
        if(candidate.has("lightTheme") && candidate.optJSONObject("lightTheme")==null)return false
        candidate.optJSONObject("lightTheme")?.let { light ->
            for (key in light.keys()) if (key !in listOf("background","surface","line","ink","muted","accent") || !colorValid(light.optString(key))) return false
            if (light.has("background") && light.has("ink") && contrast(light.getString("background"), light.getString("ink")) < 4.5) return false
        }
        if (candidate.has("themeSelectionEnabled") && candidate.opt("themeSelectionEnabled") !is Boolean) return false
        if (candidate.has("documents")) {
            val documents = candidate.optJSONObject("documents") ?: return false
            for (key in documents.keys()) {
                val document = documents.optJSONObject(key) ?: return false
                if (key !in listOf("privacy","terms","about","contact") || !translationsValid(document.optJSONObject("title"),200) || !translationsValid(document.optJSONObject("body"),20000)) return false
            }
        }
        if (candidate.has("faq")) {
            val faq = candidate.optJSONArray("faq") ?: return false
            if (faq.length() > 50) return false
            val ids = mutableSetOf<String>()
            for (index in 0 until faq.length()) {
                val entry = faq.optJSONObject(index) ?: return false
                if (!Regex("[a-zA-Z0-9_-]{1,80}").matches(entry.optString("id")) || !ids.add(entry.optString("id")) || !translationsValid(entry.optJSONObject("question"),500) || !translationsValid(entry.optJSONObject("answer"),5000)) return false
            }
        }
        for (key in theme.keys()) {
            if (key !in listOf("background", "surface", "line", "ink", "muted", "accent") || !colorValid(theme.optString(key))) return false
        }
        val components = candidate.getJSONObject("components")
        for (key in components.keys()) {
            val style = components.optJSONObject(key)
            if (key !in componentNames || !styleValid(style)) return false
            if (style!!.has("background") && style.has("color") && contrast(style.getString("background"), style.getString("color")) < 4.5) return false
        }
        if (theme.has("background") && theme.has("ink") && contrast(theme.getString("background"), theme.getString("ink")) < 4.5) return false
        val texts = candidate.getJSONObject("texts")
        if (texts.length() > 300) return false
        for (key in texts.keys()) if (!Regex("[a-z][a-z0-9_]{0,79}").matches(key) || key in protectedTextKeys || !translationsValid(texts.optJSONObject(key))) return false
        val pages = candidate.getJSONObject("pages")
        for (page in pages.keys()) {
            if (page !in pageNames) return false
            val blocks = pages.optJSONArray(page) ?: return false
            if (blocks.length() > 30) return false
            val ids = mutableSetOf<String>()
            for (i in 0 until blocks.length()) {
                val block = blocks.optJSONObject(i) ?: return false
                if (!Regex("[a-zA-Z0-9_-]{1,80}").matches(block.optString("id")) || !ids.add(block.optString("id")) || block.opt("visible") !is Boolean || block.optString("type") !in listOf("text", "button", "divider", "image") || !styleValid(block.optJSONObject("style"))) return false
                if (block.optString("type") !in listOf("divider", "image") && !translationsValid(block.optJSONObject("text"))) return false
                if (block.optString("type") == "image" && (!imageUrlValid(block.optString("imageUrl")) || !translationsValid(block.optJSONObject("accessibility")))) return false
                if (block.optString("type") == "button" && block.optString("action") !in allowedActions) return false
            }
        }
        val images = candidate.optJSONObject("images")
        if (candidate.has("images") && images == null || (images?.length() ?: 0) > 50) return false
        if (images != null) for (key in images.keys()) {
            val image = images.optJSONObject(key) ?: return false
            if (!imageUrlValid(image.optString("url")) || !translationsValid(image.optJSONObject("alt"))) return false
        }
        if (candidate.has("allowedHttpsHosts")) {
            val hosts = candidate.optJSONArray("allowedHttpsHosts") ?: return false
            if (hosts.length() > 30 || (0 until hosts.length()).any { hosts.opt(it) !is String || !Regex("(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\\.)+[a-z]{2,63}").matches(hosts.optString(it)) }) return false
        }
        if (candidate.has("sections")) {
            val sections = candidate.optJSONObject("sections") ?: return false
            for (page in sections.keys()) {
                if (page !in pageNames) return false
                val entries = sections.optJSONArray(page) ?: return false
                if (entries.length() > sectionNames.size) return false
                val ids = mutableSetOf<String>()
                for (index in 0 until entries.length()) {
                    val entry = entries.optJSONObject(index) ?: return false
                    val id = entry.optString("id")
                    if (id !in sectionNames || !ids.add(id) || entry.opt("visible") !is Boolean || (id == "predictionList" && !entry.getBoolean("visible"))) return false
                }
            }
        }
        value = candidate
        if (persist) preferences.edit().putString("last_valid", candidate.toString()).apply()
        return true
    }
    fun color(key: String, fallback: Int): Int = value?.optJSONObject("theme")?.optString(key)?.takeIf(::colorValid)?.let(Color::parseColor) ?: fallback
    fun lightColor(key: String, fallback: Int): Int = value?.optJSONObject("lightTheme")?.optString(key)?.takeIf(::colorValid)?.let(Color::parseColor) ?: fallback
    fun localized(text: JSONObject?): String? {
        val language = if (Locale.getDefault().language == "pt") "pt-BR" else Locale.getDefault().language
        return text?.optString(language)?.takeIf { it.isNotBlank() } ?: text?.optString("pt-BR")?.takeIf { it.isNotBlank() }
    }
    fun text(key: String): String? = localized(value?.optJSONObject("texts")?.optJSONObject(key))
    fun apply(view: View, role: String, explicit: JSONObject? = null) {
        val style = explicit ?: value?.optJSONObject("components")?.optJSONObject(role) ?: return
        val density = context.resources.displayMetrics.density
        fun dp(key: String) = (style.optDouble(key, 0.0) * density).toInt()
        if (style.has("padding")) view.setPadding(dp("padding"), dp("padding"), dp("padding"), dp("padding"))
        if (style.has("margin")) (view.layoutParams as? ViewGroup.MarginLayoutParams)?.setMargins(dp("margin"), dp("margin"), dp("margin"), dp("margin"))
        if(style.has("elevation"))view.elevation=dp("elevation").toFloat()
        if (style.has("background") || style.has("radius") || style.has("borderColor")) view.background = ((view.background?.mutate() as? GradientDrawable) ?: GradientDrawable()).apply {
            if (style.has("background")) setColor(Color.parseColor(style.getString("background")))
            if (style.has("radius")) cornerRadius = dp("radius").toFloat()
            if (style.has("borderColor")) setStroke(dp("borderWidth"), Color.parseColor(style.getString("borderColor")))
        }
        if (view is TextView) {
            if (style.has("color")) view.setTextColor(Color.parseColor(style.getString("color")))
            if (style.has("textSize")) view.textSize = style.getDouble("textSize").toFloat()
            if(style.has("lineSpacing"))view.setLineSpacing(dp("lineSpacing").toFloat(),1f)
            if (style.has("font") || style.has("bold")) view.typeface = Typeface.create(style.optString("font", "sans-serif"), if (style.optBoolean("bold")) Typeface.BOLD else Typeface.NORMAL)
            if (style.has("alignment")) view.gravity = when (style.getString("alignment")) { "center" -> Gravity.CENTER; "end" -> Gravity.END; else -> Gravity.START }
        }
    }
    fun arrange(container: ViewGroup, page: String) {
        val entries = value?.optJSONObject("sections")?.optJSONArray(page) ?: return
        val selected = (0 until entries.length()).mapNotNull { entries.optJSONObject(it) }
        val byId = (0 until container.childCount).map { container.getChildAt(it) }.associateBy { it.tag as? String }
        for (entry in selected) {
            val id = entry.optString("id")
            if (id !in setOf("welcomeTitle", "welcomeBody", "sectionTitle", "search", "marketFilters", "filterButton", "filtersExplanation", "predictionList")) continue
            val view = byId[id] ?: continue
            view.visibility = if (id == "predictionList" || entry.optBoolean("visible", true)) View.VISIBLE else View.GONE
            container.removeView(view); container.addView(view)
        }
    }
    fun decorate(view: View, pageRole: String) {
        apply(view, view.tag as? String ?: when (view) { is android.widget.EditText -> "field"; is android.widget.Button -> "button"; is TextView -> "text"; else -> pageRole })
        if (view is ViewGroup) for (i in 0 until view.childCount) decorate(view.getChildAt(i), pageRole)
    }
    fun approvedHttps(url: String): Boolean = runCatching {
        val uri = android.net.Uri.parse(url)
        val hosts = value?.optJSONArray("allowedHttpsHosts")
        val allowed = if (hosts == null) setOf("t.me") else (0 until hosts.length()).map { hosts.getString(it) }.toSet()
        uri.scheme == "https" && uri.userInfo == null && uri.host in allowed
    }.getOrDefault(false)
    fun image(key: String): JSONObject? = value?.optJSONObject("images")?.optJSONObject(key)
    private fun imageUrlValid(value: String): Boolean = runCatching {
        val uri = android.net.Uri.parse(value)
        uri.scheme == "https" && uri.userInfo == null && uri.host in listOf("firebasestorage.googleapis.com", "storage.googleapis.com")
    }.getOrDefault(false)
    private fun translationsValid(text: JSONObject?, max: Int = 2000): Boolean = text != null && listOf("pt-BR", "en", "es").all { text.optString(it).isNotBlank() && text.optString(it).length <= max }
    private fun colorValid(value: String) = Regex("#[0-9a-fA-F]{6}").matches(value)
    private fun contrast(background: String, foreground: String): Double {
        fun luminance(color: String): Double {
            val rgb = listOf(1, 3, 5).map { color.substring(it, it + 2).toInt(16) / 255.0 }.map { if (it <= 0.04045) it / 12.92 else Math.pow((it + 0.055) / 1.055, 2.4) }
            return rgb[0] * 0.2126 + rgb[1] * 0.7152 + rgb[2] * 0.0722
        }
        val a = luminance(background); val b = luminance(foreground)
        return (maxOf(a, b) + 0.05) / (minOf(a, b) + 0.05)
    }
    private fun styleValid(style: JSONObject?): Boolean {
        style ?: return false
        for (key in style.keys()) when (key) {
            "background", "color", "borderColor" -> if (!colorValid(style.optString(key))) return false
            "textSize" -> if (style.optDouble(key, Double.NaN) !in 10.0..40.0) return false
            "padding", "margin", "radius" -> if (style.optDouble(key, Double.NaN) !in 0.0..48.0) return false
            "borderWidth" -> if (style.optDouble(key, Double.NaN) !in 0.0..4.0) return false
            "elevation" -> if(style.optDouble(key,Double.NaN) !in 0.0..12.0)return false
            "lineSpacing" -> if(style.optDouble(key,Double.NaN) !in 0.0..16.0)return false
            "font" -> if (style.optString(key) !in listOf("sans-serif", "serif", "monospace", "sans-serif-condensed")) return false
            "alignment" -> if (style.optString(key) !in listOf("start", "center", "end")) return false
            "bold" -> if (style.opt(key) !is Boolean) return false
            else -> return false
        }
        return true
    }
    companion object {
        private val componentNames = setOf("header", "navigation", "footer", "predictionCard", "statisticsCard", "filters", "tabs", "menus", "login", "register", "details", "history", "settings", "support", "dialogs", "bottomSheets", "banners", "notifications", "text", "button", "field")
        private val pageNames = setOf("home", "explore", "saved", "stats", "settings", "notifications", "login", "register", "detail")
        private val sectionNames = setOf("welcomeTitle", "welcomeBody", "sectionTitle", "search", "marketFilters", "filterButton", "filtersExplanation", "predictionList")
        private val protectedTextKeys = setOf("disclaimer", "email_verification", "backend_missing", "auth_required", "pending", "won", "lost", "voided", "postponed", "cancelled")
        val allowedActions = listOf("navigate:home", "navigate:explore", "navigate:saved", "navigate:stats", "navigate:settings", "navigate:notifications", "support:telegram")
    }
}
