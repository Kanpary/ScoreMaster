import groovy.json.JsonSlurper
import java.util.Properties

plugins {
    id("com.android.application")
}

if (file("google-services.json").exists()) {
    apply(plugin = "com.google.gms.google-services")
}

val localSigning = Properties().apply {
    val source = rootProject.file("signing.properties")
    if (source.isFile) source.inputStream().use { load(it) }
}
fun signingValue(environment: String, property: String) = System.getenv(environment)?.takeIf { it.isNotBlank() }
    ?: localSigning.getProperty(property)?.takeIf { it.isNotBlank() }
val releaseStorePath = signingValue("CM_KEYSTORE_PATH", "storeFile")
val releaseStorePassword = signingValue("CM_KEYSTORE_PASSWORD", "storePassword")
val releaseKeyAlias = signingValue("CM_KEY_ALIAS", "keyAlias")
val releaseKeyPassword = signingValue("CM_KEY_PASSWORD", "keyPassword")

android {
    namespace = "com.scoremaster.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.scoremaster.app"
        minSdk = 23
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
        vectorDrawables.useSupportLibrary = true
    }

    signingConfigs {
        create("production") {
            if (!releaseStorePath.isNullOrBlank()) storeFile = rootProject.file(releaseStorePath)
            storePassword = releaseStorePassword
            keyAlias = releaseKeyAlias
            keyPassword = releaseKeyPassword
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("production")
            isDebuggable = false
            isShrinkResources = true
            isMinifyEnabled = true
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(project(":domain"))
    implementation(platform("com.google.firebase:firebase-bom:35.0.0"))
    implementation("com.google.firebase:firebase-firestore")
    implementation("androidx.core:core-ktx:1.17.0")

    testImplementation("junit:junit:4.13.2")
    androidTestImplementation("androidx.test:runner:1.7.0")
    androidTestImplementation("androidx.test:core:1.7.0")
    androidTestImplementation("androidx.test.ext:junit:1.3.0")
    androidTestImplementation("androidx.test.espresso:espresso-core:3.7.0")
}

val validateReleaseConfiguration = tasks.register("validateReleaseConfiguration") {
    group = "verification"
    description = "Bloqueia release sem Firebase real e chave de assinatura própria."
    doLast {
        val configFile = file("google-services.json")
        check(configFile.isFile) { "Release exige app/google-services.json do Firebase real." }
        val config = JsonSlurper().parse(configFile) as Map<*, *>
        val clients = config["client"] as? List<*> ?: emptyList<Any>()
        check(clients.any { client ->
            val info = (client as? Map<*, *>)?.get("client_info") as? Map<*, *>
            val androidInfo = info?.get("android_client_info") as? Map<*, *>
            androidInfo?.get("package_name") == "com.scoremaster.app"
        }) { "O google-services.json deve registrar com.scoremaster.app." }
        check(!releaseStorePath.isNullOrBlank() && rootProject.file(releaseStorePath).isFile &&
            !releaseStorePassword.isNullOrBlank() && !releaseKeyAlias.isNullOrBlank() &&
            !releaseKeyPassword.isNullOrBlank()) {
            "Configure a identidade Android no CI ou signing.properties com sua chave permanente para release."
        }
    }
}
tasks.matching { it.name == "preReleaseBuild" }.configureEach {
    dependsOn(validateReleaseConfiguration)
}
