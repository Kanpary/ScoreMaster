# Score Master pelo celular: configuração e APK assinado

Este roteiro usa o navegador do Android e telas de serviços em nuvem. Não requer instalar Android Studio, executar comandos no celular nem publicar credenciais no repositório. Os serviços e contas são do responsável pelo aplicativo; cobranças de Firebase/Google Cloud dependem do uso e do plano escolhido.

## 1. Enviar o projeto sem carregar dezenas de pastas

Use o arquivo Score-Master-upload-celular.zip entregue junto. Extraia-o no Android; dentro há exatamente abScore-Master.zip e codemagic.yaml.

1. No navegador, crie um repositório privado no GitHub.
2. Na página do repositório, escolha Add file → Upload files e selecione os dois arquivos extraídos. Deixe ambos na raiz; faça um único commit.
3. Crie/acesse sua conta Codemagic pelo navegador, conecte o GitHub e selecione esse repositório.
4. Confirme que o serviço identificou codemagic.yaml. O workflow extrai o ZIP automaticamente no runner antes de compilar ou implantar. Não extraia o projeto dentro do repositório nem mude os nomes dos dois arquivos.

O repositório guarda apenas código público do app, sem JSON Firebase, senha, keystore ou credencial de serviço. Mantenha-o privado mesmo assim.

## 2. Criar e preparar Firebase real

No Firebase Console, crie ou selecione o projeto real. Escolha com cuidado o local do Firestore: a localização não pode ser trocada depois. Ative Email/Senha em Authentication e crie o banco Firestore. Inicialize também Storage. Functions, Storage e Scheduler podem exigir o plano de faturamento Blaze e habilitação das APIs no projeto; verifique preços e limites antes de ativar.

Em Configurações do projeto, adicione um app Android com pacote exatamente com.scoremaster.app e baixe o google-services.json. No Codemagic, em variável/grupo protegido score_master_firebase, cadastre:

- FIREBASE_PROJECT_ID: o ID mostrado no Firebase Console.
- GOOGLE_SERVICES_JSON: conteúdo integral do arquivo JSON baixado. Use variável protegida; nunca faça commit.
- FIREBASE_DEPLOY_SERVICE_ACCOUNT_JSON: conteúdo integral de uma chave JSON de conta de serviço autorizada a implantar os recursos requeridos. Gere e guarde essa chave com muito cuidado; nunca a cole no chat, GitHub ou app Android.

Execute primeiro Score Master - Implantar Firebase real sem definir SCORE_ADMIN_EMAIL. O workflow confere se Android e projeto têm o mesmo ID, testa o backend e implanta regras, índices, Storage, Functions e Hosting. Essa ação altera seu projeto real. Se houver Functions anteriores, leia o diff/aviso da Console antes de aceitar remoção de função substituída.

## 3. Abrir painel e criar administrador

No mesmo projeto Firebase, adicione um app Web em Configurações do projeto. Copie a configuração Web pública (apiKey, authDomain, projectId e appId); ela identifica o app, mas não substitui a chave privada de serviço. Abra o domínio Hosting publicado, insira essa configuração na tela de conexão e entre com uma conta do próprio app.

Para iniciar, instale o APK assinado na etapa 5 como responsável, registre sua conta com seu e-mail real e confirme a mensagem enviada. Depois, adicione a variável protegida SCORE_ADMIN_EMAIL com esse mesmo e-mail verificado e rode novamente Score Master - Implantar Firebase real. O script só promove conta que já existe, está ativa e verificada; revoga sessões atuais por segurança, então entre novamente. Não armazene senha no projeto.

No painel, inicialize as categorias reais, cadastre conteúdo institucional verdadeiro e confira os destinos antes de publicar. Usuários, palpites, estatísticas, resultados e campanhas só aparecem após os dados reais serem cadastrados.

## 4. Criar a chave permanente sem computador

Não gere uma chave nova a cada compilação. Ela identifica todas as atualizações futuras do app. Em Codemagic, crie o grupo protegido score_master_signing_bootstrap com a variável Secret SCORE_MASTER_RELEASE_PASSWORD: gere uma senha aleatória longa (mínimo 16 caracteres) e guarde-a em um gerenciador privado.

Rode uma vez Score Master - Criar chave de release uma vez. Baixe o artefato score-master-release.p12 para uma pasta privada do Android. Na área Code signing identities do Codemagic, envie esse arquivo como keystore, use exatamente a mesma senha e o alias scoremaster_release, com referência score_master_release. Confirme salvamento. Mantenha uma cópia de segurança privada do .p12 e da senha, sem compartilhá-los. Apague o artefato temporário do workflow depois de importá-lo.

Se já possui uma chave de release deste mesmo aplicativo, não crie outra: importe a chave existente com a referência usada no workflow, ou atualize a referência do YAML para coincidir com ela. Uma chave diferente pode impedir atualização do aplicativo instalado.

## 5. Gerar o APK de distribuição

Confira se score_master_firebase ainda contém Firebase real e se score_master_release aparece na identidade de assinatura. Rode Score Master - Release assinado. Ele executa testes e lint, compila APK/AAB, confirma a assinatura e calcula SHA-256. Se falhar, abra o log e corrija o primeiro erro exibido; não distribua artifact de uma execução vermelha.

Baixe app-release.apk nos artefatos da execução verde, junto com app-release.apk.sha256. Instale no seu Android e confira login, cadastro, resultados, salvos e notificações com contas de QA antes de distribuir a outros usuários. O APK é real e assinado quando esse workflow passa; isso não significa que serviços pagos estão configurados, que dados editoriais existem ou que o sistema foi aprovado na Play Store.

## Se o build parar

- Arquivo Firebase ausente ou outro projeto: confira FIREBASE_PROJECT_ID, google-services.json e pacote com.scoremaster.app.
- Release sem assinatura: confira keystore importado, referência score_master_release, alias e senhas; use a mesma chave para sempre.
- Permissão de implantação: confirme que a conta de serviço foi autorizada para Firebase/Google Cloud e que billing/APIs dos produtos necessários estão habilitados.
- Projeto sem dados: publique categorias, termos/privacidade e palpites reais no painel. O app não inventa dados.
- E2E no aparelho: use uma conta e projeto de QA separados, um palpite já publicado e o runner privado conforme scripts/run-device-e2e.sh e E2E-ACCEPTANCE.md. A compilação de release não substitui esse teste.

Referências oficiais: https://firebase.google.com/docs/android/setup ; https://firebase.google.com/docs/cli ; https://docs.codemagic.io/yaml-code-signing/signing-android/
