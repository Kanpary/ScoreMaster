# Score Master grátis: atualizar o repositório e gerar APK

Este roteiro mantém o Firebase no plano Spark. Não habilite Blaze, não configure Firebase Storage e não crie Cloud Functions. O app fica público; somente você entra no painel administrativo. Os favoritos e preferências ficam salvos no próprio Android.

## 1. Atualize os dois arquivos do GitHub pelo navegador do Android

1. Baixe e extraia o novo `Score-Master-upload-celular.zip`.
2. Abra o repositório privado `Kanpary/ScoreMaster` no GitHub e remova os arquivos antigos `abScore-Master.zip` e `codemagic.yaml`.
3. Envie os dois arquivos novos para a raiz do repositório e confirme o commit.
4. No Codemagic, abra o app ScoreMaster e confirme que a branch `main` e o `codemagic.yaml` foram reconhecidos.

O repositório contém código, não inclua nele `google-services.json`, arquivos `.p12`, senhas ou chaves de conta de serviço.

## 2. Confira o Firebase no plano gratuito

No Firebase Console, mantenha o plano **Spark**. Use o projeto e o app Android existentes (`com.scoremaster.app`) e o Firestore que você já criou. Não abra Storage nem faça upgrade. Em Authentication, deixe Email/Senha habilitado para sua conta administrativa. O app público não oferece cadastro ou login para visitantes.

Em Configurações do projeto, registre também um aplicativo Web. A configuração Web é pública e será usada apenas para conectar o painel ao Firebase. Não cole no painel credenciais privadas.

## 3. Configure Codemagic

No grupo protegido `score_master_firebase`, confira estas variáveis:

- `FIREBASE_PROJECT_ID`: ID do projeto Firebase.
- `GOOGLE_SERVICES_JSON`: conteúdo completo do arquivo Android `google-services.json`.
- `FIREBASE_DEPLOY_SERVICE_ACCOUNT_JSON`: JSON de uma conta de serviço com permissão para publicar regras/índices do Firestore e Hosting no mesmo projeto.
- `SCORE_ADMIN_EMAIL`: seu e-mail administrativo, usado para conceder a permissão de painel à conta já criada e verificada.

Mantenha a identidade Android `score_master_release` e o arquivo `.p12` que você já importou. Não gere outra chave: ela é necessária para atualizar o mesmo aplicativo.

## 4. Publique regras e painel

No Codemagic, execute **Score Master - Implantar Firebase real**. Ele valida que Android e Firebase apontam para o mesmo projeto e publica somente regras/índices do Firestore e Hosting. Não implanta Functions nem Storage e não muda o plano Firebase.

Se o build não ficar verde, abra o primeiro erro no log antes de tentar novamente. Uma conta de serviço sem permissão de implantação impede esta etapa; isso não exige ativar faturamento.

## 5. Crie ou confirme sua conta administrativa

No Firebase Console → Authentication → Users, crie uma conta Email/Senha para seu e-mail se ainda não existir. Confirme o e-mail. Rode novamente **Score Master - Implantar Firebase real** com `SCORE_ADMIN_EMAIL` configurado. O workflow concede a claim administrativa e encerra sessões anteriores; saia e entre de novo no painel.

Abra o endereço Hosting do projeto no navegador, escolha conectar Firebase e cole a configuração do app Web. Entre com a conta administrativa verificada. O painel permite cadastrar/publicar palpites, administrar categorias e editar a configuração visual. Cadastre conteúdo verdadeiro antes de esperar que apareça no aplicativo.

## 6. Gere o APK assinado

No Codemagic, execute **Score Master - Release assinado**. Quando terminar verde, baixe `app-release.apk` e `app-release.apk.sha256` em Artifacts. O APK usa a chave permanente que você já importou. Instale no Android e confira o feed, detalhes, pesquisa, filtros, favoritos locais e painel web.

## Recursos que ficam fora desta edição sem cobrança

- Contas de visitantes, login/cadastro, perfis e estatísticas pessoais.
- Sincronização dos favoritos entre aparelhos; eles ficam apenas no aparelho atual.
- Notificações push/campanhas e publicação agendada.
- Envio de imagens ao Firebase Storage; a logomarca já incluída no APK continua disponível.
- Histórico de auditoria e validações executadas pelo antigo backend.

As gravações administrativas são feitas diretamente no Firestore e protegidas pela claim `admin`. Firestore, Authentication e Hosting continuam sujeitos às cotas gratuitas do Firebase. Se o uso ultrapassar os limites gratuitos, interrompa o uso ou reduza o tráfego; não faça upgrade para Blaze.
